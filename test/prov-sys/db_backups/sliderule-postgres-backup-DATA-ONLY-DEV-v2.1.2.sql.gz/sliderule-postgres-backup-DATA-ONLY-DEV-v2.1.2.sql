--
-- PostgreSQL database dump
--

-- Dumped from database version 13.9 (Debian 13.9-1.pgdg110+1)
-- Dumped by pg_dump version 13.9 (Debian 13.9-1.pgdg110+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: users_user; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.users_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined) FROM stdin;
3	pbkdf2_sha256$390000$FenreIjuJUdsTsTFYPPHDo$TCF/OjcfnQXKQX1bEWxISk7tkY+LSsx+9xW6u6kReo4=	2023-02-08 15:23:27.264922-05	f	devtester	development	tester	devtester@mail.slideruleearth.io	f	t	2023-02-07 09:31:17.4129-05
1	pbkdf2_sha256$390000$z4rZRc4bS7uhBDMzXFdL7m$L+WD3ly2wwN2Ze/ajIURJWpqTocBd33fr5m0xf81XY8=	2023-02-10 08:42:25.30243-05	t	admin			carlos.ugarte.nasa@gmail.com	t	t	2023-02-06 17:32:54.93728-05
4	pbkdf2_sha256$390000$Qc0fHJpTxiNQ4Z5y5uWfJg$CGmy1yrbzB6qCOBzzs027zc/fCEyRMWFMxF0hLj+FIA=	2023-02-14 14:48:50.201612-05	f	cugarteblair	Carlos	Ugarte	cugarteblair@gmail.com	t	t	2023-02-09 17:30:21-05
5	pbkdf2_sha256$390000$Rcl9CkADZO1XZ51tZKHHD8$7HOKwlZa6CzUASPAmkIcNg+xtrrHZMiLkF2sIJZt+2s=	2023-02-14 14:51:29.111056-05	f	ceugarteblair	CarlosE	Ugarte	ceugarteblair@icloud.com	f	t	2023-02-14 14:51:28.29707-05
\.


--
-- Data for Name: account_emailaddress; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.account_emailaddress (id, email, verified, "primary", user_id) FROM stdin;
1	carlos.ugarte.nasa@gmail.com	t	t	1
3	devtester@mail.slideruleearth.io	f	t	3
4	cugarteblair@gmail.com	t	t	4
5	ceugarteblair@icloud.com	f	t	5
\.


--
-- Data for Name: account_emailconfirmation; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.account_emailconfirmation (id, created, sent, key, email_address_id) FROM stdin;
\.


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.auth_group (id, name) FROM stdin;
1	PS_Developer
\.


--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.django_content_type (id, app_label, model) FROM stdin;
1	admin	logentry
2	auth	permission
3	auth	group
4	contenttypes	contenttype
5	sessions	session
6	token_blacklist	blacklistedtoken
7	token_blacklist	outstandingtoken
8	users	user
9	users	granchoice
10	users	orgaccount
11	users	cluster
12	users	pscmdqueueresult
13	users	orgnumnode
14	users	orgcost
15	users	membership
16	captcha	captchastore
17	django_celery_results	taskresult
18	django_celery_results	chordcounter
19	django_celery_results	groupresult
20	django_celery_beat	crontabschedule
21	django_celery_beat	intervalschedule
22	django_celery_beat	periodictask
23	django_celery_beat	periodictasks
24	django_celery_beat	solarschedule
25	django_celery_beat	clockedschedule
26	sites	site
27	account	emailaddress
28	account	emailconfirmation
29	socialaccount	socialaccount
30	socialaccount	socialapp
31	socialaccount	socialtoken
\.


--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.auth_permission (id, name, content_type_id, codename) FROM stdin;
1	Can add log entry	1	add_logentry
2	Can change log entry	1	change_logentry
3	Can delete log entry	1	delete_logentry
4	Can view log entry	1	view_logentry
5	Can add permission	2	add_permission
6	Can change permission	2	change_permission
7	Can delete permission	2	delete_permission
8	Can view permission	2	view_permission
9	Can add group	3	add_group
10	Can change group	3	change_group
11	Can delete group	3	delete_group
12	Can view group	3	view_group
13	Can add content type	4	add_contenttype
14	Can change content type	4	change_contenttype
15	Can delete content type	4	delete_contenttype
16	Can view content type	4	view_contenttype
17	Can add session	5	add_session
18	Can change session	5	change_session
19	Can delete session	5	delete_session
20	Can view session	5	view_session
21	Can add blacklisted token	6	add_blacklistedtoken
22	Can change blacklisted token	6	change_blacklistedtoken
23	Can delete blacklisted token	6	delete_blacklistedtoken
24	Can view blacklisted token	6	view_blacklistedtoken
25	Can add outstanding token	7	add_outstandingtoken
26	Can change outstanding token	7	change_outstandingtoken
27	Can delete outstanding token	7	delete_outstandingtoken
28	Can view outstanding token	7	view_outstandingtoken
29	Can add user	8	add_user
30	Can change user	8	change_user
31	Can delete user	8	delete_user
32	Can view user	8	view_user
33	Can add gran choice	9	add_granchoice
34	Can change gran choice	9	change_granchoice
35	Can delete gran choice	9	delete_granchoice
36	Can view gran choice	9	view_granchoice
37	Can add org account	10	add_orgaccount
38	Can change org account	10	change_orgaccount
39	Can delete org account	10	delete_orgaccount
40	Can view org account	10	view_orgaccount
41	Can add cluster	11	add_cluster
42	Can change cluster	11	change_cluster
43	Can delete cluster	11	delete_cluster
44	Can view cluster	11	view_cluster
45	Can add ps cmd queue result	12	add_pscmdqueueresult
46	Can change ps cmd queue result	12	change_pscmdqueueresult
47	Can delete ps cmd queue result	12	delete_pscmdqueueresult
48	Can view ps cmd queue result	12	view_pscmdqueueresult
49	Can add org num node	13	add_orgnumnode
50	Can change org num node	13	change_orgnumnode
51	Can delete org num node	13	delete_orgnumnode
52	Can view org num node	13	view_orgnumnode
53	Can add org cost	14	add_orgcost
54	Can change org cost	14	change_orgcost
55	Can delete org cost	14	delete_orgcost
56	Can view org cost	14	view_orgcost
57	Can add membership	15	add_membership
58	Can change membership	15	change_membership
59	Can delete membership	15	delete_membership
60	Can view membership	15	view_membership
61	Can add captcha store	16	add_captchastore
62	Can change captcha store	16	change_captchastore
63	Can delete captcha store	16	delete_captchastore
64	Can view captcha store	16	view_captchastore
65	Can add task result	17	add_taskresult
66	Can change task result	17	change_taskresult
67	Can delete task result	17	delete_taskresult
68	Can view task result	17	view_taskresult
69	Can add chord counter	18	add_chordcounter
70	Can change chord counter	18	change_chordcounter
71	Can delete chord counter	18	delete_chordcounter
72	Can view chord counter	18	view_chordcounter
73	Can add group result	19	add_groupresult
74	Can change group result	19	change_groupresult
75	Can delete group result	19	delete_groupresult
76	Can view group result	19	view_groupresult
77	Can add crontab	20	add_crontabschedule
78	Can change crontab	20	change_crontabschedule
79	Can delete crontab	20	delete_crontabschedule
80	Can view crontab	20	view_crontabschedule
81	Can add interval	21	add_intervalschedule
82	Can change interval	21	change_intervalschedule
83	Can delete interval	21	delete_intervalschedule
84	Can view interval	21	view_intervalschedule
85	Can add periodic task	22	add_periodictask
86	Can change periodic task	22	change_periodictask
87	Can delete periodic task	22	delete_periodictask
88	Can view periodic task	22	view_periodictask
89	Can add periodic tasks	23	add_periodictasks
90	Can change periodic tasks	23	change_periodictasks
91	Can delete periodic tasks	23	delete_periodictasks
92	Can view periodic tasks	23	view_periodictasks
93	Can add solar event	24	add_solarschedule
94	Can change solar event	24	change_solarschedule
95	Can delete solar event	24	delete_solarschedule
96	Can view solar event	24	view_solarschedule
97	Can add clocked	25	add_clockedschedule
98	Can change clocked	25	change_clockedschedule
99	Can delete clocked	25	delete_clockedschedule
100	Can view clocked	25	view_clockedschedule
101	Can add site	26	add_site
102	Can change site	26	change_site
103	Can delete site	26	delete_site
104	Can view site	26	view_site
105	Can add email address	27	add_emailaddress
106	Can change email address	27	change_emailaddress
107	Can delete email address	27	delete_emailaddress
108	Can view email address	27	view_emailaddress
109	Can add email confirmation	28	add_emailconfirmation
110	Can change email confirmation	28	change_emailconfirmation
111	Can delete email confirmation	28	delete_emailconfirmation
112	Can view email confirmation	28	view_emailconfirmation
113	Can add social account	29	add_socialaccount
114	Can change social account	29	change_socialaccount
115	Can delete social account	29	delete_socialaccount
116	Can view social account	29	view_socialaccount
117	Can add social application	30	add_socialapp
118	Can change social application	30	change_socialapp
119	Can delete social application	30	delete_socialapp
120	Can view social application	30	view_socialapp
121	Can add social application token	31	add_socialtoken
122	Can change social application token	31	change_socialtoken
123	Can delete social application token	31	delete_socialtoken
124	Can view social application token	31	view_socialtoken
\.


--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.auth_group_permissions (id, group_id, permission_id) FROM stdin;
1	1	21
2	1	22
3	1	23
4	1	24
5	1	25
6	1	26
7	1	27
8	1	28
9	1	29
10	1	30
11	1	31
12	1	32
13	1	37
14	1	38
15	1	39
16	1	40
17	1	41
18	1	42
19	1	43
20	1	44
21	1	45
22	1	46
23	1	47
24	1	48
25	1	49
26	1	50
27	1	51
28	1	52
29	1	53
30	1	54
31	1	55
32	1	56
33	1	57
34	1	58
35	1	59
36	1	60
37	1	65
38	1	66
39	1	67
40	1	68
41	1	69
42	1	70
43	1	71
44	1	72
45	1	73
46	1	74
47	1	75
48	1	76
49	1	77
50	1	78
51	1	79
52	1	80
53	1	81
54	1	82
55	1	83
56	1	84
57	1	85
58	1	86
59	1	87
60	1	88
61	1	89
62	1	90
63	1	91
64	1	92
65	1	93
66	1	94
67	1	95
68	1	96
69	1	97
70	1	98
71	1	99
72	1	100
73	1	101
74	1	102
75	1	103
76	1	104
77	1	105
78	1	106
79	1	107
80	1	108
81	1	109
82	1	110
83	1	111
84	1	112
85	1	113
86	1	114
87	1	115
88	1	116
89	1	117
90	1	118
91	1	119
92	1	120
93	1	121
94	1	122
95	1	123
96	1	124
\.


--
-- Data for Name: captcha_captchastore; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.captcha_captchastore (id, challenge, response, hashkey, expiration) FROM stdin;
7	ETHQ	ethq	b3ef14dc72a67ccdbd492a06f90585aa44d796fc	2023-02-14 14:53:22.607041-05
\.


--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
1	2023-02-07 09:30:14.682332-05	2	development	3		8	1
2	2023-02-07 09:49:26.558989-05	1	testsliderule-oauth	1	[{"added": {}}]	30	1
3	2023-02-07 09:49:53.898294-05	2	127.0.0.1:8080	2	[{"changed": {"fields": ["Domain name", "Display name"]}}]	26	1
4	2023-02-07 09:50:08.219719-05	1	testsliderule-oauth	2	[{"changed": {"fields": ["Sites"]}}]	30	1
5	2023-02-10 08:46:02.812322-05	1	PS_Developer	1	[{"added": {}}]	3	1
6	2023-02-10 08:46:21.617365-05	4	cugarteblair	2	[{"changed": {"fields": ["Groups", "Staff status"]}}]	8	1
\.


--
-- Data for Name: django_celery_beat_clockedschedule; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.django_celery_beat_clockedschedule (id, clocked_time) FROM stdin;
\.


--
-- Data for Name: django_celery_beat_crontabschedule; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.django_celery_beat_crontabschedule (id, minute, hour, day_of_week, day_of_month, month_of_year, timezone) FROM stdin;
1	0	4	*	*	*	UTC
2	30	*	*	*	*	UTC
3	15	*	*	*	*	UTC
4	0	0	*	*	*	UTC
\.


--
-- Data for Name: django_celery_beat_intervalschedule; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.django_celery_beat_intervalschedule (id, every, period) FROM stdin;
\.


--
-- Data for Name: django_celery_beat_solarschedule; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.django_celery_beat_solarschedule (id, event, latitude, longitude) FROM stdin;
\.


--
-- Data for Name: django_celery_beat_periodictask; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.django_celery_beat_periodictask (id, name, task, args, kwargs, queue, exchange, routing_key, expires, enabled, last_run_at, total_run_count, date_changed, description, crontab_id, interval_id, solar_id, one_off, start_time, priority, headers, clocked_id, expire_seconds) FROM stdin;
1	celery.backend_cleanup	celery.backend_cleanup	[]	{}	\N	\N	\N	\N	t	2023-02-14 14:27:45.36501-05	8	2023-02-14 14:45:20.415475-05		1	\N	\N	f	\N	\N	{}	\N	43200
2	hourly processing	hourly_processing	[]	{}	default	\N	\N	\N	t	2023-02-14 14:30:00.019096-05	150	2023-02-14 14:45:20.429708-05		2	\N	\N	f	\N	\N	{}	\N	\N
3	flush expired refresh tokens	flush_expired_refresh_tokens	[]	{}	default	\N	\N	\N	t	2023-02-14 14:27:45.397103-05	146	2023-02-14 14:45:20.433959-05		3	\N	\N	f	\N	\N	{}	\N	\N
4	purge_ps_cmd_que_rslts	purge_ps_cmd_que_rslts	[]	{}	default	\N	\N	\N	t	2023-02-14 14:27:45.404895-05	8	2023-02-14 14:45:20.438641-05		4	\N	\N	f	\N	\N	{}	\N	\N
\.


--
-- Data for Name: django_celery_beat_periodictasks; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.django_celery_beat_periodictasks (ident, last_update) FROM stdin;
1	2023-02-14 14:45:20.43891-05
\.


--
-- Data for Name: django_celery_results_chordcounter; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.django_celery_results_chordcounter (id, group_id, sub_tasks, count) FROM stdin;
\.


--
-- Data for Name: django_celery_results_groupresult; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.django_celery_results_groupresult (id, group_id, date_created, date_done, content_type, content_encoding, result) FROM stdin;
\.


--
-- Data for Name: django_celery_results_taskresult; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.django_celery_results_taskresult (id, task_id, status, content_type, content_encoding, result, date_done, traceback, meta, task_args, task_kwargs, task_name, worker, date_created, periodic_task_name) FROM stdin;
314	b6449077-cd63-493e-b244-2a243664b989	SUCCESS	application/json	utf-8	false	2023-02-14 14:30:01.870762-05	\N	{"children": []}	"()"	"{}"	hourly_processing	default@%c01f8cfef590	2023-02-14 14:30:01.870751-05	hourly processing
309	a9b37a45-f445-4c94-8d07-c8c47ce73972	SUCCESS	application/json	utf-8	true	2023-02-13 15:15:00.054203-05	\N	{"children": []}	"()"	"{}"	flush_expired_refresh_tokens	default@%4a2d0815f3d9	2023-02-13 15:15:00.054171-05	flush expired refresh tokens
308	d28375e7-295c-4dfd-82d4-7b267378e43a	SUCCESS	application/json	utf-8	true	2023-02-13 14:30:01.914273-05	\N	{"children": []}	"()"	"{}"	hourly_processing	default@%93b8b8d424c0	2023-02-13 14:30:01.914264-05	hourly processing
310	397cc11e-a58a-4f13-994c-c76a85dc1742	SUCCESS	application/json	utf-8	null	2023-02-14 14:27:46.603495-05	\N	{"children": []}	"()"	"{}"	celery.backend_cleanup	default@%c01f8cfef590	2023-02-14 14:27:46.603486-05	celery.backend_cleanup
311	1c45f3be-8ef2-49ee-af01-bf82a1ea5401	SUCCESS	application/json	utf-8	true	2023-02-14 14:27:46.605125-05	\N	{"children": []}	"()"	"{}"	flush_expired_refresh_tokens	default@%c01f8cfef590	2023-02-14 14:27:46.605064-05	flush expired refresh tokens
312	af76da09-1c9d-447f-99fb-740af4335ed0	SUCCESS	application/json	utf-8	null	2023-02-14 14:27:46.609949-05	\N	{"children": []}	"()"	"{}"	purge_ps_cmd_que_rslts	default@%c01f8cfef590	2023-02-14 14:27:46.60994-05	purge_ps_cmd_que_rslts
313	1730e50d-f1bb-422b-ae17-cae0e85731a4	SUCCESS	application/json	utf-8	false	2023-02-14 14:27:50.572805-05	\N	{"children": []}	"()"	"{}"	hourly_processing	default@%c01f8cfef590	2023-02-14 14:27:50.57279-05	hourly processing
\.


--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.django_migrations (id, app, name, applied) FROM stdin;
1	django_celery_results	0001_initial	2023-02-06 17:23:16.028476-05
2	django_celery_results	0002_add_task_name_args_kwargs	2023-02-06 17:23:16.03133-05
3	django_celery_results	0003_auto_20181106_1101	2023-02-06 17:23:16.03278-05
4	django_celery_results	0004_auto_20190516_0412	2023-02-06 17:23:16.044014-05
5	django_celery_results	0005_taskresult_worker	2023-02-06 17:23:16.04736-05
6	django_celery_results	0006_taskresult_date_created	2023-02-06 17:23:16.051893-05
7	django_celery_results	0007_remove_taskresult_hidden	2023-02-06 17:23:16.053521-05
8	django_celery_results	0008_chordcounter	2023-02-06 17:23:16.059124-05
9	django_celery_results	0009_groupresult	2023-02-06 17:23:16.086413-05
10	django_celery_results	0010_remove_duplicate_indices	2023-02-06 17:23:16.088716-05
11	django_celery_results	0011_taskresult_periodic_task_name	2023-02-06 17:23:16.090152-05
12	contenttypes	0001_initial	2023-02-06 17:23:16.093859-05
13	contenttypes	0002_remove_content_type_name	2023-02-06 17:23:16.098041-05
14	auth	0001_initial	2023-02-06 17:23:16.112664-05
15	auth	0002_alter_permission_name_max_length	2023-02-06 17:23:16.115123-05
16	auth	0003_alter_user_email_max_length	2023-02-06 17:23:16.117996-05
17	auth	0004_alter_user_username_opts	2023-02-06 17:23:16.120131-05
18	auth	0005_alter_user_last_login_null	2023-02-06 17:23:16.122426-05
19	auth	0006_require_contenttypes_0002	2023-02-06 17:23:16.123337-05
20	auth	0007_alter_validators_add_error_messages	2023-02-06 17:23:16.125537-05
21	auth	0008_alter_user_username_max_length	2023-02-06 17:23:16.128731-05
22	auth	0009_alter_user_last_name_max_length	2023-02-06 17:23:16.130906-05
23	auth	0010_alter_group_name_max_length	2023-02-06 17:23:16.13348-05
24	auth	0011_update_proxy_permissions	2023-02-06 17:23:16.136334-05
25	auth	0012_alter_user_first_name_max_length	2023-02-06 17:23:16.138588-05
26	users	0001_initial	2023-02-06 17:23:16.202174-05
27	account	0001_initial	2023-02-06 17:23:16.221724-05
28	account	0002_email_max_length	2023-02-06 17:23:16.226328-05
29	admin	0001_initial	2023-02-06 17:23:16.236127-05
30	admin	0002_logentry_remove_auto_add	2023-02-06 17:23:16.240333-05
31	admin	0003_logentry_add_action_flag_choices	2023-02-06 17:23:16.244358-05
32	captcha	0001_initial	2023-02-06 17:23:16.249188-05
33	captcha	0002_alter_captchastore_id	2023-02-06 17:23:16.250584-05
34	django_celery_beat	0001_initial	2023-02-06 17:23:16.265436-05
35	django_celery_beat	0002_auto_20161118_0346	2023-02-06 17:23:16.270774-05
36	django_celery_beat	0003_auto_20161209_0049	2023-02-06 17:23:16.274384-05
37	django_celery_beat	0004_auto_20170221_0000	2023-02-06 17:23:16.276616-05
38	django_celery_beat	0005_add_solarschedule_events_choices	2023-02-06 17:23:16.279013-05
39	django_celery_beat	0006_auto_20180322_0932	2023-02-06 17:23:16.288123-05
40	django_celery_beat	0007_auto_20180521_0826	2023-02-06 17:23:16.292665-05
41	django_celery_beat	0008_auto_20180914_1922	2023-02-06 17:23:16.299785-05
42	django_celery_beat	0006_auto_20180210_1226	2023-02-06 17:23:16.304117-05
43	django_celery_beat	0006_periodictask_priority	2023-02-06 17:23:16.306866-05
44	django_celery_beat	0009_periodictask_headers	2023-02-06 17:23:16.309881-05
45	django_celery_beat	0010_auto_20190429_0326	2023-02-06 17:23:16.376794-05
46	django_celery_beat	0011_auto_20190508_0153	2023-02-06 17:23:16.383277-05
47	django_celery_beat	0012_periodictask_expire_seconds	2023-02-06 17:23:16.386189-05
48	django_celery_beat	0013_auto_20200609_0727	2023-02-06 17:23:16.388776-05
49	django_celery_beat	0014_remove_clockedschedule_enabled	2023-02-06 17:23:16.391144-05
50	django_celery_beat	0015_edit_solarschedule_events_choices	2023-02-06 17:23:16.393602-05
51	django_celery_beat	0016_alter_crontabschedule_timezone	2023-02-06 17:23:16.396435-05
52	sessions	0001_initial	2023-02-06 17:23:16.401716-05
53	sites	0001_initial	2023-02-06 17:23:16.40459-05
54	sites	0002_alter_domain_unique	2023-02-06 17:23:16.409127-05
55	socialaccount	0001_initial	2023-02-06 17:23:16.44837-05
56	socialaccount	0002_token_max_lengths	2023-02-06 17:23:16.460869-05
57	socialaccount	0003_extra_data_default_dict	2023-02-06 17:23:16.465827-05
58	token_blacklist	0001_initial	2023-02-06 17:23:16.489244-05
59	token_blacklist	0002_outstandingtoken_jti_hex	2023-02-06 17:23:16.494848-05
60	token_blacklist	0003_auto_20171017_2007	2023-02-06 17:23:16.504298-05
61	token_blacklist	0004_auto_20171017_2013	2023-02-06 17:23:16.512343-05
62	token_blacklist	0005_remove_outstandingtoken_jti	2023-02-06 17:23:16.517412-05
63	token_blacklist	0006_auto_20171017_2113	2023-02-06 17:23:16.522336-05
64	token_blacklist	0007_auto_20171017_2214	2023-02-06 17:23:16.536298-05
65	token_blacklist	0008_migrate_to_bigautofield	2023-02-06 17:23:16.556383-05
66	token_blacklist	0010_fix_migrate_to_bigautofield	2023-02-06 17:23:16.566023-05
67	token_blacklist	0011_linearizes_history	2023-02-06 17:23:16.566953-05
68	token_blacklist	0012_alter_outstandingtoken_user	2023-02-06 17:23:16.574628-05
69	users	0002_auto_20221202_2142	2023-02-06 17:23:16.584957-05
70	users	0003_alter_orgaccount_cur_ddt_alter_orgaccount_max_ddt_and_more	2023-02-06 17:23:16.599622-05
71	users	0004_orgaccount_is_public	2023-02-06 17:23:16.605535-05
72	users	0005_orgaccount_pcqr_display_age_in_hours_and_more	2023-02-06 17:23:16.620699-05
73	users	0006_remove_user_phone_number_and_more	2023-02-06 17:23:16.689228-05
\.


--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.django_session (session_key, session_data, expire_date) FROM stdin;
\.


--
-- Data for Name: django_site; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.django_site (id, domain, name) FROM stdin;
2	127.0.0.1:8080	127.0.0.1:8080
\.


--
-- Data for Name: socialaccount_socialaccount; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.socialaccount_socialaccount (id, provider, uid, last_login, date_joined, extra_data, user_id) FROM stdin;
\.


--
-- Data for Name: socialaccount_socialapp; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.socialaccount_socialapp (id, provider, name, client_id, secret, key) FROM stdin;
1	github	testsliderule-oauth	ec90dbd6ffb32e63c3a1	11d41047c2ccf7a83e38800aa05c171b896c190c	
\.


--
-- Data for Name: socialaccount_socialapp_sites; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.socialaccount_socialapp_sites (id, socialapp_id, site_id) FROM stdin;
1	1	2
\.


--
-- Data for Name: socialaccount_socialtoken; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.socialaccount_socialtoken (id, token, token_secret, expires_at, account_id, app_id) FROM stdin;
\.


--
-- Data for Name: token_blacklist_outstandingtoken; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.token_blacklist_outstandingtoken (id, token, created_at, expires_at, user_id, jti) FROM stdin;
\.


--
-- Data for Name: token_blacklist_blacklistedtoken; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.token_blacklist_blacklistedtoken (id, blacklisted_at, token_id) FROM stdin;
\.


--
-- Data for Name: users_orgaccount; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.users_orgaccount (id, name, point_of_contact_name, email, max_allowance, monthly_allowance, balance, creation_date, modified_date, node_mgr_fixed_cost, node_fixed_cost, desired_num_nodes, cur_nodes, min_node_cap, max_node_cap, max_hrly, cur_hrly, min_hrly, min_ddt, cur_ddt, max_ddt, most_recent_charge_time, most_recent_credit_time, most_recent_recon_time, fc_min_hourly, fc_min_daily, fc_min_monthly, fc_cur_hourly, fc_cur_daily, fc_cur_monthly, fc_max_hourly, fc_max_daily, fc_max_monthly, version, mfa_code, admin_max_node_cap, tokens, tokens_time, time_to_live_in_mins, expire_time, allow_deploy_by_token, destroy_when_no_nodes, owner_id, is_public, pcqr_display_age_in_hours, pcqr_retention_age_in_days, fytd_accrued_cost) FROM stdin;
554c7ff6-263d-4910-8fa3-5636b9c51e45	unit-test-org	support team	sps.sliderule@gmail.com	1000.00	100.00	1000.00	2023-02-10 08:49:15.123129-05	2023-02-14 14:30:01.859661-05	0.153	0.226	0	0	0	10	2.4130000000000003	0.0001	0.0001	3163-12-02 06:30:01.859376-05	3163-12-02 06:30:01.859431-05	2023-03-03 20:55:20.632788-05	2023-02-11 19:00:00-05	2023-01-31 19:00:00-05	2023-02-13 11:30:04.385947-05	"{\\"tm\\": [\\"2023-02-13T16:30\\", \\"2023-02-13T17:30\\", \\"2023-02-13T18:30\\", \\"2023-02-13T19:30\\", \\"2023-02-13T20:30\\", \\"2023-02-13T21:30\\", \\"2023-02-13T22:30\\", \\"2023-02-13T23:30\\", \\"2023-02-14T00:30\\", \\"2023-02-14T01:30\\", \\"2023-02-14T02:30\\", \\"2023-02-14T03:30\\", \\"2023-02-14T04:30\\", \\"2023-02-14T05:30\\", \\"2023-02-14T06:30\\", \\"2023-02-14T07:30\\", \\"2023-02-14T08:30\\", \\"2023-02-14T09:30\\", \\"2023-02-14T10:30\\", \\"2023-02-14T11:30\\", \\"2023-02-14T12:30\\", \\"2023-02-14T13:30\\", \\"2023-02-14T14:30\\", \\"2023-02-14T15:30\\", \\"2023-02-14T16:30\\", \\"2023-02-14T17:30\\", \\"2023-02-14T18:30\\", \\"2023-02-14T19:30\\", \\"2023-02-14T20:30\\", \\"2023-02-14T21:30\\", \\"2023-02-14T22:30\\", \\"2023-02-14T23:30\\", \\"2023-02-15T00:30\\", \\"2023-02-15T01:30\\", \\"2023-02-15T02:30\\", \\"2023-02-15T03:30\\", \\"2023-02-15T04:30\\", \\"2023-02-15T05:30\\", \\"2023-02-15T06:30\\", \\"2023-02-15T07:30\\", \\"2023-02-15T08:30\\", \\"2023-02-15T09:30\\", \\"2023-02-15T10:30\\", \\"2023-02-15T11:30\\", \\"2023-02-15T12:30\\", \\"2023-02-15T13:30\\", \\"2023-02-15T14:30\\", \\"2023-02-15T15:30\\", \\"2023-02-15T16:30\\", \\"2023-02-15T17:30\\", \\"2023-02-15T18:30\\", \\"2023-02-15T19:30\\", \\"2023-02-15T20:30\\", \\"2023-02-15T21:30\\", \\"2023-02-15T22:30\\", \\"2023-02-15T23:30\\", \\"2023-02-16T00:30\\", \\"2023-02-16T01:30\\", \\"2023-02-16T02:30\\", \\"2023-02-16T03:30\\", \\"2023-02-16T04:30\\", \\"2023-02-16T05:30\\", \\"2023-02-16T06:30\\", \\"2023-02-16T07:30\\", \\"2023-02-16T08:30\\", \\"2023-02-16T09:30\\", \\"2023-02-16T10:30\\", \\"2023-02-16T11:30\\", \\"2023-02-16T12:30\\", \\"2023-02-16T13:30\\", \\"2023-02-16T14:30\\", \\"2023-02-16T15:30\\", \\"2023-02-16T16:30\\", \\"2023-02-16T17:30\\", \\"2023-02-16T18:30\\", \\"2023-02-16T19:30\\", \\"2023-02-16T20:30\\", \\"2023-02-16T21:30\\", \\"2023-02-16T22:30\\", \\"2023-02-16T23:30\\", \\"2023-02-17T00:30\\", \\"2023-02-17T01:30\\", \\"2023-02-17T02:30\\", \\"2023-02-17T03:30\\", \\"2023-02-17T04:30\\", \\"2023-02-17T05:30\\", \\"2023-02-17T06:30\\", \\"2023-02-17T07:30\\", \\"2023-02-17T08:30\\", \\"2023-02-17T09:30\\", \\"2023-02-17T10:30\\", \\"2023-02-17T11:30\\", \\"2023-02-17T12:30\\", \\"2023-02-17T13:30\\", \\"2023-02-17T14:30\\", \\"2023-02-17T15:30\\", \\"2023-02-17T16:30\\", \\"2023-02-17T17:30\\", \\"2023-02-17T18:30\\", \\"2023-02-17T19:30\\", \\"2023-02-17T20:30\\", \\"2023-02-17T21:30\\", \\"2023-02-17T22:30\\", \\"2023-02-17T23:30\\", \\"2023-02-18T00:30\\", \\"2023-02-18T01:30\\", \\"2023-02-18T02:30\\", \\"2023-02-18T03:30\\", \\"2023-02-18T04:30\\", \\"2023-02-18T05:30\\", \\"2023-02-18T06:30\\", \\"2023-02-18T07:30\\", \\"2023-02-18T08:30\\", \\"2023-02-18T09:30\\", \\"2023-02-18T10:30\\", \\"2023-02-18T11:30\\", \\"2023-02-18T12:30\\", \\"2023-02-18T13:30\\", \\"2023-02-18T14:30\\", \\"2023-02-18T15:30\\", \\"2023-02-18T16:30\\", \\"2023-02-18T17:30\\", \\"2023-02-18T18:30\\", \\"2023-02-18T19:30\\", \\"2023-02-18T20:30\\", \\"2023-02-18T21:30\\", \\"2023-02-18T22:30\\", \\"2023-02-18T23:30\\", \\"2023-02-19T00:30\\", \\"2023-02-19T01:30\\", \\"2023-02-19T02:30\\", \\"2023-02-19T03:30\\", \\"2023-02-19T04:30\\", \\"2023-02-19T05:30\\", \\"2023-02-19T06:30\\", \\"2023-02-19T07:30\\", \\"2023-02-19T08:30\\", \\"2023-02-19T09:30\\", \\"2023-02-19T10:30\\", \\"2023-02-19T11:30\\", \\"2023-02-19T12:30\\", \\"2023-02-19T13:30\\", \\"2023-02-19T14:30\\", \\"2023-02-19T15:30\\", \\"2023-02-19T16:30\\", \\"2023-02-19T17:30\\", \\"2023-02-19T18:30\\", \\"2023-02-19T19:30\\", \\"2023-02-19T20:30\\", \\"2023-02-19T21:30\\", \\"2023-02-19T22:30\\", \\"2023-02-19T23:30\\", \\"2023-02-20T00:30\\", \\"2023-02-20T01:30\\", \\"2023-02-20T02:30\\", \\"2023-02-20T03:30\\", \\"2023-02-20T04:30\\", \\"2023-02-20T05:30\\", \\"2023-02-20T06:30\\", \\"2023-02-20T07:30\\", \\"2023-02-20T08:30\\", \\"2023-02-20T09:30\\", \\"2023-02-20T10:30\\", \\"2023-02-20T11:30\\", \\"2023-02-20T12:30\\", \\"2023-02-20T13:30\\", \\"2023-02-20T14:30\\", \\"2023-02-20T15:30\\", \\"2023-02-20T16:30\\", \\"2023-02-20T17:30\\", \\"2023-02-20T18:30\\", \\"2023-02-20T19:30\\", \\"2023-02-20T20:30\\", \\"2023-02-20T21:30\\", \\"2023-02-20T22:30\\", \\"2023-02-20T23:30\\", \\"2023-02-21T00:30\\", \\"2023-02-21T01:30\\", \\"2023-02-21T02:30\\", \\"2023-02-21T03:30\\", \\"2023-02-21T04:30\\", \\"2023-02-21T05:30\\", \\"2023-02-21T06:30\\", \\"2023-02-21T07:30\\", \\"2023-02-21T08:30\\", \\"2023-02-21T09:30\\", \\"2023-02-21T10:30\\", \\"2023-02-21T11:30\\", \\"2023-02-21T12:30\\", \\"2023-02-21T13:30\\", \\"2023-02-21T14:30\\", \\"2023-02-21T15:30\\", \\"2023-02-21T16:30\\", \\"2023-02-21T17:30\\", \\"2023-02-21T18:30\\", \\"2023-02-21T19:30\\", \\"2023-02-21T20:30\\", \\"2023-02-21T21:30\\", \\"2023-02-21T22:30\\", \\"2023-02-21T23:30\\", \\"2023-02-22T00:30\\", \\"2023-02-22T01:30\\", \\"2023-02-22T02:30\\", \\"2023-02-22T03:30\\", \\"2023-02-22T04:30\\", \\"2023-02-22T05:30\\", \\"2023-02-22T06:30\\", \\"2023-02-22T07:30\\", \\"2023-02-22T08:30\\", \\"2023-02-22T09:30\\", \\"2023-02-22T10:30\\", \\"2023-02-22T11:30\\", \\"2023-02-22T12:30\\", \\"2023-02-22T13:30\\", \\"2023-02-22T14:30\\", \\"2023-02-22T15:30\\", \\"2023-02-22T16:30\\", \\"2023-02-22T17:30\\", \\"2023-02-22T18:30\\", \\"2023-02-22T19:30\\", \\"2023-02-22T20:30\\", \\"2023-02-22T21:30\\", \\"2023-02-22T22:30\\", \\"2023-02-22T23:30\\", \\"2023-02-23T00:30\\", \\"2023-02-23T01:30\\", \\"2023-02-23T02:30\\", \\"2023-02-23T03:30\\", \\"2023-02-23T04:30\\", \\"2023-02-23T05:30\\", \\"2023-02-23T06:30\\", \\"2023-02-23T07:30\\", \\"2023-02-23T08:30\\", \\"2023-02-23T09:30\\", \\"2023-02-23T10:30\\", \\"2023-02-23T11:30\\", \\"2023-02-23T12:30\\", \\"2023-02-23T13:30\\", \\"2023-02-23T14:30\\", \\"2023-02-23T15:30\\", \\"2023-02-23T16:30\\", \\"2023-02-23T17:30\\", \\"2023-02-23T18:30\\", \\"2023-02-23T19:30\\", \\"2023-02-23T20:30\\", \\"2023-02-23T21:30\\", \\"2023-02-23T22:30\\", \\"2023-02-23T23:30\\", \\"2023-02-24T00:30\\", \\"2023-02-24T01:30\\", \\"2023-02-24T02:30\\", \\"2023-02-24T03:30\\", \\"2023-02-24T04:30\\", \\"2023-02-24T05:30\\", \\"2023-02-24T06:30\\", \\"2023-02-24T07:30\\", \\"2023-02-24T08:30\\", \\"2023-02-24T09:30\\", \\"2023-02-24T10:30\\", \\"2023-02-24T11:30\\", \\"2023-02-24T12:30\\", \\"2023-02-24T13:30\\", \\"2023-02-24T14:30\\", \\"2023-02-24T15:30\\", \\"2023-02-24T16:30\\", \\"2023-02-24T17:30\\", \\"2023-02-24T18:30\\", \\"2023-02-24T19:30\\", \\"2023-02-24T20:30\\", \\"2023-02-24T21:30\\", \\"2023-02-24T22:30\\", \\"2023-02-24T23:30\\", \\"2023-02-25T00:30\\", \\"2023-02-25T01:30\\", \\"2023-02-25T02:30\\", \\"2023-02-25T03:30\\", \\"2023-02-25T04:30\\", \\"2023-02-25T05:30\\", \\"2023-02-25T06:30\\", \\"2023-02-25T07:30\\", \\"2023-02-25T08:30\\", \\"2023-02-25T09:30\\", \\"2023-02-25T10:30\\", \\"2023-02-25T11:30\\", \\"2023-02-25T12:30\\", \\"2023-02-25T13:30\\", \\"2023-02-25T14:30\\", \\"2023-02-25T15:30\\", \\"2023-02-25T16:30\\", \\"2023-02-25T17:30\\", \\"2023-02-25T18:30\\", \\"2023-02-25T19:30\\", \\"2023-02-25T20:30\\", \\"2023-02-25T21:30\\", \\"2023-02-25T22:30\\", \\"2023-02-25T23:30\\", \\"2023-02-26T00:30\\", \\"2023-02-26T01:30\\", \\"2023-02-26T02:30\\", \\"2023-02-26T03:30\\", \\"2023-02-26T04:30\\", \\"2023-02-26T05:30\\", \\"2023-02-26T06:30\\", \\"2023-02-26T07:30\\", \\"2023-02-26T08:30\\", \\"2023-02-26T09:30\\", \\"2023-02-26T10:30\\", \\"2023-02-26T11:30\\", \\"2023-02-26T12:30\\", \\"2023-02-26T13:30\\", \\"2023-02-26T14:30\\", \\"2023-02-26T15:30\\", \\"2023-02-26T16:30\\", \\"2023-02-26T17:30\\", \\"2023-02-26T18:30\\", \\"2023-02-26T19:30\\", \\"2023-02-26T20:30\\", \\"2023-02-26T21:30\\", \\"2023-02-26T22:30\\", \\"2023-02-26T23:30\\", \\"2023-02-27T00:30\\", \\"2023-02-27T01:30\\", \\"2023-02-27T02:30\\", \\"2023-02-27T03:30\\", \\"2023-02-27T04:30\\", \\"2023-02-27T05:30\\", \\"2023-02-27T06:30\\", \\"2023-02-27T07:30\\", \\"2023-02-27T08:30\\", \\"2023-02-27T09:30\\", \\"2023-02-27T10:30\\", \\"2023-02-27T11:30\\", \\"2023-02-27T12:30\\", \\"2023-02-27T13:30\\", \\"2023-02-27T14:30\\", \\"2023-02-27T15:30\\"], \\"bal\\": [999.9999, 999.9998, 999.9997000000001, 999.9996000000001, 999.9995000000001, 999.9994000000002, 999.9993000000002, 999.9992000000002, 999.9991000000002, 999.9990000000003, 999.9989000000003, 999.9988000000003, 999.9987000000003, 999.9986000000004, 999.9985000000004, 999.9984000000004, 999.9983000000004, 999.9982000000005, 999.9981000000005, 999.9980000000005, 999.9979000000005, 999.9978000000006, 999.9977000000006, 999.9976000000006, 999.9975000000006, 999.9974000000007, 999.9973000000007, 999.9972000000007, 999.9971000000007, 999.9970000000008, 999.9969000000008, 999.9968000000008, 999.9967000000008, 999.9966000000009, 999.9965000000009, 999.9964000000009, 999.9963000000009, 999.996200000001, 999.996100000001, 999.996000000001, 999.995900000001, 999.995800000001, 999.9957000000011, 999.9956000000011, 999.9955000000011, 999.9954000000012, 999.9953000000012, 999.9952000000012, 999.9951000000012, 999.9950000000013, 999.9949000000013, 999.9948000000013, 999.9947000000013, 999.9946000000014, 999.9945000000014, 999.9944000000014, 999.9943000000014, 999.9942000000015, 999.9941000000015, 999.9940000000015, 999.9939000000015, 999.9938000000016, 999.9937000000016, 999.9936000000016, 999.9935000000016, 999.9934000000017, 999.9933000000017, 999.9932000000017, 999.9931000000017, 999.9930000000018, 999.9929000000018, 999.9928000000018, 999.9927000000018, 999.9926000000019, 999.9925000000019, 999.9924000000019, 999.9923000000019, 999.992200000002, 999.992100000002, 999.992000000002, 999.991900000002, 999.9918000000021, 999.9917000000021, 999.9916000000021, 999.9915000000021, 999.9914000000022, 999.9913000000022, 999.9912000000022, 999.9911000000022, 999.9910000000023, 999.9909000000023, 999.9908000000023, 999.9907000000023, 999.9906000000024, 999.9905000000024, 999.9904000000024, 999.9903000000024, 999.9902000000025, 999.9901000000025, 999.9900000000025, 999.9899000000025, 999.9898000000026, 999.9897000000026, 999.9896000000026, 999.9895000000026, 999.9894000000027, 999.9893000000027, 999.9892000000027, 999.9891000000027, 999.9890000000028, 999.9889000000028, 999.9888000000028, 999.9887000000028, 999.9886000000029, 999.9885000000029, 999.9884000000029, 999.9883000000029, 999.988200000003, 999.988100000003, 999.988000000003, 999.987900000003, 999.9878000000031, 999.9877000000031, 999.9876000000031, 999.9875000000031, 999.9874000000032, 999.9873000000032, 999.9872000000032, 999.9871000000032, 999.9870000000033, 999.9869000000033, 999.9868000000033, 999.9867000000033, 999.9866000000034, 999.9865000000034, 999.9864000000034, 999.9863000000034, 999.9862000000035, 999.9861000000035, 999.9860000000035, 999.9859000000035, 999.9858000000036, 999.9857000000036, 999.9856000000036, 999.9855000000036, 999.9854000000037, 999.9853000000037, 999.9852000000037, 999.9851000000037, 999.9850000000038, 999.9849000000038, 999.9848000000038, 999.9847000000038, 999.9846000000039, 999.9845000000039, 999.9844000000039, 999.9843000000039, 999.984200000004, 999.984100000004, 999.984000000004, 999.983900000004, 999.9838000000041, 999.9837000000041, 999.9836000000041, 999.9835000000041, 999.9834000000042, 999.9833000000042, 999.9832000000042, 999.9831000000042, 999.9830000000043, 999.9829000000043, 999.9828000000043, 999.9827000000043, 999.9826000000044, 999.9825000000044, 999.9824000000044, 999.9823000000044, 999.9822000000045, 999.9821000000045, 999.9820000000045, 999.9819000000045, 999.9818000000046, 999.9817000000046, 999.9816000000046, 999.9815000000046, 999.9814000000047, 999.9813000000047, 999.9812000000047, 999.9811000000047, 999.9810000000048, 999.9809000000048, 999.9808000000048, 999.9807000000048, 999.9806000000049, 999.9805000000049, 999.9804000000049, 999.980300000005, 999.980200000005, 999.980100000005, 999.980000000005, 999.979900000005, 999.9798000000051, 999.9797000000051, 999.9796000000051, 999.9795000000051, 999.9794000000052, 999.9793000000052, 999.9792000000052, 999.9791000000052, 999.9790000000053, 999.9789000000053, 999.9788000000053, 999.9787000000053, 999.9786000000054, 999.9785000000054, 999.9784000000054, 999.9783000000054, 999.9782000000055, 999.9781000000055, 999.9780000000055, 999.9779000000055, 999.9778000000056, 999.9777000000056, 999.9776000000056, 999.9775000000056, 999.9774000000057, 999.9773000000057, 999.9772000000057, 999.9771000000057, 999.9770000000058, 999.9769000000058, 999.9768000000058, 999.9767000000058, 999.9766000000059, 999.9765000000059, 999.9764000000059, 999.976300000006, 999.976200000006, 999.976100000006, 999.976000000006, 999.975900000006, 999.9758000000061, 999.9757000000061, 999.9756000000061, 999.9755000000062, 999.9754000000062, 999.9753000000062, 999.9752000000062, 999.9751000000063, 999.9750000000063, 999.9749000000063, 999.9748000000063, 999.9747000000064, 999.9746000000064, 999.9745000000064, 999.9744000000064, 999.9743000000065, 999.9742000000065, 999.9741000000065, 999.9740000000065, 999.9739000000066, 999.9738000000066, 999.9737000000066, 999.9736000000066, 999.9735000000067, 999.9734000000067, 999.9733000000067, 999.9732000000067, 999.9731000000068, 999.9730000000068, 999.9729000000068, 999.9728000000068, 999.9727000000069, 999.9726000000069, 999.9725000000069, 999.9724000000069, 999.972300000007, 999.972200000007, 999.972100000007, 999.972000000007, 999.971900000007, 999.9718000000071, 999.9717000000071, 999.9716000000071, 999.9715000000072, 999.9714000000072, 999.9713000000072, 999.9712000000072, 999.9711000000073, 999.9710000000073, 999.9709000000073, 999.9708000000073, 999.9707000000074, 999.9706000000074, 999.9705000000074, 999.9704000000074, 999.9703000000075, 999.9702000000075, 999.9701000000075, 999.9700000000075, 999.9699000000076, 999.9698000000076, 999.9697000000076, 999.9696000000076, 999.9695000000077, 999.9694000000077, 999.9693000000077, 999.9692000000077, 999.9691000000078, 999.9690000000078, 999.9689000000078, 999.9688000000078, 999.9687000000079, 999.9686000000079, 999.9685000000079, 999.9684000000079, 999.968300000008, 999.968200000008, 999.968100000008, 999.968000000008, 999.9679000000081, 999.9678000000081, 999.9677000000081, 999.9676000000081, 999.9675000000082, 999.9674000000082, 999.9673000000082, 999.9672000000082, 999.9671000000083, 999.9670000000083, 999.9669000000083, 999.9668000000083, 999.9667000000084, 999.9666000000084, 999.9665000000084, 999.9664000000084]}"	"{\\"tm\\": [\\"2023-02-14\\", \\"2023-02-15\\", \\"2023-02-16\\", \\"2023-02-17\\", \\"2023-02-18\\", \\"2023-02-19\\", \\"2023-02-20\\", \\"2023-02-21\\", \\"2023-02-22\\", \\"2023-02-23\\", \\"2023-02-24\\", \\"2023-02-25\\", \\"2023-02-26\\", \\"2023-02-27\\", \\"2023-02-28\\", \\"2023-03-01\\", \\"2023-03-02\\", \\"2023-03-03\\", \\"2023-03-04\\", \\"2023-03-05\\", \\"2023-03-06\\", \\"2023-03-07\\", \\"2023-03-08\\", \\"2023-03-09\\", \\"2023-03-10\\", \\"2023-03-11\\", \\"2023-03-12\\", \\"2023-03-13\\", \\"2023-03-14\\", \\"2023-03-15\\", \\"2023-03-16\\"], \\"bal\\": [999.9952000000001, 999.9928000000001, 999.9904000000001, 999.9880000000002, 999.9856000000002, 999.9832000000002, 999.9808000000003, 999.9784000000003, 999.9760000000003, 999.9736000000004, 999.9712000000004, 999.9688000000004, 999.9664000000005, 999.9640000000005, 999.9616000000005, 1099.9592000000007, 1099.9568000000006, 1099.9544000000005, 1099.9520000000005, 1099.9496000000004, 1099.9472000000003, 1099.9448000000002, 1099.9424000000001, 1099.94, 1099.9376, 1099.9352, 1099.9327999999998, 1099.9303999999997, 1099.9279999999997, 1099.9255999999996, 1099.9231999999995]}"	"{\\"tm\\": [\\"2023-02\\", \\"2023-03\\", \\"2023-04\\", \\"2023-05\\", \\"2023-06\\", \\"2023-07\\", \\"2023-08\\", \\"2023-09\\", \\"2023-10\\", \\"2023-11\\", \\"2023-12\\", \\"2024-01\\", \\"2024-02\\"], \\"bal\\": [999.9616000000005, 1099.8872000000006, 1199.8152000000007, 1299.7408000000007, 1399.6688000000008, 1499.5944000000009, 1599.520000000001, 1699.448000000001, 1799.373600000001, 1899.3016000000011, 1999.2272000000012, 2099.152800000001, 2199.0832000000014]}"	"{\\"tm\\": [\\"2023-02-13T16:30\\", \\"2023-02-13T17:30\\", \\"2023-02-13T18:30\\", \\"2023-02-13T19:30\\", \\"2023-02-13T20:30\\", \\"2023-02-13T21:30\\", \\"2023-02-13T22:30\\", \\"2023-02-13T23:30\\", \\"2023-02-14T00:30\\", \\"2023-02-14T01:30\\", \\"2023-02-14T02:30\\", \\"2023-02-14T03:30\\", \\"2023-02-14T04:30\\", \\"2023-02-14T05:30\\", \\"2023-02-14T06:30\\", \\"2023-02-14T07:30\\", \\"2023-02-14T08:30\\", \\"2023-02-14T09:30\\", \\"2023-02-14T10:30\\", \\"2023-02-14T11:30\\", \\"2023-02-14T12:30\\", \\"2023-02-14T13:30\\", \\"2023-02-14T14:30\\", \\"2023-02-14T15:30\\", \\"2023-02-14T16:30\\", \\"2023-02-14T17:30\\", \\"2023-02-14T18:30\\", \\"2023-02-14T19:30\\", \\"2023-02-14T20:30\\", \\"2023-02-14T21:30\\", \\"2023-02-14T22:30\\", \\"2023-02-14T23:30\\", \\"2023-02-15T00:30\\", \\"2023-02-15T01:30\\", \\"2023-02-15T02:30\\", \\"2023-02-15T03:30\\", \\"2023-02-15T04:30\\", \\"2023-02-15T05:30\\", \\"2023-02-15T06:30\\", \\"2023-02-15T07:30\\", \\"2023-02-15T08:30\\", \\"2023-02-15T09:30\\", \\"2023-02-15T10:30\\", \\"2023-02-15T11:30\\", \\"2023-02-15T12:30\\", \\"2023-02-15T13:30\\", \\"2023-02-15T14:30\\", \\"2023-02-15T15:30\\", \\"2023-02-15T16:30\\", \\"2023-02-15T17:30\\", \\"2023-02-15T18:30\\", \\"2023-02-15T19:30\\", \\"2023-02-15T20:30\\", \\"2023-02-15T21:30\\", \\"2023-02-15T22:30\\", \\"2023-02-15T23:30\\", \\"2023-02-16T00:30\\", \\"2023-02-16T01:30\\", \\"2023-02-16T02:30\\", \\"2023-02-16T03:30\\", \\"2023-02-16T04:30\\", \\"2023-02-16T05:30\\", \\"2023-02-16T06:30\\", \\"2023-02-16T07:30\\", \\"2023-02-16T08:30\\", \\"2023-02-16T09:30\\", \\"2023-02-16T10:30\\", \\"2023-02-16T11:30\\", \\"2023-02-16T12:30\\", \\"2023-02-16T13:30\\", \\"2023-02-16T14:30\\", \\"2023-02-16T15:30\\", \\"2023-02-16T16:30\\", \\"2023-02-16T17:30\\", \\"2023-02-16T18:30\\", \\"2023-02-16T19:30\\", \\"2023-02-16T20:30\\", \\"2023-02-16T21:30\\", \\"2023-02-16T22:30\\", \\"2023-02-16T23:30\\", \\"2023-02-17T00:30\\", \\"2023-02-17T01:30\\", \\"2023-02-17T02:30\\", \\"2023-02-17T03:30\\", \\"2023-02-17T04:30\\", \\"2023-02-17T05:30\\", \\"2023-02-17T06:30\\", \\"2023-02-17T07:30\\", \\"2023-02-17T08:30\\", \\"2023-02-17T09:30\\", \\"2023-02-17T10:30\\", \\"2023-02-17T11:30\\", \\"2023-02-17T12:30\\", \\"2023-02-17T13:30\\", \\"2023-02-17T14:30\\", \\"2023-02-17T15:30\\", \\"2023-02-17T16:30\\", \\"2023-02-17T17:30\\", \\"2023-02-17T18:30\\", \\"2023-02-17T19:30\\", \\"2023-02-17T20:30\\", \\"2023-02-17T21:30\\", \\"2023-02-17T22:30\\", \\"2023-02-17T23:30\\", \\"2023-02-18T00:30\\", \\"2023-02-18T01:30\\", \\"2023-02-18T02:30\\", \\"2023-02-18T03:30\\", \\"2023-02-18T04:30\\", \\"2023-02-18T05:30\\", \\"2023-02-18T06:30\\", \\"2023-02-18T07:30\\", \\"2023-02-18T08:30\\", \\"2023-02-18T09:30\\", \\"2023-02-18T10:30\\", \\"2023-02-18T11:30\\", \\"2023-02-18T12:30\\", \\"2023-02-18T13:30\\", \\"2023-02-18T14:30\\", \\"2023-02-18T15:30\\", \\"2023-02-18T16:30\\", \\"2023-02-18T17:30\\", \\"2023-02-18T18:30\\", \\"2023-02-18T19:30\\", \\"2023-02-18T20:30\\", \\"2023-02-18T21:30\\", \\"2023-02-18T22:30\\", \\"2023-02-18T23:30\\", \\"2023-02-19T00:30\\", \\"2023-02-19T01:30\\", \\"2023-02-19T02:30\\", \\"2023-02-19T03:30\\", \\"2023-02-19T04:30\\", \\"2023-02-19T05:30\\", \\"2023-02-19T06:30\\", \\"2023-02-19T07:30\\", \\"2023-02-19T08:30\\", \\"2023-02-19T09:30\\", \\"2023-02-19T10:30\\", \\"2023-02-19T11:30\\", \\"2023-02-19T12:30\\", \\"2023-02-19T13:30\\", \\"2023-02-19T14:30\\", \\"2023-02-19T15:30\\", \\"2023-02-19T16:30\\", \\"2023-02-19T17:30\\", \\"2023-02-19T18:30\\", \\"2023-02-19T19:30\\", \\"2023-02-19T20:30\\", \\"2023-02-19T21:30\\", \\"2023-02-19T22:30\\", \\"2023-02-19T23:30\\", \\"2023-02-20T00:30\\", \\"2023-02-20T01:30\\", \\"2023-02-20T02:30\\", \\"2023-02-20T03:30\\", \\"2023-02-20T04:30\\", \\"2023-02-20T05:30\\", \\"2023-02-20T06:30\\", \\"2023-02-20T07:30\\", \\"2023-02-20T08:30\\", \\"2023-02-20T09:30\\", \\"2023-02-20T10:30\\", \\"2023-02-20T11:30\\", \\"2023-02-20T12:30\\", \\"2023-02-20T13:30\\", \\"2023-02-20T14:30\\", \\"2023-02-20T15:30\\", \\"2023-02-20T16:30\\", \\"2023-02-20T17:30\\", \\"2023-02-20T18:30\\", \\"2023-02-20T19:30\\", \\"2023-02-20T20:30\\", \\"2023-02-20T21:30\\", \\"2023-02-20T22:30\\", \\"2023-02-20T23:30\\", \\"2023-02-21T00:30\\", \\"2023-02-21T01:30\\", \\"2023-02-21T02:30\\", \\"2023-02-21T03:30\\", \\"2023-02-21T04:30\\", \\"2023-02-21T05:30\\", \\"2023-02-21T06:30\\", \\"2023-02-21T07:30\\", \\"2023-02-21T08:30\\", \\"2023-02-21T09:30\\", \\"2023-02-21T10:30\\", \\"2023-02-21T11:30\\", \\"2023-02-21T12:30\\", \\"2023-02-21T13:30\\", \\"2023-02-21T14:30\\", \\"2023-02-21T15:30\\", \\"2023-02-21T16:30\\", \\"2023-02-21T17:30\\", \\"2023-02-21T18:30\\", \\"2023-02-21T19:30\\", \\"2023-02-21T20:30\\", \\"2023-02-21T21:30\\", \\"2023-02-21T22:30\\", \\"2023-02-21T23:30\\", \\"2023-02-22T00:30\\", \\"2023-02-22T01:30\\", \\"2023-02-22T02:30\\", \\"2023-02-22T03:30\\", \\"2023-02-22T04:30\\", \\"2023-02-22T05:30\\", \\"2023-02-22T06:30\\", \\"2023-02-22T07:30\\", \\"2023-02-22T08:30\\", \\"2023-02-22T09:30\\", \\"2023-02-22T10:30\\", \\"2023-02-22T11:30\\", \\"2023-02-22T12:30\\", \\"2023-02-22T13:30\\", \\"2023-02-22T14:30\\", \\"2023-02-22T15:30\\", \\"2023-02-22T16:30\\", \\"2023-02-22T17:30\\", \\"2023-02-22T18:30\\", \\"2023-02-22T19:30\\", \\"2023-02-22T20:30\\", \\"2023-02-22T21:30\\", \\"2023-02-22T22:30\\", \\"2023-02-22T23:30\\", \\"2023-02-23T00:30\\", \\"2023-02-23T01:30\\", \\"2023-02-23T02:30\\", \\"2023-02-23T03:30\\", \\"2023-02-23T04:30\\", \\"2023-02-23T05:30\\", \\"2023-02-23T06:30\\", \\"2023-02-23T07:30\\", \\"2023-02-23T08:30\\", \\"2023-02-23T09:30\\", \\"2023-02-23T10:30\\", \\"2023-02-23T11:30\\", \\"2023-02-23T12:30\\", \\"2023-02-23T13:30\\", \\"2023-02-23T14:30\\", \\"2023-02-23T15:30\\", \\"2023-02-23T16:30\\", \\"2023-02-23T17:30\\", \\"2023-02-23T18:30\\", \\"2023-02-23T19:30\\", \\"2023-02-23T20:30\\", \\"2023-02-23T21:30\\", \\"2023-02-23T22:30\\", \\"2023-02-23T23:30\\", \\"2023-02-24T00:30\\", \\"2023-02-24T01:30\\", \\"2023-02-24T02:30\\", \\"2023-02-24T03:30\\", \\"2023-02-24T04:30\\", \\"2023-02-24T05:30\\", \\"2023-02-24T06:30\\", \\"2023-02-24T07:30\\", \\"2023-02-24T08:30\\", \\"2023-02-24T09:30\\", \\"2023-02-24T10:30\\", \\"2023-02-24T11:30\\", \\"2023-02-24T12:30\\", \\"2023-02-24T13:30\\", \\"2023-02-24T14:30\\", \\"2023-02-24T15:30\\", \\"2023-02-24T16:30\\", \\"2023-02-24T17:30\\", \\"2023-02-24T18:30\\", \\"2023-02-24T19:30\\", \\"2023-02-24T20:30\\", \\"2023-02-24T21:30\\", \\"2023-02-24T22:30\\", \\"2023-02-24T23:30\\", \\"2023-02-25T00:30\\", \\"2023-02-25T01:30\\", \\"2023-02-25T02:30\\", \\"2023-02-25T03:30\\", \\"2023-02-25T04:30\\", \\"2023-02-25T05:30\\", \\"2023-02-25T06:30\\", \\"2023-02-25T07:30\\", \\"2023-02-25T08:30\\", \\"2023-02-25T09:30\\", \\"2023-02-25T10:30\\", \\"2023-02-25T11:30\\", \\"2023-02-25T12:30\\", \\"2023-02-25T13:30\\", \\"2023-02-25T14:30\\", \\"2023-02-25T15:30\\", \\"2023-02-25T16:30\\", \\"2023-02-25T17:30\\", \\"2023-02-25T18:30\\", \\"2023-02-25T19:30\\", \\"2023-02-25T20:30\\", \\"2023-02-25T21:30\\", \\"2023-02-25T22:30\\", \\"2023-02-25T23:30\\", \\"2023-02-26T00:30\\", \\"2023-02-26T01:30\\", \\"2023-02-26T02:30\\", \\"2023-02-26T03:30\\", \\"2023-02-26T04:30\\", \\"2023-02-26T05:30\\", \\"2023-02-26T06:30\\", \\"2023-02-26T07:30\\", \\"2023-02-26T08:30\\", \\"2023-02-26T09:30\\", \\"2023-02-26T10:30\\", \\"2023-02-26T11:30\\", \\"2023-02-26T12:30\\", \\"2023-02-26T13:30\\", \\"2023-02-26T14:30\\", \\"2023-02-26T15:30\\", \\"2023-02-26T16:30\\", \\"2023-02-26T17:30\\", \\"2023-02-26T18:30\\", \\"2023-02-26T19:30\\", \\"2023-02-26T20:30\\", \\"2023-02-26T21:30\\", \\"2023-02-26T22:30\\", \\"2023-02-26T23:30\\", \\"2023-02-27T00:30\\", \\"2023-02-27T01:30\\", \\"2023-02-27T02:30\\", \\"2023-02-27T03:30\\", \\"2023-02-27T04:30\\", \\"2023-02-27T05:30\\", \\"2023-02-27T06:30\\", \\"2023-02-27T07:30\\", \\"2023-02-27T08:30\\", \\"2023-02-27T09:30\\", \\"2023-02-27T10:30\\", \\"2023-02-27T11:30\\", \\"2023-02-27T12:30\\", \\"2023-02-27T13:30\\", \\"2023-02-27T14:30\\", \\"2023-02-27T15:30\\"], \\"bal\\": [999.9999, 999.9998, 999.9997000000001, 999.9996000000001, 999.9995000000001, 999.9994000000002, 999.9993000000002, 999.9992000000002, 999.9991000000002, 999.9990000000003, 999.9989000000003, 999.9988000000003, 999.9987000000003, 999.9986000000004, 999.9985000000004, 999.9984000000004, 999.9983000000004, 999.9982000000005, 999.9981000000005, 999.9980000000005, 999.9979000000005, 999.9978000000006, 999.9977000000006, 999.9976000000006, 999.9975000000006, 999.9974000000007, 999.9973000000007, 999.9972000000007, 999.9971000000007, 999.9970000000008, 999.9969000000008, 999.9968000000008, 999.9967000000008, 999.9966000000009, 999.9965000000009, 999.9964000000009, 999.9963000000009, 999.996200000001, 999.996100000001, 999.996000000001, 999.995900000001, 999.995800000001, 999.9957000000011, 999.9956000000011, 999.9955000000011, 999.9954000000012, 999.9953000000012, 999.9952000000012, 999.9951000000012, 999.9950000000013, 999.9949000000013, 999.9948000000013, 999.9947000000013, 999.9946000000014, 999.9945000000014, 999.9944000000014, 999.9943000000014, 999.9942000000015, 999.9941000000015, 999.9940000000015, 999.9939000000015, 999.9938000000016, 999.9937000000016, 999.9936000000016, 999.9935000000016, 999.9934000000017, 999.9933000000017, 999.9932000000017, 999.9931000000017, 999.9930000000018, 999.9929000000018, 999.9928000000018, 999.9927000000018, 999.9926000000019, 999.9925000000019, 999.9924000000019, 999.9923000000019, 999.992200000002, 999.992100000002, 999.992000000002, 999.991900000002, 999.9918000000021, 999.9917000000021, 999.9916000000021, 999.9915000000021, 999.9914000000022, 999.9913000000022, 999.9912000000022, 999.9911000000022, 999.9910000000023, 999.9909000000023, 999.9908000000023, 999.9907000000023, 999.9906000000024, 999.9905000000024, 999.9904000000024, 999.9903000000024, 999.9902000000025, 999.9901000000025, 999.9900000000025, 999.9899000000025, 999.9898000000026, 999.9897000000026, 999.9896000000026, 999.9895000000026, 999.9894000000027, 999.9893000000027, 999.9892000000027, 999.9891000000027, 999.9890000000028, 999.9889000000028, 999.9888000000028, 999.9887000000028, 999.9886000000029, 999.9885000000029, 999.9884000000029, 999.9883000000029, 999.988200000003, 999.988100000003, 999.988000000003, 999.987900000003, 999.9878000000031, 999.9877000000031, 999.9876000000031, 999.9875000000031, 999.9874000000032, 999.9873000000032, 999.9872000000032, 999.9871000000032, 999.9870000000033, 999.9869000000033, 999.9868000000033, 999.9867000000033, 999.9866000000034, 999.9865000000034, 999.9864000000034, 999.9863000000034, 999.9862000000035, 999.9861000000035, 999.9860000000035, 999.9859000000035, 999.9858000000036, 999.9857000000036, 999.9856000000036, 999.9855000000036, 999.9854000000037, 999.9853000000037, 999.9852000000037, 999.9851000000037, 999.9850000000038, 999.9849000000038, 999.9848000000038, 999.9847000000038, 999.9846000000039, 999.9845000000039, 999.9844000000039, 999.9843000000039, 999.984200000004, 999.984100000004, 999.984000000004, 999.983900000004, 999.9838000000041, 999.9837000000041, 999.9836000000041, 999.9835000000041, 999.9834000000042, 999.9833000000042, 999.9832000000042, 999.9831000000042, 999.9830000000043, 999.9829000000043, 999.9828000000043, 999.9827000000043, 999.9826000000044, 999.9825000000044, 999.9824000000044, 999.9823000000044, 999.9822000000045, 999.9821000000045, 999.9820000000045, 999.9819000000045, 999.9818000000046, 999.9817000000046, 999.9816000000046, 999.9815000000046, 999.9814000000047, 999.9813000000047, 999.9812000000047, 999.9811000000047, 999.9810000000048, 999.9809000000048, 999.9808000000048, 999.9807000000048, 999.9806000000049, 999.9805000000049, 999.9804000000049, 999.980300000005, 999.980200000005, 999.980100000005, 999.980000000005, 999.979900000005, 999.9798000000051, 999.9797000000051, 999.9796000000051, 999.9795000000051, 999.9794000000052, 999.9793000000052, 999.9792000000052, 999.9791000000052, 999.9790000000053, 999.9789000000053, 999.9788000000053, 999.9787000000053, 999.9786000000054, 999.9785000000054, 999.9784000000054, 999.9783000000054, 999.9782000000055, 999.9781000000055, 999.9780000000055, 999.9779000000055, 999.9778000000056, 999.9777000000056, 999.9776000000056, 999.9775000000056, 999.9774000000057, 999.9773000000057, 999.9772000000057, 999.9771000000057, 999.9770000000058, 999.9769000000058, 999.9768000000058, 999.9767000000058, 999.9766000000059, 999.9765000000059, 999.9764000000059, 999.976300000006, 999.976200000006, 999.976100000006, 999.976000000006, 999.975900000006, 999.9758000000061, 999.9757000000061, 999.9756000000061, 999.9755000000062, 999.9754000000062, 999.9753000000062, 999.9752000000062, 999.9751000000063, 999.9750000000063, 999.9749000000063, 999.9748000000063, 999.9747000000064, 999.9746000000064, 999.9745000000064, 999.9744000000064, 999.9743000000065, 999.9742000000065, 999.9741000000065, 999.9740000000065, 999.9739000000066, 999.9738000000066, 999.9737000000066, 999.9736000000066, 999.9735000000067, 999.9734000000067, 999.9733000000067, 999.9732000000067, 999.9731000000068, 999.9730000000068, 999.9729000000068, 999.9728000000068, 999.9727000000069, 999.9726000000069, 999.9725000000069, 999.9724000000069, 999.972300000007, 999.972200000007, 999.972100000007, 999.972000000007, 999.971900000007, 999.9718000000071, 999.9717000000071, 999.9716000000071, 999.9715000000072, 999.9714000000072, 999.9713000000072, 999.9712000000072, 999.9711000000073, 999.9710000000073, 999.9709000000073, 999.9708000000073, 999.9707000000074, 999.9706000000074, 999.9705000000074, 999.9704000000074, 999.9703000000075, 999.9702000000075, 999.9701000000075, 999.9700000000075, 999.9699000000076, 999.9698000000076, 999.9697000000076, 999.9696000000076, 999.9695000000077, 999.9694000000077, 999.9693000000077, 999.9692000000077, 999.9691000000078, 999.9690000000078, 999.9689000000078, 999.9688000000078, 999.9687000000079, 999.9686000000079, 999.9685000000079, 999.9684000000079, 999.968300000008, 999.968200000008, 999.968100000008, 999.968000000008, 999.9679000000081, 999.9678000000081, 999.9677000000081, 999.9676000000081, 999.9675000000082, 999.9674000000082, 999.9673000000082, 999.9672000000082, 999.9671000000083, 999.9670000000083, 999.9669000000083, 999.9668000000083, 999.9667000000084, 999.9666000000084, 999.9665000000084, 999.9664000000084]}"	"{\\"tm\\": [\\"2023-02-14\\", \\"2023-02-15\\", \\"2023-02-16\\", \\"2023-02-17\\", \\"2023-02-18\\", \\"2023-02-19\\", \\"2023-02-20\\", \\"2023-02-21\\", \\"2023-02-22\\", \\"2023-02-23\\", \\"2023-02-24\\", \\"2023-02-25\\", \\"2023-02-26\\", \\"2023-02-27\\", \\"2023-02-28\\", \\"2023-03-01\\", \\"2023-03-02\\", \\"2023-03-03\\", \\"2023-03-04\\", \\"2023-03-05\\", \\"2023-03-06\\", \\"2023-03-07\\", \\"2023-03-08\\", \\"2023-03-09\\", \\"2023-03-10\\", \\"2023-03-11\\", \\"2023-03-12\\", \\"2023-03-13\\", \\"2023-03-14\\", \\"2023-03-15\\", \\"2023-03-16\\"], \\"bal\\": [999.9952000000001, 999.9928000000001, 999.9904000000001, 999.9880000000002, 999.9856000000002, 999.9832000000002, 999.9808000000003, 999.9784000000003, 999.9760000000003, 999.9736000000004, 999.9712000000004, 999.9688000000004, 999.9664000000005, 999.9640000000005, 999.9616000000005, 1099.9592000000007, 1099.9568000000006, 1099.9544000000005, 1099.9520000000005, 1099.9496000000004, 1099.9472000000003, 1099.9448000000002, 1099.9424000000001, 1099.94, 1099.9376, 1099.9352, 1099.9327999999998, 1099.9303999999997, 1099.9279999999997, 1099.9255999999996, 1099.9231999999995]}"	"{\\"tm\\": [\\"2023-02\\", \\"2023-03\\", \\"2023-04\\", \\"2023-05\\", \\"2023-06\\", \\"2023-07\\", \\"2023-08\\", \\"2023-09\\", \\"2023-10\\", \\"2023-11\\", \\"2023-12\\", \\"2024-01\\", \\"2024-02\\"], \\"bal\\": [999.9616000000005, 1099.8872000000006, 1199.8152000000007, 1299.7408000000007, 1399.6688000000008, 1499.5944000000009, 1599.520000000001, 1699.448000000001, 1799.373600000001, 1899.3016000000011, 1999.2272000000012, 2099.152800000001, 2199.0832000000014]}"	"{\\"tm\\": [\\"2023-02-13T16:30\\", \\"2023-02-13T17:30\\", \\"2023-02-13T18:30\\", \\"2023-02-13T19:30\\", \\"2023-02-13T20:30\\", \\"2023-02-13T21:30\\", \\"2023-02-13T22:30\\", \\"2023-02-13T23:30\\", \\"2023-02-14T00:30\\", \\"2023-02-14T01:30\\", \\"2023-02-14T02:30\\", \\"2023-02-14T03:30\\", \\"2023-02-14T04:30\\", \\"2023-02-14T05:30\\", \\"2023-02-14T06:30\\", \\"2023-02-14T07:30\\", \\"2023-02-14T08:30\\", \\"2023-02-14T09:30\\", \\"2023-02-14T10:30\\", \\"2023-02-14T11:30\\", \\"2023-02-14T12:30\\", \\"2023-02-14T13:30\\", \\"2023-02-14T14:30\\", \\"2023-02-14T15:30\\", \\"2023-02-14T16:30\\", \\"2023-02-14T17:30\\", \\"2023-02-14T18:30\\", \\"2023-02-14T19:30\\", \\"2023-02-14T20:30\\", \\"2023-02-14T21:30\\", \\"2023-02-14T22:30\\", \\"2023-02-14T23:30\\", \\"2023-02-15T00:30\\", \\"2023-02-15T01:30\\", \\"2023-02-15T02:30\\", \\"2023-02-15T03:30\\", \\"2023-02-15T04:30\\", \\"2023-02-15T05:30\\", \\"2023-02-15T06:30\\", \\"2023-02-15T07:30\\", \\"2023-02-15T08:30\\", \\"2023-02-15T09:30\\", \\"2023-02-15T10:30\\", \\"2023-02-15T11:30\\", \\"2023-02-15T12:30\\", \\"2023-02-15T13:30\\", \\"2023-02-15T14:30\\", \\"2023-02-15T15:30\\", \\"2023-02-15T16:30\\", \\"2023-02-15T17:30\\", \\"2023-02-15T18:30\\", \\"2023-02-15T19:30\\", \\"2023-02-15T20:30\\", \\"2023-02-15T21:30\\", \\"2023-02-15T22:30\\", \\"2023-02-15T23:30\\", \\"2023-02-16T00:30\\", \\"2023-02-16T01:30\\", \\"2023-02-16T02:30\\", \\"2023-02-16T03:30\\", \\"2023-02-16T04:30\\", \\"2023-02-16T05:30\\", \\"2023-02-16T06:30\\", \\"2023-02-16T07:30\\", \\"2023-02-16T08:30\\", \\"2023-02-16T09:30\\", \\"2023-02-16T10:30\\", \\"2023-02-16T11:30\\", \\"2023-02-16T12:30\\", \\"2023-02-16T13:30\\", \\"2023-02-16T14:30\\", \\"2023-02-16T15:30\\", \\"2023-02-16T16:30\\", \\"2023-02-16T17:30\\", \\"2023-02-16T18:30\\", \\"2023-02-16T19:30\\", \\"2023-02-16T20:30\\", \\"2023-02-16T21:30\\", \\"2023-02-16T22:30\\", \\"2023-02-16T23:30\\", \\"2023-02-17T00:30\\", \\"2023-02-17T01:30\\", \\"2023-02-17T02:30\\", \\"2023-02-17T03:30\\", \\"2023-02-17T04:30\\", \\"2023-02-17T05:30\\", \\"2023-02-17T06:30\\", \\"2023-02-17T07:30\\", \\"2023-02-17T08:30\\", \\"2023-02-17T09:30\\", \\"2023-02-17T10:30\\", \\"2023-02-17T11:30\\", \\"2023-02-17T12:30\\", \\"2023-02-17T13:30\\", \\"2023-02-17T14:30\\", \\"2023-02-17T15:30\\", \\"2023-02-17T16:30\\", \\"2023-02-17T17:30\\", \\"2023-02-17T18:30\\", \\"2023-02-17T19:30\\", \\"2023-02-17T20:30\\", \\"2023-02-17T21:30\\", \\"2023-02-17T22:30\\", \\"2023-02-17T23:30\\", \\"2023-02-18T00:30\\", \\"2023-02-18T01:30\\", \\"2023-02-18T02:30\\", \\"2023-02-18T03:30\\", \\"2023-02-18T04:30\\", \\"2023-02-18T05:30\\", \\"2023-02-18T06:30\\", \\"2023-02-18T07:30\\", \\"2023-02-18T08:30\\", \\"2023-02-18T09:30\\", \\"2023-02-18T10:30\\", \\"2023-02-18T11:30\\", \\"2023-02-18T12:30\\", \\"2023-02-18T13:30\\", \\"2023-02-18T14:30\\", \\"2023-02-18T15:30\\", \\"2023-02-18T16:30\\", \\"2023-02-18T17:30\\", \\"2023-02-18T18:30\\", \\"2023-02-18T19:30\\", \\"2023-02-18T20:30\\", \\"2023-02-18T21:30\\", \\"2023-02-18T22:30\\", \\"2023-02-18T23:30\\", \\"2023-02-19T00:30\\", \\"2023-02-19T01:30\\", \\"2023-02-19T02:30\\", \\"2023-02-19T03:30\\", \\"2023-02-19T04:30\\", \\"2023-02-19T05:30\\", \\"2023-02-19T06:30\\", \\"2023-02-19T07:30\\", \\"2023-02-19T08:30\\", \\"2023-02-19T09:30\\", \\"2023-02-19T10:30\\", \\"2023-02-19T11:30\\", \\"2023-02-19T12:30\\", \\"2023-02-19T13:30\\", \\"2023-02-19T14:30\\", \\"2023-02-19T15:30\\", \\"2023-02-19T16:30\\", \\"2023-02-19T17:30\\", \\"2023-02-19T18:30\\", \\"2023-02-19T19:30\\", \\"2023-02-19T20:30\\", \\"2023-02-19T21:30\\", \\"2023-02-19T22:30\\", \\"2023-02-19T23:30\\", \\"2023-02-20T00:30\\", \\"2023-02-20T01:30\\", \\"2023-02-20T02:30\\", \\"2023-02-20T03:30\\", \\"2023-02-20T04:30\\", \\"2023-02-20T05:30\\", \\"2023-02-20T06:30\\", \\"2023-02-20T07:30\\", \\"2023-02-20T08:30\\", \\"2023-02-20T09:30\\", \\"2023-02-20T10:30\\", \\"2023-02-20T11:30\\", \\"2023-02-20T12:30\\", \\"2023-02-20T13:30\\", \\"2023-02-20T14:30\\", \\"2023-02-20T15:30\\", \\"2023-02-20T16:30\\", \\"2023-02-20T17:30\\", \\"2023-02-20T18:30\\", \\"2023-02-20T19:30\\", \\"2023-02-20T20:30\\", \\"2023-02-20T21:30\\", \\"2023-02-20T22:30\\", \\"2023-02-20T23:30\\", \\"2023-02-21T00:30\\", \\"2023-02-21T01:30\\", \\"2023-02-21T02:30\\", \\"2023-02-21T03:30\\", \\"2023-02-21T04:30\\", \\"2023-02-21T05:30\\", \\"2023-02-21T06:30\\", \\"2023-02-21T07:30\\", \\"2023-02-21T08:30\\", \\"2023-02-21T09:30\\", \\"2023-02-21T10:30\\", \\"2023-02-21T11:30\\", \\"2023-02-21T12:30\\", \\"2023-02-21T13:30\\", \\"2023-02-21T14:30\\", \\"2023-02-21T15:30\\", \\"2023-02-21T16:30\\", \\"2023-02-21T17:30\\", \\"2023-02-21T18:30\\", \\"2023-02-21T19:30\\", \\"2023-02-21T20:30\\", \\"2023-02-21T21:30\\", \\"2023-02-21T22:30\\", \\"2023-02-21T23:30\\", \\"2023-02-22T00:30\\", \\"2023-02-22T01:30\\", \\"2023-02-22T02:30\\", \\"2023-02-22T03:30\\", \\"2023-02-22T04:30\\", \\"2023-02-22T05:30\\", \\"2023-02-22T06:30\\", \\"2023-02-22T07:30\\", \\"2023-02-22T08:30\\", \\"2023-02-22T09:30\\", \\"2023-02-22T10:30\\", \\"2023-02-22T11:30\\", \\"2023-02-22T12:30\\", \\"2023-02-22T13:30\\", \\"2023-02-22T14:30\\", \\"2023-02-22T15:30\\", \\"2023-02-22T16:30\\", \\"2023-02-22T17:30\\", \\"2023-02-22T18:30\\", \\"2023-02-22T19:30\\", \\"2023-02-22T20:30\\", \\"2023-02-22T21:30\\", \\"2023-02-22T22:30\\", \\"2023-02-22T23:30\\", \\"2023-02-23T00:30\\", \\"2023-02-23T01:30\\", \\"2023-02-23T02:30\\", \\"2023-02-23T03:30\\", \\"2023-02-23T04:30\\", \\"2023-02-23T05:30\\", \\"2023-02-23T06:30\\", \\"2023-02-23T07:30\\", \\"2023-02-23T08:30\\", \\"2023-02-23T09:30\\", \\"2023-02-23T10:30\\", \\"2023-02-23T11:30\\", \\"2023-02-23T12:30\\", \\"2023-02-23T13:30\\", \\"2023-02-23T14:30\\", \\"2023-02-23T15:30\\", \\"2023-02-23T16:30\\", \\"2023-02-23T17:30\\", \\"2023-02-23T18:30\\", \\"2023-02-23T19:30\\", \\"2023-02-23T20:30\\", \\"2023-02-23T21:30\\", \\"2023-02-23T22:30\\", \\"2023-02-23T23:30\\", \\"2023-02-24T00:30\\", \\"2023-02-24T01:30\\", \\"2023-02-24T02:30\\", \\"2023-02-24T03:30\\", \\"2023-02-24T04:30\\", \\"2023-02-24T05:30\\", \\"2023-02-24T06:30\\", \\"2023-02-24T07:30\\", \\"2023-02-24T08:30\\", \\"2023-02-24T09:30\\", \\"2023-02-24T10:30\\", \\"2023-02-24T11:30\\", \\"2023-02-24T12:30\\", \\"2023-02-24T13:30\\", \\"2023-02-24T14:30\\", \\"2023-02-24T15:30\\", \\"2023-02-24T16:30\\", \\"2023-02-24T17:30\\", \\"2023-02-24T18:30\\", \\"2023-02-24T19:30\\", \\"2023-02-24T20:30\\", \\"2023-02-24T21:30\\", \\"2023-02-24T22:30\\", \\"2023-02-24T23:30\\", \\"2023-02-25T00:30\\", \\"2023-02-25T01:30\\", \\"2023-02-25T02:30\\", \\"2023-02-25T03:30\\", \\"2023-02-25T04:30\\", \\"2023-02-25T05:30\\", \\"2023-02-25T06:30\\", \\"2023-02-25T07:30\\", \\"2023-02-25T08:30\\", \\"2023-02-25T09:30\\", \\"2023-02-25T10:30\\", \\"2023-02-25T11:30\\", \\"2023-02-25T12:30\\", \\"2023-02-25T13:30\\", \\"2023-02-25T14:30\\", \\"2023-02-25T15:30\\", \\"2023-02-25T16:30\\", \\"2023-02-25T17:30\\", \\"2023-02-25T18:30\\", \\"2023-02-25T19:30\\", \\"2023-02-25T20:30\\", \\"2023-02-25T21:30\\", \\"2023-02-25T22:30\\", \\"2023-02-25T23:30\\", \\"2023-02-26T00:30\\", \\"2023-02-26T01:30\\", \\"2023-02-26T02:30\\", \\"2023-02-26T03:30\\", \\"2023-02-26T04:30\\", \\"2023-02-26T05:30\\", \\"2023-02-26T06:30\\", \\"2023-02-26T07:30\\", \\"2023-02-26T08:30\\", \\"2023-02-26T09:30\\", \\"2023-02-26T10:30\\", \\"2023-02-26T11:30\\", \\"2023-02-26T12:30\\", \\"2023-02-26T13:30\\", \\"2023-02-26T14:30\\", \\"2023-02-26T15:30\\", \\"2023-02-26T16:30\\", \\"2023-02-26T17:30\\", \\"2023-02-26T18:30\\", \\"2023-02-26T19:30\\", \\"2023-02-26T20:30\\", \\"2023-02-26T21:30\\", \\"2023-02-26T22:30\\", \\"2023-02-26T23:30\\", \\"2023-02-27T00:30\\", \\"2023-02-27T01:30\\", \\"2023-02-27T02:30\\", \\"2023-02-27T03:30\\", \\"2023-02-27T04:30\\", \\"2023-02-27T05:30\\", \\"2023-02-27T06:30\\", \\"2023-02-27T07:30\\", \\"2023-02-27T08:30\\", \\"2023-02-27T09:30\\", \\"2023-02-27T10:30\\", \\"2023-02-27T11:30\\", \\"2023-02-27T12:30\\", \\"2023-02-27T13:30\\", \\"2023-02-27T14:30\\", \\"2023-02-27T15:30\\"], \\"bal\\": [997.587, 995.174, 992.761, 990.348, 987.935, 985.5219999999999, 983.1089999999999, 980.6959999999999, 978.2829999999999, 975.8699999999999, 973.4569999999999, 971.0439999999999, 968.6309999999999, 966.2179999999998, 963.8049999999998, 961.3919999999998, 958.9789999999998, 956.5659999999998, 954.1529999999998, 951.7399999999998, 949.3269999999998, 946.9139999999998, 944.5009999999997, 942.0879999999997, 939.6749999999997, 937.2619999999997, 934.8489999999997, 932.4359999999997, 930.0229999999997, 927.6099999999997, 925.1969999999997, 922.7839999999997, 920.3709999999996, 917.9579999999996, 915.5449999999996, 913.1319999999996, 910.7189999999996, 908.3059999999996, 905.8929999999996, 903.4799999999996, 901.0669999999996, 898.6539999999995, 896.2409999999995, 893.8279999999995, 891.4149999999995, 889.0019999999995, 886.5889999999995, 884.1759999999995, 881.7629999999995, 879.3499999999995, 876.9369999999994, 874.5239999999994, 872.1109999999994, 869.6979999999994, 867.2849999999994, 864.8719999999994, 862.4589999999994, 860.0459999999994, 857.6329999999994, 855.2199999999993, 852.8069999999993, 850.3939999999993, 847.9809999999993, 845.5679999999993, 843.1549999999993, 840.7419999999993, 838.3289999999993, 835.9159999999993, 833.5029999999992, 831.0899999999992, 828.6769999999992, 826.2639999999992, 823.8509999999992, 821.4379999999992, 819.0249999999992, 816.6119999999992, 814.1989999999992, 811.7859999999991, 809.3729999999991, 806.9599999999991, 804.5469999999991, 802.1339999999991, 799.7209999999991, 797.3079999999991, 794.8949999999991, 792.4819999999991, 790.068999999999, 787.655999999999, 785.242999999999, 782.829999999999, 780.416999999999, 778.003999999999, 775.590999999999, 773.177999999999, 770.764999999999, 768.351999999999, 765.9389999999989, 763.5259999999989, 761.1129999999989, 758.6999999999989, 756.2869999999989, 753.8739999999989, 751.4609999999989, 749.0479999999989, 746.6349999999989, 744.2219999999988, 741.8089999999988, 739.3959999999988, 736.9829999999988, 734.5699999999988, 732.1569999999988, 729.7439999999988, 727.3309999999988, 724.9179999999988, 722.5049999999987, 720.0919999999987, 717.6789999999987, 715.2659999999987, 712.8529999999987, 710.4399999999987, 708.0269999999987, 705.6139999999987, 703.2009999999987, 700.7879999999986, 698.3749999999986, 695.9619999999986, 693.5489999999986, 691.1359999999986, 688.7229999999986, 686.3099999999986, 683.8969999999986, 681.4839999999986, 679.0709999999985, 676.6579999999985, 674.2449999999985, 671.8319999999985, 669.4189999999985, 667.0059999999985, 664.5929999999985, 662.1799999999985, 659.7669999999985, 657.3539999999985, 654.9409999999984, 652.5279999999984, 650.1149999999984, 647.7019999999984, 645.2889999999984, 642.8759999999984, 640.4629999999984, 638.0499999999984, 635.6369999999984, 633.2239999999983, 630.8109999999983, 628.3979999999983, 625.9849999999983, 623.5719999999983, 621.1589999999983, 618.7459999999983, 616.3329999999983, 613.9199999999983, 611.5069999999982, 609.0939999999982, 606.6809999999982, 604.2679999999982, 601.8549999999982, 599.4419999999982, 597.0289999999982, 594.6159999999982, 592.2029999999982, 589.7899999999981, 587.3769999999981, 584.9639999999981, 582.5509999999981, 580.1379999999981, 577.7249999999981, 575.3119999999981, 572.8989999999981, 570.4859999999981, 568.072999999998, 565.659999999998, 563.246999999998, 560.833999999998, 558.420999999998, 556.007999999998, 553.594999999998, 551.181999999998, 548.768999999998, 546.355999999998, 543.9429999999979, 541.5299999999979, 539.1169999999979, 536.7039999999979, 534.2909999999979, 531.8779999999979, 529.4649999999979, 527.0519999999979, 524.6389999999978, 522.2259999999978, 519.8129999999978, 517.3999999999978, 514.9869999999978, 512.5739999999978, 510.1609999999978, 507.7479999999978, 505.33499999999776, 502.92199999999775, 500.50899999999774, 498.09599999999773, 495.6829999999977, 493.2699999999977, 490.8569999999977, 488.4439999999977, 486.0309999999977, 483.61799999999766, 481.20499999999765, 478.79199999999764, 476.37899999999763, 473.9659999999976, 471.5529999999976, 469.1399999999976, 466.7269999999976, 464.3139999999976, 461.90099999999757, 459.48799999999756, 457.07499999999754, 454.66199999999753, 452.2489999999975, 449.8359999999975, 447.4229999999975, 445.0099999999975, 442.5969999999975, 440.18399999999747, 437.77099999999746, 435.35799999999745, 432.94499999999744, 430.5319999999974, 428.1189999999974, 425.7059999999974, 423.2929999999974, 420.8799999999974, 418.46699999999737, 416.05399999999736, 413.64099999999735, 411.22799999999734, 408.8149999999973, 406.4019999999973, 403.9889999999973, 401.5759999999973, 399.1629999999973, 396.74999999999727, 394.33699999999726, 391.92399999999725, 389.51099999999724, 387.0979999999972, 384.6849999999972, 382.2719999999972, 379.8589999999972, 377.4459999999972, 375.0329999999972, 372.61999999999716, 370.20699999999715, 367.79399999999714, 365.38099999999713, 362.9679999999971, 360.5549999999971, 358.1419999999971, 355.7289999999971, 353.3159999999971, 350.90299999999706, 348.48999999999705, 346.07699999999704, 343.66399999999703, 341.250999999997, 338.837999999997, 336.424999999997, 334.011999999997, 331.598999999997, 329.18599999999697, 326.77299999999696, 324.35999999999694, 321.94699999999693, 319.5339999999969, 317.1209999999969, 314.7079999999969, 312.2949999999969, 309.8819999999969, 307.46899999999687, 305.05599999999686, 302.64299999999685, 300.22999999999683, 297.8169999999968, 295.4039999999968, 292.9909999999968, 290.5779999999968, 288.1649999999968, 285.75199999999677, 283.33899999999676, 280.92599999999675, 278.51299999999674, 276.0999999999967, 273.6869999999967, 271.2739999999967, 268.8609999999967, 266.4479999999967, 264.03499999999667, 261.62199999999666, 259.20899999999665, 256.79599999999664, 254.38299999999663, 251.96999999999662, 249.5569999999966, 247.1439999999966, 244.73099999999658, 242.31799999999657, 239.90499999999656, 237.49199999999655, 235.07899999999654, 232.66599999999653, 230.25299999999652, 227.8399999999965, 225.4269999999965, 223.01399999999649, 220.60099999999647, 218.18799999999646, 215.77499999999645, 213.36199999999644, 210.94899999999643, 208.53599999999642, 206.1229999999964, 203.7099999999964, 201.2969999999964, 198.88399999999638, 196.47099999999637, 194.05799999999635, 191.64499999999634, 189.23199999999633]}"	"{\\"tm\\": [\\"2023-02-14\\", \\"2023-02-15\\", \\"2023-02-16\\", \\"2023-02-17\\", \\"2023-02-18\\", \\"2023-02-19\\", \\"2023-02-20\\", \\"2023-02-21\\", \\"2023-02-22\\", \\"2023-02-23\\", \\"2023-02-24\\", \\"2023-02-25\\", \\"2023-02-26\\", \\"2023-02-27\\", \\"2023-02-28\\", \\"2023-03-01\\", \\"2023-03-02\\", \\"2023-03-03\\", \\"2023-03-04\\", \\"2023-03-05\\", \\"2023-03-06\\", \\"2023-03-07\\", \\"2023-03-08\\", \\"2023-03-09\\", \\"2023-03-10\\", \\"2023-03-11\\", \\"2023-03-12\\", \\"2023-03-13\\", \\"2023-03-14\\", \\"2023-03-15\\", \\"2023-03-16\\"], \\"bal\\": [884.1759999999999, 826.2639999999999, 768.3519999999999, 710.4399999999998, 652.5279999999998, 594.6159999999998, 536.7039999999997, 478.7919999999997, 420.87999999999965, 362.9679999999996, 305.0559999999996, 247.14399999999958, 189.23199999999957, 131.31999999999957, 73.40799999999956, 115.49599999999955, 57.58399999999955, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]}"	"{\\"tm\\": [\\"2023-02\\", \\"2023-03\\", \\"2023-04\\", \\"2023-05\\", \\"2023-06\\", \\"2023-07\\", \\"2023-08\\", \\"2023-09\\", \\"2023-10\\", \\"2023-11\\", \\"2023-12\\", \\"2024-01\\", \\"2024-02\\"], \\"bal\\": [73.40799999999956, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]}"	latest	sliderule_1492	3	{}	2023-02-10 08:49:15.119981-05	60	2023-02-10 08:49:15.119983-05	t	t	4	f	72	14	0.00
\.


--
-- Data for Name: users_cluster; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.users_cluster (org_id, creation_date, modified_date, mgr_ip_address, active_ps_cmd, is_deployed, deployed_state, connection_status, version_query_log, cqro_id, cnnro_id) FROM stdin;
554c7ff6-263d-4910-8fa3-5636b9c51e45	2023-02-10 08:49:15.125586-05	2023-02-10 08:49:15.126378-05	0.0.0.0		f	unknown	unknown		\N	\N
\.


--
-- Data for Name: users_granchoice; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.users_granchoice (granularity) FROM stdin;
HOURLY
DAILY
MONTHLY
\.


--
-- Data for Name: users_membership; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.users_membership (id, active, creation_date, modified_date, delete_requested, activation_date, org_id, user_id) FROM stdin;
5817e61a-b3a5-4b9d-a55a-080278eae934	t	2023-02-10 08:49:15.13658-05	2023-02-10 08:49:15.136585-05	f	2023-02-10 08:49:15.136588-05	554c7ff6-263d-4910-8fa3-5636b9c51e45	4
\.


--
-- Data for Name: users_orgcost; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.users_orgcost (id, creation_date, modified_date, tm, cnt, avg, min, max, std, ccr, cost_refresh_time, gran_id, org_id) FROM stdin;
2	2023-02-10 08:49:15.131919-05	2023-02-14 14:27:49.993249-05	2023-02-12 19:00:00-05	0	0.03010081206	0	7.0983400722	0.42030612309748394	"{\\n  \\"orgName\\": \\"unit-test-org\\",\\n  \\"granularity\\": \\"DAILY\\",\\n  \\"total\\": 10.9867964019,\\n  \\"unit\\": \\"USD\\",\\n  \\"tm\\": [\\n    \\"2022-02-14\\",\\n    \\"2022-02-15\\",\\n    \\"2022-02-16\\",\\n    \\"2022-02-17\\",\\n    \\"2022-02-18\\",\\n    \\"2022-02-19\\",\\n    \\"2022-02-20\\",\\n    \\"2022-02-21\\",\\n    \\"2022-02-22\\",\\n    \\"2022-02-23\\",\\n    \\"2022-02-24\\",\\n    \\"2022-02-25\\",\\n    \\"2022-02-26\\",\\n    \\"2022-02-27\\",\\n    \\"2022-02-28\\",\\n    \\"2022-03-01\\",\\n    \\"2022-03-02\\",\\n    \\"2022-03-03\\",\\n    \\"2022-03-04\\",\\n    \\"2022-03-05\\",\\n    \\"2022-03-06\\",\\n    \\"2022-03-07\\",\\n    \\"2022-03-08\\",\\n    \\"2022-03-09\\",\\n    \\"2022-03-10\\",\\n    \\"2022-03-11\\",\\n    \\"2022-03-12\\",\\n    \\"2022-03-13\\",\\n    \\"2022-03-14\\",\\n    \\"2022-03-15\\",\\n    \\"2022-03-16\\",\\n    \\"2022-03-17\\",\\n    \\"2022-03-18\\",\\n    \\"2022-03-19\\",\\n    \\"2022-03-20\\",\\n    \\"2022-03-21\\",\\n    \\"2022-03-22\\",\\n    \\"2022-03-23\\",\\n    \\"2022-03-24\\",\\n    \\"2022-03-25\\",\\n    \\"2022-03-26\\",\\n    \\"2022-03-27\\",\\n    \\"2022-03-28\\",\\n    \\"2022-03-29\\",\\n    \\"2022-03-30\\",\\n    \\"2022-03-31\\",\\n    \\"2022-04-01\\",\\n    \\"2022-04-02\\",\\n    \\"2022-04-03\\",\\n    \\"2022-04-04\\",\\n    \\"2022-04-05\\",\\n    \\"2022-04-06\\",\\n    \\"2022-04-07\\",\\n    \\"2022-04-08\\",\\n    \\"2022-04-09\\",\\n    \\"2022-04-10\\",\\n    \\"2022-04-11\\",\\n    \\"2022-04-12\\",\\n    \\"2022-04-13\\",\\n    \\"2022-04-14\\",\\n    \\"2022-04-15\\",\\n    \\"2022-04-16\\",\\n    \\"2022-04-17\\",\\n    \\"2022-04-18\\",\\n    \\"2022-04-19\\",\\n    \\"2022-04-20\\",\\n    \\"2022-04-21\\",\\n    \\"2022-04-22\\",\\n    \\"2022-04-23\\",\\n    \\"2022-04-24\\",\\n    \\"2022-04-25\\",\\n    \\"2022-04-26\\",\\n    \\"2022-04-27\\",\\n    \\"2022-04-28\\",\\n    \\"2022-04-29\\",\\n    \\"2022-04-30\\",\\n    \\"2022-05-01\\",\\n    \\"2022-05-02\\",\\n    \\"2022-05-03\\",\\n    \\"2022-05-04\\",\\n    \\"2022-05-05\\",\\n    \\"2022-05-06\\",\\n    \\"2022-05-07\\",\\n    \\"2022-05-08\\",\\n    \\"2022-05-09\\",\\n    \\"2022-05-10\\",\\n    \\"2022-05-11\\",\\n    \\"2022-05-12\\",\\n    \\"2022-05-13\\",\\n    \\"2022-05-14\\",\\n    \\"2022-05-15\\",\\n    \\"2022-05-16\\",\\n    \\"2022-05-17\\",\\n    \\"2022-05-18\\",\\n    \\"2022-05-19\\",\\n    \\"2022-05-20\\",\\n    \\"2022-05-21\\",\\n    \\"2022-05-22\\",\\n    \\"2022-05-23\\",\\n    \\"2022-05-24\\",\\n    \\"2022-05-25\\",\\n    \\"2022-05-26\\",\\n    \\"2022-05-27\\",\\n    \\"2022-05-28\\",\\n    \\"2022-05-29\\",\\n    \\"2022-05-30\\",\\n    \\"2022-05-31\\",\\n    \\"2022-06-01\\",\\n    \\"2022-06-02\\",\\n    \\"2022-06-03\\",\\n    \\"2022-06-04\\",\\n    \\"2022-06-05\\",\\n    \\"2022-06-06\\",\\n    \\"2022-06-07\\",\\n    \\"2022-06-08\\",\\n    \\"2022-06-09\\",\\n    \\"2022-06-10\\",\\n    \\"2022-06-11\\",\\n    \\"2022-06-12\\",\\n    \\"2022-06-13\\",\\n    \\"2022-06-14\\",\\n    \\"2022-06-15\\",\\n    \\"2022-06-16\\",\\n    \\"2022-06-17\\",\\n    \\"2022-06-18\\",\\n    \\"2022-06-19\\",\\n    \\"2022-06-20\\",\\n    \\"2022-06-21\\",\\n    \\"2022-06-22\\",\\n    \\"2022-06-23\\",\\n    \\"2022-06-24\\",\\n    \\"2022-06-25\\",\\n    \\"2022-06-26\\",\\n    \\"2022-06-27\\",\\n    \\"2022-06-28\\",\\n    \\"2022-06-29\\",\\n    \\"2022-06-30\\",\\n    \\"2022-07-01\\",\\n    \\"2022-07-02\\",\\n    \\"2022-07-03\\",\\n    \\"2022-07-04\\",\\n    \\"2022-07-05\\",\\n    \\"2022-07-06\\",\\n    \\"2022-07-07\\",\\n    \\"2022-07-08\\",\\n    \\"2022-07-09\\",\\n    \\"2022-07-10\\",\\n    \\"2022-07-11\\",\\n    \\"2022-07-12\\",\\n    \\"2022-07-13\\",\\n    \\"2022-07-14\\",\\n    \\"2022-07-15\\",\\n    \\"2022-07-16\\",\\n    \\"2022-07-17\\",\\n    \\"2022-07-18\\",\\n    \\"2022-07-19\\",\\n    \\"2022-07-20\\",\\n    \\"2022-07-21\\",\\n    \\"2022-07-22\\",\\n    \\"2022-07-23\\",\\n    \\"2022-07-24\\",\\n    \\"2022-07-25\\",\\n    \\"2022-07-26\\",\\n    \\"2022-07-27\\",\\n    \\"2022-07-28\\",\\n    \\"2022-07-29\\",\\n    \\"2022-07-30\\",\\n    \\"2022-07-31\\",\\n    \\"2022-08-01\\",\\n    \\"2022-08-02\\",\\n    \\"2022-08-03\\",\\n    \\"2022-08-04\\",\\n    \\"2022-08-05\\",\\n    \\"2022-08-06\\",\\n    \\"2022-08-07\\",\\n    \\"2022-08-08\\",\\n    \\"2022-08-09\\",\\n    \\"2022-08-10\\",\\n    \\"2022-08-11\\",\\n    \\"2022-08-12\\",\\n    \\"2022-08-13\\",\\n    \\"2022-08-14\\",\\n    \\"2022-08-15\\",\\n    \\"2022-08-16\\",\\n    \\"2022-08-17\\",\\n    \\"2022-08-18\\",\\n    \\"2022-08-19\\",\\n    \\"2022-08-20\\",\\n    \\"2022-08-21\\",\\n    \\"2022-08-22\\",\\n    \\"2022-08-23\\",\\n    \\"2022-08-24\\",\\n    \\"2022-08-25\\",\\n    \\"2022-08-26\\",\\n    \\"2022-08-27\\",\\n    \\"2022-08-28\\",\\n    \\"2022-08-29\\",\\n    \\"2022-08-30\\",\\n    \\"2022-08-31\\",\\n    \\"2022-09-01\\",\\n    \\"2022-09-02\\",\\n    \\"2022-09-03\\",\\n    \\"2022-09-04\\",\\n    \\"2022-09-05\\",\\n    \\"2022-09-06\\",\\n    \\"2022-09-07\\",\\n    \\"2022-09-08\\",\\n    \\"2022-09-09\\",\\n    \\"2022-09-10\\",\\n    \\"2022-09-11\\",\\n    \\"2022-09-12\\",\\n    \\"2022-09-13\\",\\n    \\"2022-09-14\\",\\n    \\"2022-09-15\\",\\n    \\"2022-09-16\\",\\n    \\"2022-09-17\\",\\n    \\"2022-09-18\\",\\n    \\"2022-09-19\\",\\n    \\"2022-09-20\\",\\n    \\"2022-09-21\\",\\n    \\"2022-09-22\\",\\n    \\"2022-09-23\\",\\n    \\"2022-09-24\\",\\n    \\"2022-09-25\\",\\n    \\"2022-09-26\\",\\n    \\"2022-09-27\\",\\n    \\"2022-09-28\\",\\n    \\"2022-09-29\\",\\n    \\"2022-09-30\\",\\n    \\"2022-10-01\\",\\n    \\"2022-10-02\\",\\n    \\"2022-10-03\\",\\n    \\"2022-10-04\\",\\n    \\"2022-10-05\\",\\n    \\"2022-10-06\\",\\n    \\"2022-10-07\\",\\n    \\"2022-10-08\\",\\n    \\"2022-10-09\\",\\n    \\"2022-10-10\\",\\n    \\"2022-10-11\\",\\n    \\"2022-10-12\\",\\n    \\"2022-10-13\\",\\n    \\"2022-10-14\\",\\n    \\"2022-10-15\\",\\n    \\"2022-10-16\\",\\n    \\"2022-10-17\\",\\n    \\"2022-10-18\\",\\n    \\"2022-10-19\\",\\n    \\"2022-10-20\\",\\n    \\"2022-10-21\\",\\n    \\"2022-10-22\\",\\n    \\"2022-10-23\\",\\n    \\"2022-10-24\\",\\n    \\"2022-10-25\\",\\n    \\"2022-10-26\\",\\n    \\"2022-10-27\\",\\n    \\"2022-10-28\\",\\n    \\"2022-10-29\\",\\n    \\"2022-10-30\\",\\n    \\"2022-10-31\\",\\n    \\"2022-11-01\\",\\n    \\"2022-11-02\\",\\n    \\"2022-11-03\\",\\n    \\"2022-11-04\\",\\n    \\"2022-11-05\\",\\n    \\"2022-11-06\\",\\n    \\"2022-11-07\\",\\n    \\"2022-11-08\\",\\n    \\"2022-11-09\\",\\n    \\"2022-11-10\\",\\n    \\"2022-11-11\\",\\n    \\"2022-11-12\\",\\n    \\"2022-11-13\\",\\n    \\"2022-11-14\\",\\n    \\"2022-11-15\\",\\n    \\"2022-11-16\\",\\n    \\"2022-11-17\\",\\n    \\"2022-11-18\\",\\n    \\"2022-11-19\\",\\n    \\"2022-11-20\\",\\n    \\"2022-11-21\\",\\n    \\"2022-11-22\\",\\n    \\"2022-11-23\\",\\n    \\"2022-11-24\\",\\n    \\"2022-11-25\\",\\n    \\"2022-11-26\\",\\n    \\"2022-11-27\\",\\n    \\"2022-11-28\\",\\n    \\"2022-11-29\\",\\n    \\"2022-11-30\\",\\n    \\"2022-12-01\\",\\n    \\"2022-12-02\\",\\n    \\"2022-12-03\\",\\n    \\"2022-12-04\\",\\n    \\"2022-12-05\\",\\n    \\"2022-12-06\\",\\n    \\"2022-12-07\\",\\n    \\"2022-12-08\\",\\n    \\"2022-12-09\\",\\n    \\"2022-12-10\\",\\n    \\"2022-12-11\\",\\n    \\"2022-12-12\\",\\n    \\"2022-12-13\\",\\n    \\"2022-12-14\\",\\n    \\"2022-12-15\\",\\n    \\"2022-12-16\\",\\n    \\"2022-12-17\\",\\n    \\"2022-12-18\\",\\n    \\"2022-12-19\\",\\n    \\"2022-12-20\\",\\n    \\"2022-12-21\\",\\n    \\"2022-12-22\\",\\n    \\"2022-12-23\\",\\n    \\"2022-12-24\\",\\n    \\"2022-12-25\\",\\n    \\"2022-12-26\\",\\n    \\"2022-12-27\\",\\n    \\"2022-12-28\\",\\n    \\"2022-12-29\\",\\n    \\"2022-12-30\\",\\n    \\"2022-12-31\\",\\n    \\"2023-01-01\\",\\n    \\"2023-01-02\\",\\n    \\"2023-01-03\\",\\n    \\"2023-01-04\\",\\n    \\"2023-01-05\\",\\n    \\"2023-01-06\\",\\n    \\"2023-01-07\\",\\n    \\"2023-01-08\\",\\n    \\"2023-01-09\\",\\n    \\"2023-01-10\\",\\n    \\"2023-01-11\\",\\n    \\"2023-01-12\\",\\n    \\"2023-01-13\\",\\n    \\"2023-01-14\\",\\n    \\"2023-01-15\\",\\n    \\"2023-01-16\\",\\n    \\"2023-01-17\\",\\n    \\"2023-01-18\\",\\n    \\"2023-01-19\\",\\n    \\"2023-01-20\\",\\n    \\"2023-01-21\\",\\n    \\"2023-01-22\\",\\n    \\"2023-01-23\\",\\n    \\"2023-01-24\\",\\n    \\"2023-01-25\\",\\n    \\"2023-01-26\\",\\n    \\"2023-01-27\\",\\n    \\"2023-01-28\\",\\n    \\"2023-01-29\\",\\n    \\"2023-01-30\\",\\n    \\"2023-01-31\\",\\n    \\"2023-02-01\\",\\n    \\"2023-02-02\\",\\n    \\"2023-02-03\\",\\n    \\"2023-02-04\\",\\n    \\"2023-02-05\\",\\n    \\"2023-02-06\\",\\n    \\"2023-02-07\\",\\n    \\"2023-02-08\\",\\n    \\"2023-02-09\\",\\n    \\"2023-02-10\\",\\n    \\"2023-02-11\\",\\n    \\"2023-02-12\\",\\n    \\"2023-02-13\\"\\n  ],\\n  \\"cost\\": [\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.1156402249,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    3.7728161048,\\n    7.0983400722,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0\\n  ],\\n  \\"stats\\": {\\n    \\"avg\\": 0.03010081206,\\n    \\"max\\": 7.0983400722,\\n    \\"std\\": 0.42030612309748394\\n  }\\n}"	2023-02-14 14:27:47.096776-05	DAILY	554c7ff6-263d-4910-8fa3-5636b9c51e45
1	2023-02-10 08:49:15.128674-05	2023-02-14 14:30:00.52903-05	2022-02-09 08:49:15.122855-05	0	0	0	0	0	"{ }"	2022-02-09 08:49:15.122855-05	HOURLY	554c7ff6-263d-4910-8fa3-5636b9c51e45
3	2023-02-10 08:49:15.134408-05	2023-02-14 14:30:01.383497-05	2023-01-31 19:00:00-05	0	0.8451381847615385	0	10.871156177	3.012613042400426	"{\\n  \\"orgName\\": \\"unit-test-org\\",\\n  \\"granularity\\": \\"MONTHLY\\",\\n  \\"total\\": 10.9867964019,\\n  \\"unit\\": \\"USD\\",\\n  \\"tm\\": [\\n    \\"2022-02-14\\",\\n    \\"2022-03-01\\",\\n    \\"2022-04-01\\",\\n    \\"2022-05-01\\",\\n    \\"2022-06-01\\",\\n    \\"2022-07-01\\",\\n    \\"2022-08-01\\",\\n    \\"2022-09-01\\",\\n    \\"2022-10-01\\",\\n    \\"2022-11-01\\",\\n    \\"2022-12-01\\",\\n    \\"2023-01-01\\",\\n    \\"2023-02-01\\"\\n  ],\\n  \\"cost\\": [\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.1156402249,\\n    10.871156177,\\n    0.0\\n  ],\\n  \\"stats\\": {\\n    \\"avg\\": 0.8451381847615385,\\n    \\"max\\": 10.871156177,\\n    \\"std\\": 3.012613042400426\\n  }\\n}"	2023-02-14 14:30:00.541623-05	MONTHLY	554c7ff6-263d-4910-8fa3-5636b9c51e45
\.


--
-- Data for Name: users_orgnumnode; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.users_orgnumnode (id, desired_num_nodes, expiration, has_active_ps_cmd, org_id, user_id, show_expire_tm) FROM stdin;
\.


--
-- Data for Name: users_pscmdqueueresult; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.users_pscmdqueueresult (id, ps_cmd_output, error, creation_date, ps_cmd_summary_label, org_id, task_result_id, expiration, show_expire_tm) FROM stdin;
\.


--
-- Data for Name: users_user_groups; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.users_user_groups (id, user_id, group_id) FROM stdin;
1	4	1
\.


--
-- Data for Name: users_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.users_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.


--
-- Name: account_emailaddress_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ps_admin
--

SELECT pg_catalog.setval('public.account_emailaddress_id_seq', 5, true);


--
-- Name: account_emailconfirmation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ps_admin
--

SELECT pg_catalog.setval('public.account_emailconfirmation_id_seq', 1, false);


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ps_admin
--

SELECT pg_catalog.setval('public.auth_group_id_seq', 1, true);


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ps_admin
--

SELECT pg_catalog.setval('public.auth_group_permissions_id_seq', 96, true);


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ps_admin
--

SELECT pg_catalog.setval('public.auth_permission_id_seq', 124, true);


--
-- Name: captcha_captchastore_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ps_admin
--

SELECT pg_catalog.setval('public.captcha_captchastore_id_seq', 8, true);


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ps_admin
--

SELECT pg_catalog.setval('public.django_admin_log_id_seq', 6, true);


--
-- Name: django_celery_beat_clockedschedule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ps_admin
--

SELECT pg_catalog.setval('public.django_celery_beat_clockedschedule_id_seq', 1, false);


--
-- Name: django_celery_beat_crontabschedule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ps_admin
--

SELECT pg_catalog.setval('public.django_celery_beat_crontabschedule_id_seq', 4, true);


--
-- Name: django_celery_beat_intervalschedule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ps_admin
--

SELECT pg_catalog.setval('public.django_celery_beat_intervalschedule_id_seq', 1, false);


--
-- Name: django_celery_beat_periodictask_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ps_admin
--

SELECT pg_catalog.setval('public.django_celery_beat_periodictask_id_seq', 4, true);


--
-- Name: django_celery_beat_solarschedule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ps_admin
--

SELECT pg_catalog.setval('public.django_celery_beat_solarschedule_id_seq', 1, false);


--
-- Name: django_celery_results_chordcounter_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ps_admin
--

SELECT pg_catalog.setval('public.django_celery_results_chordcounter_id_seq', 1, false);


--
-- Name: django_celery_results_groupresult_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ps_admin
--

SELECT pg_catalog.setval('public.django_celery_results_groupresult_id_seq', 1, false);


--
-- Name: django_celery_results_taskresult_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ps_admin
--

SELECT pg_catalog.setval('public.django_celery_results_taskresult_id_seq', 314, true);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ps_admin
--

SELECT pg_catalog.setval('public.django_content_type_id_seq', 31, true);


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ps_admin
--

SELECT pg_catalog.setval('public.django_migrations_id_seq', 73, true);


--
-- Name: django_site_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ps_admin
--

SELECT pg_catalog.setval('public.django_site_id_seq', 2, true);


--
-- Name: socialaccount_socialaccount_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ps_admin
--

SELECT pg_catalog.setval('public.socialaccount_socialaccount_id_seq', 1, false);


--
-- Name: socialaccount_socialapp_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ps_admin
--

SELECT pg_catalog.setval('public.socialaccount_socialapp_id_seq', 1, true);


--
-- Name: socialaccount_socialapp_sites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ps_admin
--

SELECT pg_catalog.setval('public.socialaccount_socialapp_sites_id_seq', 1, true);


--
-- Name: socialaccount_socialtoken_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ps_admin
--

SELECT pg_catalog.setval('public.socialaccount_socialtoken_id_seq', 1, false);


--
-- Name: token_blacklist_blacklistedtoken_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ps_admin
--

SELECT pg_catalog.setval('public.token_blacklist_blacklistedtoken_id_seq', 1, false);


--
-- Name: token_blacklist_outstandingtoken_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ps_admin
--

SELECT pg_catalog.setval('public.token_blacklist_outstandingtoken_id_seq', 1, false);


--
-- Name: users_orgcost_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ps_admin
--

SELECT pg_catalog.setval('public.users_orgcost_id_seq', 3, true);


--
-- Name: users_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ps_admin
--

SELECT pg_catalog.setval('public.users_user_groups_id_seq', 1, true);


--
-- Name: users_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ps_admin
--

SELECT pg_catalog.setval('public.users_user_id_seq', 5, true);


--
-- Name: users_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ps_admin
--

SELECT pg_catalog.setval('public.users_user_user_permissions_id_seq', 1, false);


--
-- PostgreSQL database dump complete
--

