--
-- PostgreSQL database dump
--

-- Dumped from database version 12.13 (Debian 12.13-1.pgdg110+1)
-- Dumped by pg_dump version 12.13 (Debian 12.13-1.pgdg110+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: users_user; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.users_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined) FROM stdin;
2	pbkdf2_sha256$390000$1t8BvoVMwGyqm2IqMLNtyz$ieu6zdynRswa8fAm6gZb4yc/zICVTUPGKJbwOQidqh8=	2023-01-06 08:02:34-05	t	admin1			ceugarteblair@outlook.com	t	t	2023-01-06 07:51:51-05
1	pbkdf2_sha256$390000$QcnjnyhgqwVD5fS8Q7hZpK$44z9Tz96PbyYws1QpVDhvQ3c0g0mkCpVDeUxsSQ5xxA=	2023-02-01 17:51:04.702696-05	t	admin			sps.sliderule@gmail.com	t	t	2023-01-06 07:48:55-05
4	!8zZNFEIpNXuj1dzKCatLr6hOYCX6QNnKQJ0NMYFh	2023-01-17 12:06:38.581791-05	f	cugarteblair	Carlos	E. Ugarte	carlos.e.ugarte@nasa.gov	f	t	2023-01-17 10:47:40.198825-05
3	pbkdf2_sha256$390000$9EYfED7P9QdohFyUBaOCOQ$C2ppqQnm5el7SR2sa4uJypGOOT1EGfCVjgseFRDB4Dk=	2023-02-03 15:46:41.120103-05	f	ceugarteblair	Carlos	Ugarte	ceugarteblair@icloud.com	t	t	2023-01-06 08:07:46-05
\.


--
-- Data for Name: account_emailaddress; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.account_emailaddress (id, email, verified, "primary", user_id) FROM stdin;
2	carlos.e.ugarte@nasa.gov	f	t	4
1	ceugarteblair@icloud.com	t	t	3
4	sps.sliderule@gmail.com	t	t	1
\.


--
-- Data for Name: account_emailconfirmation; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.account_emailconfirmation (id, created, sent, key, email_address_id) FROM stdin;
\.


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.auth_group (id, name) FROM stdin;
1	PS_Developer
\.


--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.django_content_type (id, app_label, model) FROM stdin;
1	admin	logentry
2	auth	permission
3	auth	group
4	contenttypes	contenttype
5	sessions	session
6	token_blacklist	blacklistedtoken
7	token_blacklist	outstandingtoken
8	users	user
9	users	granchoice
10	users	orgaccount
11	users	cluster
12	users	pscmdqueueresult
13	users	orgnumnode
14	users	orgcost
15	users	membership
16	captcha	captchastore
17	django_celery_results	taskresult
18	django_celery_results	chordcounter
19	django_celery_results	groupresult
20	django_celery_beat	crontabschedule
21	django_celery_beat	intervalschedule
22	django_celery_beat	periodictask
23	django_celery_beat	periodictasks
24	django_celery_beat	solarschedule
25	django_celery_beat	clockedschedule
26	sites	site
27	account	emailaddress
28	account	emailconfirmation
29	socialaccount	socialaccount
30	socialaccount	socialapp
31	socialaccount	socialtoken
\.


--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.auth_permission (id, name, content_type_id, codename) FROM stdin;
1	Can add log entry	1	add_logentry
2	Can change log entry	1	change_logentry
3	Can delete log entry	1	delete_logentry
4	Can view log entry	1	view_logentry
5	Can add permission	2	add_permission
6	Can change permission	2	change_permission
7	Can delete permission	2	delete_permission
8	Can view permission	2	view_permission
9	Can add group	3	add_group
10	Can change group	3	change_group
11	Can delete group	3	delete_group
12	Can view group	3	view_group
13	Can add content type	4	add_contenttype
14	Can change content type	4	change_contenttype
15	Can delete content type	4	delete_contenttype
16	Can view content type	4	view_contenttype
17	Can add session	5	add_session
18	Can change session	5	change_session
19	Can delete session	5	delete_session
20	Can view session	5	view_session
21	Can add blacklisted token	6	add_blacklistedtoken
22	Can change blacklisted token	6	change_blacklistedtoken
23	Can delete blacklisted token	6	delete_blacklistedtoken
24	Can view blacklisted token	6	view_blacklistedtoken
25	Can add outstanding token	7	add_outstandingtoken
26	Can change outstanding token	7	change_outstandingtoken
27	Can delete outstanding token	7	delete_outstandingtoken
28	Can view outstanding token	7	view_outstandingtoken
29	Can add user	8	add_user
30	Can change user	8	change_user
31	Can delete user	8	delete_user
32	Can view user	8	view_user
33	Can add gran choice	9	add_granchoice
34	Can change gran choice	9	change_granchoice
35	Can delete gran choice	9	delete_granchoice
36	Can view gran choice	9	view_granchoice
37	Can add org account	10	add_orgaccount
38	Can change org account	10	change_orgaccount
39	Can delete org account	10	delete_orgaccount
40	Can view org account	10	view_orgaccount
41	Can add cluster	11	add_cluster
42	Can change cluster	11	change_cluster
43	Can delete cluster	11	delete_cluster
44	Can view cluster	11	view_cluster
45	Can add ps cmd queue result	12	add_pscmdqueueresult
46	Can change ps cmd queue result	12	change_pscmdqueueresult
47	Can delete ps cmd queue result	12	delete_pscmdqueueresult
48	Can view ps cmd queue result	12	view_pscmdqueueresult
49	Can add org num node	13	add_orgnumnode
50	Can change org num node	13	change_orgnumnode
51	Can delete org num node	13	delete_orgnumnode
52	Can view org num node	13	view_orgnumnode
53	Can add org cost	14	add_orgcost
54	Can change org cost	14	change_orgcost
55	Can delete org cost	14	delete_orgcost
56	Can view org cost	14	view_orgcost
57	Can add membership	15	add_membership
58	Can change membership	15	change_membership
59	Can delete membership	15	delete_membership
60	Can view membership	15	view_membership
61	Can add captcha store	16	add_captchastore
62	Can change captcha store	16	change_captchastore
63	Can delete captcha store	16	delete_captchastore
64	Can view captcha store	16	view_captchastore
65	Can add task result	17	add_taskresult
66	Can change task result	17	change_taskresult
67	Can delete task result	17	delete_taskresult
68	Can view task result	17	view_taskresult
69	Can add chord counter	18	add_chordcounter
70	Can change chord counter	18	change_chordcounter
71	Can delete chord counter	18	delete_chordcounter
72	Can view chord counter	18	view_chordcounter
73	Can add group result	19	add_groupresult
74	Can change group result	19	change_groupresult
75	Can delete group result	19	delete_groupresult
76	Can view group result	19	view_groupresult
77	Can add crontab	20	add_crontabschedule
78	Can change crontab	20	change_crontabschedule
79	Can delete crontab	20	delete_crontabschedule
80	Can view crontab	20	view_crontabschedule
81	Can add interval	21	add_intervalschedule
82	Can change interval	21	change_intervalschedule
83	Can delete interval	21	delete_intervalschedule
84	Can view interval	21	view_intervalschedule
85	Can add periodic task	22	add_periodictask
86	Can change periodic task	22	change_periodictask
87	Can delete periodic task	22	delete_periodictask
88	Can view periodic task	22	view_periodictask
89	Can add periodic tasks	23	add_periodictasks
90	Can change periodic tasks	23	change_periodictasks
91	Can delete periodic tasks	23	delete_periodictasks
92	Can view periodic tasks	23	view_periodictasks
93	Can add solar event	24	add_solarschedule
94	Can change solar event	24	change_solarschedule
95	Can delete solar event	24	delete_solarschedule
96	Can view solar event	24	view_solarschedule
97	Can add clocked	25	add_clockedschedule
98	Can change clocked	25	change_clockedschedule
99	Can delete clocked	25	delete_clockedschedule
100	Can view clocked	25	view_clockedschedule
101	Can add site	26	add_site
102	Can change site	26	change_site
103	Can delete site	26	delete_site
104	Can view site	26	view_site
105	Can add email address	27	add_emailaddress
106	Can change email address	27	change_emailaddress
107	Can delete email address	27	delete_emailaddress
108	Can view email address	27	view_emailaddress
109	Can add email confirmation	28	add_emailconfirmation
110	Can change email confirmation	28	change_emailconfirmation
111	Can delete email confirmation	28	delete_emailconfirmation
112	Can view email confirmation	28	view_emailconfirmation
113	Can add social account	29	add_socialaccount
114	Can change social account	29	change_socialaccount
115	Can delete social account	29	delete_socialaccount
116	Can view social account	29	view_socialaccount
117	Can add social application	30	add_socialapp
118	Can change social application	30	change_socialapp
119	Can delete social application	30	delete_socialapp
120	Can view social application	30	view_socialapp
121	Can add social application token	31	add_socialtoken
122	Can change social application token	31	change_socialtoken
123	Can delete social application token	31	delete_socialtoken
124	Can view social application token	31	view_socialtoken
\.


--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.auth_group_permissions (id, group_id, permission_id) FROM stdin;
1	1	21
2	1	22
3	1	23
4	1	24
5	1	25
6	1	26
7	1	27
8	1	28
9	1	33
10	1	34
11	1	35
12	1	36
13	1	37
14	1	38
15	1	39
16	1	40
17	1	41
18	1	42
19	1	43
20	1	44
21	1	45
22	1	46
23	1	47
24	1	48
25	1	49
26	1	50
27	1	51
28	1	52
29	1	53
30	1	54
31	1	55
32	1	56
33	1	57
34	1	58
35	1	59
36	1	60
37	1	65
38	1	66
39	1	67
40	1	68
41	1	69
42	1	70
43	1	71
44	1	72
45	1	73
46	1	74
47	1	75
48	1	76
49	1	77
50	1	78
51	1	79
52	1	80
53	1	81
54	1	82
55	1	83
56	1	84
57	1	85
58	1	86
59	1	87
60	1	88
61	1	89
62	1	90
63	1	91
64	1	92
65	1	93
66	1	94
67	1	95
68	1	96
69	1	97
70	1	98
71	1	99
72	1	100
\.


--
-- Data for Name: captcha_captchastore; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.captcha_captchastore (id, challenge, response, hashkey, expiration) FROM stdin;
\.


--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
1	2023-01-06 07:58:46.480404-05	1	admin	2	[{"changed": {"fields": ["Superuser status", "Phone number"]}}]	8	2
2	2023-01-06 08:02:49.263512-05	1	admin	2	[{"changed": {"fields": ["Superuser status"]}}]	8	2
3	2023-01-06 08:12:47.564433-05	1	PS_Developer	1	[{"added": {}}]	3	1
4	2023-01-06 08:14:16.285461-05	3	ceugarteblair	2	[{"changed": {"fields": ["Groups", "Staff status"]}}]	8	1
5	2023-01-10 10:10:59.528965-05	b5edeee0-8425-446c-a73f-47e5a20ef3ce	Cluster object (b5edeee0-8425-446c-a73f-47e5a20ef3ce)	2	[{"changed": {"fields": ["Active ps cmd", "Is deployed", "Cqro id"]}}]	11	3
6	2023-01-11 09:30:00.16058-05	b5edeee0-8425-446c-a73f-47e5a20ef3ce	Cluster object (b5edeee0-8425-446c-a73f-47e5a20ef3ce)	2	[{"changed": {"fields": ["Is deployed", "Cnnro id"]}}]	11	3
7	2023-01-13 10:48:35.342463-05	1	127.0.0.1:8080	2	[{"changed": {"fields": ["Domain name", "Display name"]}}]	26	1
8	2023-01-17 10:32:42.109981-05	1	oath-github-prov-sys	1	[{"added": {}}]	30	1
9	2023-01-17 10:52:32.57905-05	1	oath-github-prov-sys	2	[{"changed": {"fields": ["Secret key"]}}]	30	1
10	2023-01-17 12:12:09.121989-05	1	oath-github-prov-sys	2	[{"changed": {"fields": ["Secret key"]}}]	30	1
11	2023-01-17 12:12:24.035801-05	1	oath-github-prov-sys	2	[]	30	1
12	2023-01-17 12:16:51.589227-05	2	http://127.0.0.1:8080	1	[{"added": {}}]	26	1
13	2023-01-17 12:17:01.560198-05	1	127.0.0.1:8080	3		26	1
14	2023-01-17 12:17:12.42814-05	1	cugarteblair	3		29	1
15	2023-01-17 12:18:47.98955-05	1	oath-github-prov-sys	2	[{"changed": {"fields": ["Sites"]}}]	30	1
16	2023-01-17 14:12:44.8641-05	1	oath-github-prov-sys	2	[{"changed": {"fields": ["Client id", "Secret key"]}}]	30	1
17	2023-01-19 15:01:12.382181-05	1	admin	2	[{"changed": {"fields": ["Email address"]}}]	8	1
18	2023-01-19 15:02:25.206296-05	2	admin1	2	[{"changed": {"fields": ["Email address", "Phone number"]}}]	8	1
19	2023-01-19 15:17:50.883627-05	2	google-oauth	1	[{"added": {}}]	30	1
20	2023-01-27 08:22:54.467455-05	b5edeee0-8425-446c-a73f-47e5a20ef3ce	unit-test-org	2	[{"changed": {"fields": ["Tokens", "Allow deploy by token"]}}]	10	3
\.


--
-- Data for Name: django_celery_beat_clockedschedule; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.django_celery_beat_clockedschedule (id, clocked_time) FROM stdin;
\.


--
-- Data for Name: django_celery_beat_crontabschedule; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.django_celery_beat_crontabschedule (id, minute, hour, day_of_week, day_of_month, month_of_year, timezone) FROM stdin;
1	0	4	*	*	*	UTC
2	30	*	*	*	*	UTC
3	15	*	*	*	*	UTC
4	0	0	*	*	*	UTC
\.


--
-- Data for Name: django_celery_beat_intervalschedule; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.django_celery_beat_intervalschedule (id, every, period) FROM stdin;
\.


--
-- Data for Name: django_celery_beat_solarschedule; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.django_celery_beat_solarschedule (id, event, latitude, longitude) FROM stdin;
\.


--
-- Data for Name: django_celery_beat_periodictask; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.django_celery_beat_periodictask (id, name, task, args, kwargs, queue, exchange, routing_key, expires, enabled, last_run_at, total_run_count, date_changed, description, crontab_id, interval_id, solar_id, one_off, start_time, priority, headers, clocked_id, expire_seconds) FROM stdin;
1	celery.backend_cleanup	celery.backend_cleanup	[]	{}	\N	\N	\N	\N	t	2023-02-03 09:09:56.088484-05	17	2023-02-03 15:46:34.74387-05		1	\N	\N	f	\N	\N	{}	\N	43200
4	purge_ps_cmd_que_rslts	purge_ps_cmd_que_rslts	[]	{}	default	\N	\N	\N	t	2023-02-03 09:09:56.127614-05	17	2023-02-03 15:46:34.771115-05		4	\N	\N	f	\N	\N	{}	\N	\N
2	hourly processing	hourly_processing	[]	{}	default	\N	\N	\N	t	2023-02-03 15:46:34.817135-05	291	2023-02-03 15:46:34.83328-05		2	\N	\N	f	\N	\N	{}	\N	\N
3	flush expired refresh tokens	flush_expired_refresh_tokens	[]	{}	default	\N	\N	\N	t	2023-02-03 15:46:34.840949-05	289	2023-02-03 15:49:35.596497-05		3	\N	\N	f	\N	\N	{}	\N	\N
\.


--
-- Data for Name: django_celery_beat_periodictasks; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.django_celery_beat_periodictasks (ident, last_update) FROM stdin;
1	2023-02-03 15:46:34.771361-05
\.


--
-- Data for Name: django_celery_results_chordcounter; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.django_celery_results_chordcounter (id, group_id, sub_tasks, count) FROM stdin;
\.


--
-- Data for Name: django_celery_results_groupresult; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.django_celery_results_groupresult (id, group_id, date_created, date_done, content_type, content_encoding, result) FROM stdin;
\.


--
-- Data for Name: django_celery_results_taskresult; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.django_celery_results_taskresult (id, task_id, status, content_type, content_encoding, result, date_done, traceback, meta, task_args, task_kwargs, task_name, worker, date_created, periodic_task_name) FROM stdin;
516	8f383abc-8db9-4730-a827-b3c344359b12	SUCCESS	application/json	utf-8	true	2023-01-30 07:15:00.027742-05	\N	{"children": []}	"()"	"{}"	flush_expired_refresh_tokens	default@%7e2a53c89252	2023-01-30 07:15:00.027733-05	flush expired refresh tokens
563	0ef750d8-3413-4849-ad7f-4d5d73c9b9db	SUCCESS	application/json	utf-8	true	2023-01-31 02:15:00.011266-05	\N	{"children": []}	"()"	"{}"	flush_expired_refresh_tokens	default@%67e9c3d9f403	2023-01-31 02:15:00.011259-05	flush expired refresh tokens
620	8b198f7c-9af9-41d5-a365-0bbfeeffa276	SUCCESS	application/json	utf-8	true	2023-02-02 00:15:00.033039-05	\N	{"children": []}	"()"	"{}"	flush_expired_refresh_tokens	default@%5f721f5feee9	2023-02-02 00:15:00.03303-05	flush expired refresh tokens
637	32045da9-6e13-4552-9591-5cfd49ccc737	SUCCESS	application/json	utf-8	false	2023-02-02 08:30:01.416163-05	\N	{"children": []}	"()"	"{}"	hourly_processing	default@%5f721f5feee9	2023-02-02 08:30:01.416139-05	hourly processing
517	2f9c5513-6e74-4dc3-bdbb-aa1ed48d0982	SUCCESS	application/json	utf-8	true	2023-01-30 07:30:07.939434-05	\N	{"children": []}	"()"	"{}"	hourly_processing	default@%7e2a53c89252	2023-01-30 07:30:07.939427-05	hourly processing
522	679d7f20-1d72-4a69-8bf5-c4c0dc821b4b	SUCCESS	application/json	utf-8	true	2023-01-30 10:35:14.897824-05	\N	{"children": []}	"()"	"{}"	flush_expired_refresh_tokens	default@%ca7c4b5ed1b6	2023-01-30 10:35:14.897792-05	flush expired refresh tokens
524	ac1ca2d2-d221-4cd3-9c34-7128a9069928	SUCCESS	application/json	utf-8	true	2023-01-30 13:43:14.984476-05	\N	{"children": []}	"()"	"{}"	flush_expired_refresh_tokens	default@%4e576379ffab	2023-01-30 13:43:14.984444-05	flush expired refresh tokens
526	f3c3a5e9-8ad5-4013-b694-87a71109c57f	SUCCESS	application/json	utf-8	true	2023-01-30 13:48:05.279024-05	\N	{"children": []}	"()"	"{}"	flush_expired_refresh_tokens	default@%a7745da6e13f	2023-01-30 13:48:05.278992-05	flush expired refresh tokens
527	df763a9e-a530-4b2d-a874-83e82e1d02de	SUCCESS	application/json	utf-8	true	2023-01-30 14:15:00.023862-05	\N	{"children": []}	"()"	"{}"	flush_expired_refresh_tokens	default@%29b7ee2d6958	2023-01-30 14:15:00.023825-05	flush expired refresh tokens
528	504ff216-20f4-4280-baae-3c142daf46d8	SUCCESS	application/json	utf-8	true	2023-01-30 14:27:18.124921-05	\N	{"children": []}	"()"	"{}"	flush_expired_refresh_tokens	default@%d0a11c62c81a	2023-01-30 14:27:18.124898-05	flush expired refresh tokens
529	78165b05-8811-48ac-88ea-cf926b06c88a	SUCCESS	application/json	utf-8	true	2023-01-30 14:32:49.975657-05	\N	{"children": []}	"()"	"{}"	hourly_processing	default@%5c8909d3f876	2023-01-30 14:32:49.975645-05	hourly processing
530	e8098d23-1c1d-4785-afdb-3ddd4394a335	SUCCESS	application/json	utf-8	true	2023-01-30 15:25:42.604882-05	\N	{"children": []}	"()"	"{}"	flush_expired_refresh_tokens	default@%933c0f7e7131	2023-01-30 15:25:42.604854-05	flush expired refresh tokens
532	bc0cd59d-677a-435f-baec-74fbf7ab5052	SUCCESS	application/json	utf-8	true	2023-01-30 16:04:56.642655-05	\N	{"children": []}	"()"	"{}"	hourly_processing	default@%1aa89ba7f8b6	2023-01-30 16:04:56.642648-05	hourly processing
536	e407e1df-76d4-415a-b218-0c9bdd60f543	SUCCESS	application/json	utf-8	true	2023-01-30 16:30:34.366185-05	\N	{"children": []}	"()"	"{}"	hourly_processing	default@%6e59a8df8ad7	2023-01-30 16:30:34.366177-05	hourly processing
538	aaa9dd03-bc12-4966-814a-6c68c01203cb	SUCCESS	application/json	utf-8	{"task": {"id": "aaa9dd03-bc12-4966-814a-6c68c01203cb", "org_id": "b5edeee0-8425-446c-a73f-47e5a20ef3ce", "description": "AttributeError(\\"'Connection' object has no attribute 'connect'\\")", "lock_status": "unset", "cmd_status": ""}, "cqro_id": "b73b5924-83c2-4076-8351-090213c2e98b"}	2023-01-30 16:54:19.033884-05	\N	{"children": []}	"('Refresh', UUID('b5edeee0-8425-446c-a73f-47e5a20ef3ce'), 'ceugarteblair', None, False, None, False)"	"{}"	provision_cmd_uuid	unit-test-org@%a30ad1b5a0ef	2023-01-30 16:54:19.033875-05	\N
539	e00893e2-c128-4e08-a798-3ba0600cb358	SUCCESS	application/json	utf-8	{"task": {"id": "e00893e2-c128-4e08-a798-3ba0600cb358", "org_id": "b5edeee0-8425-446c-a73f-47e5a20ef3ce", "description": "AttributeError(\\"'Connection' object has no attribute 'connect'\\")", "lock_status": "unset", "cmd_status": ""}, "cqro_id": "5f2c1efa-8902-444d-b247-c6a3ace9d84b"}	2023-01-30 17:04:01.155471-05	\N	{"children": []}	"('Refresh', UUID('b5edeee0-8425-446c-a73f-47e5a20ef3ce'), 'ceugarteblair', None, False, None, False)"	"{}"	provision_cmd_uuid	unit-test-org@%a3d3b8fc775c	2023-01-30 17:04:01.155464-05	\N
541	0ff83410-9627-4a52-b538-39d7bf902ab4	SUCCESS	application/json	utf-8	true	2023-01-30 17:16:27.648476-05	\N	{"children": []}	"()"	"{}"	flush_expired_refresh_tokens	default@%1a54df768e38	2023-01-30 17:16:27.648447-05	flush expired refresh tokens
546	76a9c696-7918-4d84-b5d9-0d8d4d4d11a1	SUCCESS	application/json	utf-8	null	2023-01-30 19:00:51.688632-05	\N	{"children": []}	"()"	"{}"	purge_ps_cmd_que_rslts	default@%67e9c3d9f403	2023-01-30 19:00:51.688626-05	purge_ps_cmd_que_rslts
564	a1037dda-db0b-4370-b860-b422abf78e77	SUCCESS	application/json	utf-8	false	2023-01-31 02:30:01.264516-05	\N	{"children": []}	"()"	"{}"	hourly_processing	default@%67e9c3d9f403	2023-01-31 02:30:01.264492-05	hourly processing
574	edc6d943-1ae1-4131-b961-47d1f5f63886	FAILURE	application/json	utf-8	{"exc_type": "NameError", "exc_message": ["name 'pals' is not defined"], "exc_module": "builtins"}	2023-01-31 07:28:24.871872-05	Traceback (most recent call last):\n  File "/home/reg_user/.local/lib/python3.11/site-packages/celery/app/trace.py", line 451, in trace_task\n    R = retval = fun(*args, **kwargs)\n                 ^^^^^^^^^^^^^^^^^^^^\n  File "/home/reg_user/.local/lib/python3.11/site-packages/celery/app/trace.py", line 734, in __protected_call__\n    return self.run(*args, **kwargs)\n           ^^^^^^^^^^^^^^^^^^^^^^^^^\n  File "/home/reg_user/ps/users/tasks.py", line 1123, in provision_cmd_uuid\n    task_result = process_provision_cmd(ps_cmd=ps_cmd, uuid=uuid, username=username, deploy_values=deploy_values, task_result=task_result,last_one=last_one,onn_uuid=onn_uuid,reset=reset)\n                  ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File "/home/reg_user/ps/users/tasks.py", line 842, in process_provision_cmd\n    locker = pals.Locker('prov-sys-locker', get_db_login())\n             ^^^^\nNameError: name 'pals' is not defined\n	{"children": []}	"('Refresh', UUID('b5edeee0-8425-446c-a73f-47e5a20ef3ce'), 'ceugarteblair', None, False, None, False)"	"{}"	provision_cmd_uuid	unit-test-org@%a112411f1046	2023-01-31 07:28:24.87183-05	\N
575	abdcdbde-58ce-4b20-b4d0-486eac999cde	SUCCESS	application/json	utf-8	true	2023-01-31 07:30:17.360137-05	\N	{"children": []}	"()"	"{}"	hourly_processing	default@%c469f6d97563	2023-01-31 07:30:17.360132-05	hourly processing
577	1a340e3a-faaf-40fd-926d-21e055f25a7f	SUCCESS	application/json	utf-8	true	2023-01-31 08:27:13.261442-05	\N	{"children": []}	"()"	"{}"	flush_expired_refresh_tokens	default@%34b1683e5aa4	2023-01-31 08:27:13.261398-05	flush expired refresh tokens
579	b0ff9280-1432-4894-b266-57497951f68e	SUCCESS	application/json	utf-8	true	2023-01-31 08:31:19.734347-05	\N	{"children": []}	"()"	"{}"	hourly_processing	default@%9c70b5b9a2d8	2023-01-31 08:31:19.734332-05	hourly processing
580	3131ed6c-ee30-4b76-96db-64d1b5a3cd88	SUCCESS	application/json	utf-8	true	2023-01-31 10:53:11.587347-05	\N	{"children": []}	"()"	"{}"	flush_expired_refresh_tokens	default@%f44b7f7dd453	2023-01-31 10:53:11.587303-05	flush expired refresh tokens
583	94e7e082-d355-48c0-a438-acd1dd4e27d6	SUCCESS	application/json	utf-8	true	2023-01-31 11:49:47.044148-05	\N	{"children": []}	"()"	"{}"	flush_expired_refresh_tokens	default@%4b49f0baf1fc	2023-01-31 11:49:47.044119-05	flush expired refresh tokens
585	7e9940b1-1e32-41fa-9c44-9a7187aa5f68	SUCCESS	application/json	utf-8	true	2023-02-01 09:25:47.989777-05	\N	{"children": []}	"()"	"{}"	flush_expired_refresh_tokens	default@%eeca0c0e1f99	2023-02-01 09:25:47.989748-05	flush expired refresh tokens
589	17e6b199-1380-4531-a56e-954a7185b2bf	SUCCESS	application/json	utf-8	true	2023-02-01 09:30:11.226531-05	\N	{"children": []}	"()"	"{}"	hourly_processing	default@%ef527d40128e	2023-02-01 09:30:11.226522-05	hourly processing
598	bb061dde-983e-4c32-865c-55b775c8fba4	SUCCESS	application/json	utf-8	true	2023-02-01 14:15:00.045522-05	\N	{"children": []}	"()"	"{}"	flush_expired_refresh_tokens	default@%3e19828d2081	2023-02-01 14:15:00.045474-05	flush expired refresh tokens
621	19e87f35-ae83-44bd-914e-0a1a8c1e8ffd	SUCCESS	application/json	utf-8	false	2023-02-02 00:30:01.0487-05	\N	{"children": []}	"()"	"{}"	hourly_processing	default@%5f721f5feee9	2023-02-02 00:30:01.048673-05	hourly processing
638	d7708033-1418-47a8-9173-d90a6e93c0d4	SUCCESS	application/json	utf-8	true	2023-02-02 09:15:00.028224-05	\N	{"children": []}	"()"	"{}"	flush_expired_refresh_tokens	default@%5f721f5feee9	2023-02-02 09:15:00.028213-05	flush expired refresh tokens
518	a494a7f9-6a93-4283-bb70-d9c08284b69b	SUCCESS	application/json	utf-8	true	2023-01-30 08:15:00.035657-05	\N	{"children": []}	"()"	"{}"	flush_expired_refresh_tokens	default@%7e2a53c89252	2023-01-30 08:15:00.035649-05	flush expired refresh tokens
523	879d2997-fbcb-4bd1-baea-ebd6a8722759	SUCCESS	application/json	utf-8	true	2023-01-30 10:35:16.486725-05	\N	{"children": []}	"()"	"{}"	hourly_processing	default@%ca7c4b5ed1b6	2023-01-30 10:35:16.486719-05	hourly processing
525	fbeebaf6-36cc-40da-8b20-bf409ae105b5	SUCCESS	application/json	utf-8	true	2023-01-30 13:43:16.659543-05	\N	{"children": []}	"()"	"{}"	hourly_processing	default@%4e576379ffab	2023-01-30 13:43:16.659535-05	hourly processing
531	ab4eb9d3-707d-4e63-b887-c320c438ce78	SUCCESS	application/json	utf-8	true	2023-01-30 15:30:07.977896-05	\N	{"children": []}	"()"	"{}"	hourly_processing	default@%933c0f7e7131	2023-01-30 15:30:07.977881-05	hourly processing
533	ca37755b-0a7b-47c7-ade9-a29ac33ae767	SUCCESS	application/json	utf-8	{"task": {"id": "ca37755b-0a7b-47c7-ade9-a29ac33ae767", "org_id": "b5edeee0-8425-446c-a73f-47e5a20ef3ce", "description": "AttributeError(\\"'Connection' object has no attribute 'connect'\\")", "lock_status": "unset", "cmd_status": ""}, "cqro_id": "c68aa7aa-01e3-433e-b84e-420db99bb1b6"}	2023-01-30 16:05:32.179911-05	\N	{"children": []}	"('Refresh', UUID('b5edeee0-8425-446c-a73f-47e5a20ef3ce'), 'ceugarteblair', None, False, None, False)"	"{}"	provision_cmd_uuid	unit-test-org@%1aa89ba7f8b6	2023-01-30 16:05:32.179903-05	\N
537	d9be64a0-536f-4ba4-876b-2d1b05886c5f	SUCCESS	application/json	utf-8	{"task": {"id": "d9be64a0-536f-4ba4-876b-2d1b05886c5f", "org_id": "b5edeee0-8425-446c-a73f-47e5a20ef3ce", "description": "AttributeError(\\"'Connection' object has no attribute 'connect'\\")", "lock_status": "unset", "cmd_status": ""}, "cqro_id": "60e592e3-0968-41ee-a069-0036b4e4a1cb"}	2023-01-30 16:31:10.129396-05	\N	{"children": []}	"('Refresh', UUID('b5edeee0-8425-446c-a73f-47e5a20ef3ce'), 'ceugarteblair', None, False, None, False)"	"{}"	provision_cmd_uuid	unit-test-org@%6e59a8df8ad7	2023-01-30 16:31:10.12939-05	\N
540	2efd1af4-1843-43da-a499-80db689ec1a3	SUCCESS	application/json	utf-8	true	2023-01-30 17:15:00.039181-05	\N	{"children": []}	"()"	"{}"	flush_expired_refresh_tokens	default@%a3d3b8fc775c	2023-01-30 17:15:00.039121-05	flush expired refresh tokens
542	3698750b-251f-41d8-8a27-ed8c0d726d50	SUCCESS	application/json	utf-8	{"task": {"id": "3698750b-251f-41d8-8a27-ed8c0d726d50", "org_id": "b5edeee0-8425-446c-a73f-47e5a20ef3ce", "description": "AttributeError(\\"'Connection' object has no attribute 'connect'\\")", "lock_status": "unset", "cmd_status": ""}, "cqro_id": "e868d611-b235-41eb-8c75-51c76f235bb2"}	2023-01-30 17:16:51.916947-05	\N	{"children": []}	"('Refresh', UUID('b5edeee0-8425-446c-a73f-47e5a20ef3ce'), 'ceugarteblair', None, False, None, False)"	"{}"	provision_cmd_uuid	unit-test-org@%1a54df768e38	2023-01-30 17:16:51.91694-05	\N
547	5954785f-2328-448f-a7d2-80732d2e96ca	FAILURE	application/json	utf-8	{"exc_type": "NameError", "exc_message": ["name 'pals' is not defined"], "exc_module": "builtins"}	2023-01-30 19:01:02.209557-05	Traceback (most recent call last):\n  File "/home/reg_user/.local/lib/python3.11/site-packages/celery/app/trace.py", line 451, in trace_task\n    R = retval = fun(*args, **kwargs)\n                 ^^^^^^^^^^^^^^^^^^^^\n  File "/home/reg_user/.local/lib/python3.11/site-packages/celery/app/trace.py", line 734, in __protected_call__\n    return self.run(*args, **kwargs)\n           ^^^^^^^^^^^^^^^^^^^^^^^^^\n  File "/home/reg_user/ps/users/tasks.py", line 1123, in provision_cmd_uuid\n    task_result = process_provision_cmd(ps_cmd=ps_cmd, uuid=uuid, username=username, deploy_values=deploy_values, task_result=task_result,last_one=last_one,onn_uuid=onn_uuid,reset=reset)\n                  ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File "/home/reg_user/ps/users/tasks.py", line 842, in process_provision_cmd\n    locker = pals.Locker('prov-sys-locker', get_db_login())\n             ^^^^\nNameError: name 'pals' is not defined\n	{"children": []}	"('Refresh', UUID('b5edeee0-8425-446c-a73f-47e5a20ef3ce'), 'ceugarteblair', None, False, None, False)"	"{}"	provision_cmd_uuid	unit-test-org@%67e9c3d9f403	2023-01-30 19:01:02.209524-05	\N
565	09db1487-a1fc-4b8b-8e6b-0f2f2f5965f0	SUCCESS	application/json	utf-8	true	2023-01-31 03:15:00.025096-05	\N	{"children": []}	"()"	"{}"	flush_expired_refresh_tokens	default@%67e9c3d9f403	2023-01-31 03:15:00.025088-05	flush expired refresh tokens
576	1656e2f0-8e6e-45f6-8940-af8ec1f21000	SUCCESS	application/json	utf-8	{"task": {"id": "1656e2f0-8e6e-45f6-8940-af8ec1f21000", "org_id": "b5edeee0-8425-446c-a73f-47e5a20ef3ce", "description": "Server completed Refresh unit-test-org in 0:00:33", "lock_status": "unset", "cmd_status": "SUCCESS"}, "cqro_id": "0937513a-477c-4f1d-90d3-474a73487177"}	2023-01-31 07:31:03.134089-05	\N	{"children": []}	"('Refresh', UUID('b5edeee0-8425-446c-a73f-47e5a20ef3ce'), 'ceugarteblair', None, False, None, False)"	"{}"	provision_cmd_uuid	unit-test-org@%c469f6d97563	2023-01-31 07:31:03.13408-05	\N
578	ec3813a3-1bc6-4e07-911c-4074056413b1	SUCCESS	application/json	utf-8	{"task": {"id": "ec3813a3-1bc6-4e07-911c-4074056413b1", "org_id": "b5edeee0-8425-446c-a73f-47e5a20ef3ce", "description": "Server completed Refresh unit-test-org in 0:00:33", "lock_status": "unset", "cmd_status": "SUCCESS"}, "cqro_id": "1e7037d9-6256-4996-adc0-c9a0034e4cfd"}	2023-01-31 08:27:54.207332-05	\N	{"children": []}	"('Refresh', UUID('b5edeee0-8425-446c-a73f-47e5a20ef3ce'), 'ceugarteblair', None, False, None, False)"	"{}"	provision_cmd_uuid	unit-test-org@%34b1683e5aa4	2023-01-31 08:27:54.207318-05	\N
581	6f8d46ce-d279-498a-beed-3a30d9f434d4	SUCCESS	application/json	utf-8	true	2023-01-31 10:53:13.492171-05	\N	{"children": []}	"()"	"{}"	hourly_processing	default@%f44b7f7dd453	2023-01-31 10:53:13.492163-05	hourly processing
584	7b89f00f-27ce-4f08-9e22-b19ef3c28cd0	SUCCESS	application/json	utf-8	true	2023-01-31 11:49:48.689041-05	\N	{"children": []}	"()"	"{}"	hourly_processing	default@%4b49f0baf1fc	2023-01-31 11:49:48.689034-05	hourly processing
550	0c21d24b-4e47-4842-855d-8dcf0ebba73c	SUCCESS	application/json	utf-8	true	2023-01-30 20:15:00.034111-05	\N	{"children": []}	"()"	"{}"	flush_expired_refresh_tokens	default@%67e9c3d9f403	2023-01-30 20:15:00.034105-05	flush expired refresh tokens
568	6ab00921-af89-476b-8cd3-437738525968	SUCCESS	application/json	utf-8	false	2023-01-31 04:30:01.259551-05	\N	{"children": []}	"()"	"{}"	hourly_processing	default@%67e9c3d9f403	2023-01-31 04:30:01.259532-05	hourly processing
593	ef1bfcd9-ee7c-4335-9364-a37a2e0c74a8	SUCCESS	application/json	utf-8	true	2023-02-01 11:30:01.758549-05	\N	{"children": []}	"()"	"{}"	hourly_processing	default@%ef527d40128e	2023-02-01 11:30:01.758538-05	hourly processing
601	fa3bffd9-ab7b-4868-9b82-8a46e037729a	SUCCESS	application/json	utf-8	true	2023-02-01 15:30:02.070722-05	\N	{"children": []}	"()"	"{}"	hourly_processing	default@%3e19828d2081	2023-02-01 15:30:02.070713-05	hourly processing
586	e3b1f3ae-1364-4c14-b4ed-bc21047afd8f	FAILURE	application/json	utf-8	{"exc_type": "IntegrityError", "exc_message": ["update or delete on table \\"django_celery_results_taskresult\\" violates foreign key constraint \\"users_pscmdqueueresu_task_result_id_01ba48ff_fk_django_ce\\" on table \\"users_pscmdqueueresult\\"\\nDETAIL:  Key (id)=(538) is still referenced from table \\"users_pscmdqueueresult\\".\\n"], "exc_module": "django.db.utils"}	2023-02-01 09:25:47.993911-05	Traceback (most recent call last):\n  File "/home/reg_user/.local/lib/python3.11/site-packages/django/db/backends/base/base.py", line 306, in _commit\n    return self.connection.commit()\n           ^^^^^^^^^^^^^^^^^^^^^^^^\npsycopg2.errors.ForeignKeyViolation: update or delete on table "django_celery_results_taskresult" violates foreign key constraint "users_pscmdqueueresu_task_result_id_01ba48ff_fk_django_ce" on table "users_pscmdqueueresult"\nDETAIL:  Key (id)=(538) is still referenced from table "users_pscmdqueueresult".\n\n\nThe above exception was the direct cause of the following exception:\n\nTraceback (most recent call last):\n  File "/home/reg_user/.local/lib/python3.11/site-packages/celery/app/trace.py", line 451, in trace_task\n    R = retval = fun(*args, **kwargs)\n                 ^^^^^^^^^^^^^^^^^^^^\n  File "/home/reg_user/.local/lib/python3.11/site-packages/celery/app/trace.py", line 734, in __protected_call__\n    return self.run(*args, **kwargs)\n           ^^^^^^^^^^^^^^^^^^^^^^^^^\n  File "/home/reg_user/.local/lib/python3.11/site-packages/celery/app/builtins.py", line 22, in backend_cleanup\n    app.backend.cleanup()\n  File "/home/reg_user/.local/lib/python3.11/site-packages/django_celery_results/backends/database.py", line 182, in cleanup\n    self.TaskModel._default_manager.delete_expired(self.expires)\n  File "/home/reg_user/.local/lib/python3.11/site-packages/django_celery_results/managers.py", line 90, in delete_expired\n    with transaction.atomic(using=self.db):\n  File "/home/reg_user/.local/lib/python3.11/site-packages/django/db/transaction.py", line 262, in __exit__\n    connection.commit()\n  File "/home/reg_user/.local/lib/python3.11/site-packages/django/utils/asyncio.py", line 26, in inner\n    return func(*args, **kwargs)\n           ^^^^^^^^^^^^^^^^^^^^^\n  File "/home/reg_user/.local/lib/python3.11/site-packages/django/db/backends/base/base.py", line 330, in commit\n    self._commit()\n  File "/home/reg_user/.local/lib/python3.11/site-packages/django/db/backends/base/base.py", line 305, in _commit\n    with self.wrap_database_errors:\n  File "/home/reg_user/.local/lib/python3.11/site-packages/django/db/utils.py", line 91, in __exit__\n    raise dj_exc_value.with_traceback(traceback) from exc_value\n  File "/home/reg_user/.local/lib/python3.11/site-packages/django/db/backends/base/base.py", line 306, in _commit\n    return self.connection.commit()\n           ^^^^^^^^^^^^^^^^^^^^^^^^\ndjango.db.utils.IntegrityError: update or delete on table "django_celery_results_taskresult" violates foreign key constraint "users_pscmdqueueresu_task_result_id_01ba48ff_fk_django_ce" on table "users_pscmdqueueresult"\nDETAIL:  Key (id)=(538) is still referenced from table "users_pscmdqueueresult".\n\n	{"children": []}	"()"	"{}"	celery.backend_cleanup	default@%eeca0c0e1f99	2023-02-01 09:25:47.993903-05	celery.backend_cleanup
590	06ba2130-ad48-40a2-a58e-9969b8fc1271	SUCCESS	application/json	utf-8	true	2023-02-01 10:15:00.028425-05	\N	{"children": []}	"()"	"{}"	flush_expired_refresh_tokens	default@%ef527d40128e	2023-02-01 10:15:00.028417-05	flush expired refresh tokens
519	cef1030b-ecf9-498f-8d73-bb7534891d9e	SUCCESS	application/json	utf-8	true	2023-01-30 08:30:01.610475-05	\N	{"children": []}	"()"	"{}"	hourly_processing	default@%7e2a53c89252	2023-01-30 08:30:01.610466-05	hourly processing
534	a1cfd3a8-fb3f-4472-8cf1-045f3abde4c6	SUCCESS	application/json	utf-8	true	2023-01-30 16:15:00.028882-05	\N	{"children": []}	"()"	"{}"	flush_expired_refresh_tokens	default@%1aa89ba7f8b6	2023-01-30 16:15:00.028871-05	flush expired refresh tokens
543	8a79e318-fc61-4a6d-88a5-a91d8762232a	SUCCESS	application/json	utf-8	true	2023-01-30 17:30:01.481744-05	\N	{"children": []}	"()"	"{}"	hourly_processing	default@%1a54df768e38	2023-01-30 17:30:01.481733-05	hourly processing
548	62303e83-b017-4ebe-8746-e7a4fe76511d	SUCCESS	application/json	utf-8	true	2023-01-30 19:15:00.030665-05	\N	{"children": []}	"()"	"{}"	flush_expired_refresh_tokens	default@%67e9c3d9f403	2023-01-30 19:15:00.030653-05	flush expired refresh tokens
566	ca4b0273-411c-4a95-ac5d-1b6e34de7050	SUCCESS	application/json	utf-8	false	2023-01-31 03:30:01.388934-05	\N	{"children": []}	"()"	"{}"	hourly_processing	default@%67e9c3d9f403	2023-01-31 03:30:01.38891-05	hourly processing
582	e6b2de0a-f01f-4a7d-a991-58c289c33315	SUCCESS	application/json	utf-8	{"task": {"id": "e6b2de0a-f01f-4a7d-a991-58c289c33315", "org_id": "b5edeee0-8425-446c-a73f-47e5a20ef3ce", "description": "Server completed Refresh unit-test-org in 0:00:34", "lock_status": "unset", "cmd_status": "SUCCESS"}, "cqro_id": "208cf07e-4c37-453f-bbff-63e696f875a9"}	2023-01-31 10:54:05.688417-05	\N	{"children": []}	"('Refresh', UUID('b5edeee0-8425-446c-a73f-47e5a20ef3ce'), 'ceugarteblair', None, False, None, False)"	"{}"	provision_cmd_uuid	unit-test-org@%f44b7f7dd453	2023-01-31 10:54:05.688411-05	\N
587	7e83d107-1edf-4e1c-9679-fec226c2d9e1	SUCCESS	application/json	utf-8	null	2023-02-01 09:25:47.995568-05	\N	{"children": []}	"()"	"{}"	purge_ps_cmd_que_rslts	default@%eeca0c0e1f99	2023-02-01 09:25:47.99555-05	purge_ps_cmd_que_rslts
591	b59ed560-c8e5-4e2a-a30b-9cd56ffdc131	SUCCESS	application/json	utf-8	true	2023-02-01 10:30:01.535378-05	\N	{"children": []}	"()"	"{}"	hourly_processing	default@%ef527d40128e	2023-02-01 10:30:01.535366-05	hourly processing
599	67d247ff-d04b-4959-afc5-7df7e5cb7d11	SUCCESS	application/json	utf-8	false	2023-02-01 14:30:20.424567-05	\N	{"children": []}	"()"	"{}"	hourly_processing	default@%3e19828d2081	2023-02-01 14:30:20.424535-05	hourly processing
622	a8a647ba-5ced-4812-9cf8-1d8c387adb2a	SUCCESS	application/json	utf-8	true	2023-02-02 01:15:00.040704-05	\N	{"children": []}	"()"	"{}"	flush_expired_refresh_tokens	default@%5f721f5feee9	2023-02-02 01:15:00.040696-05	flush expired refresh tokens
639	2aeccfc4-dc2d-420f-a13f-48becff175cf	SUCCESS	application/json	utf-8	false	2023-02-02 09:30:01.353775-05	\N	{"children": []}	"()"	"{}"	hourly_processing	default@%5f721f5feee9	2023-02-02 09:30:01.353758-05	hourly processing
520	4a8b8ec1-228c-4ebe-9c8a-0e2aa1757865	SUCCESS	application/json	utf-8	true	2023-01-30 09:15:00.033559-05	\N	{"children": []}	"()"	"{}"	flush_expired_refresh_tokens	default@%7e2a53c89252	2023-01-30 09:15:00.033551-05	flush expired refresh tokens
535	5cf48dc1-c851-4b4f-9cfc-ea98e99223e1	SUCCESS	application/json	utf-8	true	2023-01-30 16:30:02.968927-05	\N	{"children": []}	"()"	"{}"	hourly_processing	default@%1aa89ba7f8b6	2023-01-30 16:30:02.968908-05	hourly processing
544	544d154d-cf31-4d14-8451-12753d21045e	SUCCESS	application/json	utf-8	true	2023-01-30 18:15:00.046398-05	\N	{"children": []}	"()"	"{}"	flush_expired_refresh_tokens	default@%1a54df768e38	2023-01-30 18:15:00.046339-05	flush expired refresh tokens
549	5ccced48-0f4d-4442-94cd-3a4001b2345e	SUCCESS	application/json	utf-8	false	2023-01-30 19:30:01.102651-05	\N	{"children": []}	"()"	"{}"	hourly_processing	default@%67e9c3d9f403	2023-01-30 19:30:01.102633-05	hourly processing
567	5b70ca3c-e4bc-42de-bfe9-609ca643de5e	SUCCESS	application/json	utf-8	true	2023-01-31 04:15:00.025629-05	\N	{"children": []}	"()"	"{}"	flush_expired_refresh_tokens	default@%67e9c3d9f403	2023-01-31 04:15:00.025615-05	flush expired refresh tokens
588	f689a524-1183-4f9d-91a9-fbb42e2ba5b1	SUCCESS	application/json	utf-8	false	2023-02-01 09:25:55.905143-05	\N	{"children": []}	"()"	"{}"	hourly_processing	default@%eeca0c0e1f99	2023-02-01 09:25:55.905135-05	hourly processing
592	9e8c4c5a-2049-4727-ab73-a16379546482	SUCCESS	application/json	utf-8	true	2023-02-01 11:15:00.03538-05	\N	{"children": []}	"()"	"{}"	flush_expired_refresh_tokens	default@%ef527d40128e	2023-02-01 11:15:00.035371-05	flush expired refresh tokens
600	669f2d9f-2908-4f5b-afe4-22cf8ae193d5	SUCCESS	application/json	utf-8	true	2023-02-01 15:15:00.029997-05	\N	{"children": []}	"()"	"{}"	flush_expired_refresh_tokens	default@%3e19828d2081	2023-02-01 15:15:00.029988-05	flush expired refresh tokens
606	31e76eb7-6f2f-4870-ac3c-e6a533b23857	SUCCESS	application/json	utf-8	true	2023-02-01 18:15:00.046251-05	\N	{"children": []}	"()"	"{}"	flush_expired_refresh_tokens	default@%5f721f5feee9	2023-02-01 18:15:00.046211-05	flush expired refresh tokens
623	20bdb748-98c2-4c74-a34a-6390384c2bc9	SUCCESS	application/json	utf-8	false	2023-02-02 01:30:01.039036-05	\N	{"children": []}	"()"	"{}"	hourly_processing	default@%5f721f5feee9	2023-02-02 01:30:01.039007-05	hourly processing
640	5e696923-1861-4177-8c81-ddd07fffc0f9	SUCCESS	application/json	utf-8	true	2023-02-02 10:15:00.033934-05	\N	{"children": []}	"()"	"{}"	flush_expired_refresh_tokens	default@%5f721f5feee9	2023-02-02 10:15:00.033923-05	flush expired refresh tokens
641	75d23ef3-dcb2-4e97-8401-227348a6e508	SUCCESS	application/json	utf-8	true	2023-02-02 13:25:23.067282-05	\N	{"children": []}	"()"	"{}"	flush_expired_refresh_tokens	default@%530d94465a81	2023-02-02 13:25:23.067231-05	flush expired refresh tokens
521	3ed95e35-b148-438a-8745-33c72677076f	SUCCESS	application/json	utf-8	true	2023-01-30 09:30:01.670846-05	\N	{"children": []}	"()"	"{}"	hourly_processing	default@%7e2a53c89252	2023-01-30 09:30:01.670838-05	hourly processing
545	7ab2cf2b-a6da-4be5-a7ca-5be338931557	SUCCESS	application/json	utf-8	true	2023-01-30 18:30:01.818714-05	\N	{"children": []}	"()"	"{}"	hourly_processing	default@%1a54df768e38	2023-01-30 18:30:01.818702-05	hourly processing
607	c664a6c1-9365-4201-8668-544d4b44141c	SUCCESS	application/json	utf-8	true	2023-02-01 18:30:10.578209-05	\N	{"children": []}	"()"	"{}"	hourly_processing	default@%5f721f5feee9	2023-02-01 18:30:10.578197-05	hourly processing
624	7c790768-06c5-44af-b2d7-f88287818a17	SUCCESS	application/json	utf-8	true	2023-02-02 02:15:00.034538-05	\N	{"children": []}	"()"	"{}"	flush_expired_refresh_tokens	default@%5f721f5feee9	2023-02-02 02:15:00.034529-05	flush expired refresh tokens
642	3356f874-f295-4ebe-a543-20c4689276b7	SUCCESS	application/json	utf-8	true	2023-02-02 13:25:29.381575-05	\N	{"children": []}	"()"	"{}"	hourly_processing	default@%530d94465a81	2023-02-02 13:25:29.381566-05	hourly processing
551	0b39e8c1-4c33-42ce-a2cb-70e753ae6879	SUCCESS	application/json	utf-8	false	2023-01-30 20:30:01.026864-05	\N	{"children": []}	"()"	"{}"	hourly_processing	default@%67e9c3d9f403	2023-01-30 20:30:01.026839-05	hourly processing
569	03382dad-c501-4ac0-9b7b-4d1e5e616c39	SUCCESS	application/json	utf-8	true	2023-01-31 05:15:00.027512-05	\N	{"children": []}	"()"	"{}"	flush_expired_refresh_tokens	default@%67e9c3d9f403	2023-01-31 05:15:00.027497-05	flush expired refresh tokens
594	7e893c53-3678-4b5f-8735-efa0afaba9ed	SUCCESS	application/json	utf-8	true	2023-02-01 12:15:00.032619-05	\N	{"children": []}	"()"	"{}"	flush_expired_refresh_tokens	default@%ef527d40128e	2023-02-01 12:15:00.03261-05	flush expired refresh tokens
602	8adc6952-4726-4eb4-9bf1-64e8273393ba	SUCCESS	application/json	utf-8	true	2023-02-01 16:15:00.029455-05	\N	{"children": []}	"()"	"{}"	flush_expired_refresh_tokens	default@%3e19828d2081	2023-02-01 16:15:00.029442-05	flush expired refresh tokens
608	2d9127e9-4f6b-479a-80b1-b78932945771	SUCCESS	application/json	utf-8	null	2023-02-01 19:00:00.041132-05	\N	{"children": []}	"()"	"{}"	purge_ps_cmd_que_rslts	default@%5f721f5feee9	2023-02-01 19:00:00.041124-05	purge_ps_cmd_que_rslts
625	8197f256-a1e6-4f2e-bd27-0c3f08ef472c	SUCCESS	application/json	utf-8	false	2023-02-02 02:30:01.568962-05	\N	{"children": []}	"()"	"{}"	hourly_processing	default@%5f721f5feee9	2023-02-02 02:30:01.568947-05	hourly processing
643	8391a80d-611e-4e8f-8b2f-934f1e93a380	SUCCESS	application/json	utf-8	true	2023-02-02 13:30:13.180149-05	\N	{"children": []}	"()"	"{}"	hourly_processing	default@%530d94465a81	2023-02-02 13:30:13.180137-05	hourly processing
552	0a86ada1-2dc0-4284-88ea-f89d27cc646d	SUCCESS	application/json	utf-8	true	2023-01-30 21:15:00.033393-05	\N	{"children": []}	"()"	"{}"	flush_expired_refresh_tokens	default@%67e9c3d9f403	2023-01-30 21:15:00.033387-05	flush expired refresh tokens
570	ffeaf477-2629-41c0-9b88-ae9de0f5223a	SUCCESS	application/json	utf-8	false	2023-01-31 05:30:01.26114-05	\N	{"children": []}	"()"	"{}"	hourly_processing	default@%67e9c3d9f403	2023-01-31 05:30:01.261112-05	hourly processing
595	730d774e-f01a-402c-94cf-59194c206ed1	SUCCESS	application/json	utf-8	true	2023-02-01 12:30:01.815543-05	\N	{"children": []}	"()"	"{}"	hourly_processing	default@%ef527d40128e	2023-02-01 12:30:01.815533-05	hourly processing
603	56817aa3-04fd-4383-bc0d-520f78ea2247	SUCCESS	application/json	utf-8	true	2023-02-01 16:30:01.812689-05	\N	{"children": []}	"()"	"{}"	hourly_processing	default@%3e19828d2081	2023-02-01 16:30:01.812681-05	hourly processing
609	d856a044-8153-4908-9b5a-b8a89f7fdaaf	SUCCESS	application/json	utf-8	true	2023-02-01 19:15:00.032655-05	\N	{"children": []}	"()"	"{}"	flush_expired_refresh_tokens	default@%5f721f5feee9	2023-02-01 19:15:00.032647-05	flush expired refresh tokens
626	b096aae5-aa14-4b8b-8021-f815104a7127	SUCCESS	application/json	utf-8	true	2023-02-02 03:15:00.03254-05	\N	{"children": []}	"()"	"{}"	flush_expired_refresh_tokens	default@%5f721f5feee9	2023-02-02 03:15:00.03253-05	flush expired refresh tokens
553	a78f5260-5a11-45a7-9f34-82da3173a262	SUCCESS	application/json	utf-8	false	2023-01-30 21:30:01.103059-05	\N	{"children": []}	"()"	"{}"	hourly_processing	default@%67e9c3d9f403	2023-01-30 21:30:01.103035-05	hourly processing
571	2a0bb619-5339-4937-9347-f0f3c67f9afb	SUCCESS	application/json	utf-8	true	2023-01-31 06:15:00.030848-05	\N	{"children": []}	"()"	"{}"	flush_expired_refresh_tokens	default@%67e9c3d9f403	2023-01-31 06:15:00.030841-05	flush expired refresh tokens
596	ecab8493-137a-4491-bb04-5e67bc06ff0b	SUCCESS	application/json	utf-8	true	2023-02-01 13:15:00.034593-05	\N	{"children": []}	"()"	"{}"	flush_expired_refresh_tokens	default@%ef527d40128e	2023-02-01 13:15:00.034584-05	flush expired refresh tokens
604	66e59ddd-a0d0-44f8-a3cc-ecf449b815fd	SUCCESS	application/json	utf-8	true	2023-02-01 17:15:00.024087-05	\N	{"children": []}	"()"	"{}"	flush_expired_refresh_tokens	default@%3e19828d2081	2023-02-01 17:15:00.024081-05	flush expired refresh tokens
610	841a01d8-b411-4078-8a11-8a3a332374f6	SUCCESS	application/json	utf-8	true	2023-02-01 19:30:01.768911-05	\N	{"children": []}	"()"	"{}"	hourly_processing	default@%5f721f5feee9	2023-02-01 19:30:01.768905-05	hourly processing
627	d9728424-1537-47b5-b3c5-9cbcb6475c75	SUCCESS	application/json	utf-8	false	2023-02-02 03:30:01.320014-05	\N	{"children": []}	"()"	"{}"	hourly_processing	default@%5f721f5feee9	2023-02-02 03:30:01.320002-05	hourly processing
554	9446d95a-5899-4926-b4b7-f918bfe44fcb	SUCCESS	application/json	utf-8	true	2023-01-30 22:15:00.033506-05	\N	{"children": []}	"()"	"{}"	flush_expired_refresh_tokens	default@%67e9c3d9f403	2023-01-30 22:15:00.033499-05	flush expired refresh tokens
572	0e348bd7-5852-4a10-ba50-dd8734a7958b	SUCCESS	application/json	utf-8	false	2023-01-31 06:30:01.4151-05	\N	{"children": []}	"()"	"{}"	hourly_processing	default@%67e9c3d9f403	2023-01-31 06:30:01.415078-05	hourly processing
597	2a4a2f66-653e-436a-8346-48ab3b38e271	SUCCESS	application/json	utf-8	true	2023-02-01 13:30:01.848731-05	\N	{"children": []}	"()"	"{}"	hourly_processing	default@%ef527d40128e	2023-02-01 13:30:01.848726-05	hourly processing
605	64a701db-4866-4a60-9828-76b4f5a6f6ad	SUCCESS	application/json	utf-8	true	2023-02-01 17:30:05.566095-05	\N	{"children": []}	"()"	"{}"	hourly_processing	default@%3e19828d2081	2023-02-01 17:30:05.56609-05	hourly processing
611	11e1233a-fd4f-400f-81db-a90fb1c4ba98	SUCCESS	application/json	utf-8	true	2023-02-01 20:15:00.034692-05	\N	{"children": []}	"()"	"{}"	flush_expired_refresh_tokens	default@%5f721f5feee9	2023-02-01 20:15:00.034682-05	flush expired refresh tokens
628	2b64c98f-9fe6-4244-8822-a01ee3221a86	SUCCESS	application/json	utf-8	true	2023-02-02 04:15:00.036646-05	\N	{"children": []}	"()"	"{}"	flush_expired_refresh_tokens	default@%5f721f5feee9	2023-02-02 04:15:00.036637-05	flush expired refresh tokens
555	a39e9db6-faf5-42d7-b8b4-9d887dab6176	SUCCESS	application/json	utf-8	false	2023-01-30 22:30:01.075896-05	\N	{"children": []}	"()"	"{}"	hourly_processing	default@%67e9c3d9f403	2023-01-30 22:30:01.075866-05	hourly processing
573	188a7720-bf0c-40b7-8363-2bbd84e556de	SUCCESS	application/json	utf-8	true	2023-01-31 07:15:00.035031-05	\N	{"children": []}	"()"	"{}"	flush_expired_refresh_tokens	default@%67e9c3d9f403	2023-01-31 07:15:00.035022-05	flush expired refresh tokens
612	59be8ab5-78a8-4e69-915b-40871373faa7	SUCCESS	application/json	utf-8	true	2023-02-01 20:30:01.753147-05	\N	{"children": []}	"()"	"{}"	hourly_processing	default@%5f721f5feee9	2023-02-01 20:30:01.753135-05	hourly processing
629	c21cf564-c98b-483c-b3e8-8e10956fec99	SUCCESS	application/json	utf-8	false	2023-02-02 04:30:01.352833-05	\N	{"children": []}	"()"	"{}"	hourly_processing	default@%5f721f5feee9	2023-02-02 04:30:01.352811-05	hourly processing
556	a8230274-b3c6-40b1-aaab-9e58a64c9145	SUCCESS	application/json	utf-8	null	2023-01-30 23:00:00.035968-05	\N	{"children": []}	"()"	"{}"	celery.backend_cleanup	default@%67e9c3d9f403	2023-01-30 23:00:00.035962-05	celery.backend_cleanup
613	5394215d-c8e1-4605-991f-dd2127fb7010	SUCCESS	application/json	utf-8	true	2023-02-01 21:15:00.032039-05	\N	{"children": []}	"()"	"{}"	flush_expired_refresh_tokens	default@%5f721f5feee9	2023-02-01 21:15:00.032029-05	flush expired refresh tokens
630	3c73af10-aabc-4d4d-b345-d39898aface9	SUCCESS	application/json	utf-8	true	2023-02-02 05:15:00.024193-05	\N	{"children": []}	"()"	"{}"	flush_expired_refresh_tokens	default@%5f721f5feee9	2023-02-02 05:15:00.024185-05	flush expired refresh tokens
557	a9c34d0d-9bac-4fba-93f9-409b6acf51f9	SUCCESS	application/json	utf-8	true	2023-01-30 23:15:00.023506-05	\N	{"children": []}	"()"	"{}"	flush_expired_refresh_tokens	default@%67e9c3d9f403	2023-01-30 23:15:00.023499-05	flush expired refresh tokens
614	044f3a44-6d61-4e70-93f0-01983aa5ecc6	SUCCESS	application/json	utf-8	false	2023-02-01 21:30:01.077842-05	\N	{"children": []}	"()"	"{}"	hourly_processing	default@%5f721f5feee9	2023-02-01 21:30:01.077815-05	hourly processing
631	18e6e0d8-ce3c-4c6e-9428-31c991dbb11d	SUCCESS	application/json	utf-8	false	2023-02-02 05:30:01.342984-05	\N	{"children": []}	"()"	"{}"	hourly_processing	default@%5f721f5feee9	2023-02-02 05:30:01.342957-05	hourly processing
558	c1a14029-c65a-44d4-a622-08c837f84067	SUCCESS	application/json	utf-8	false	2023-01-30 23:30:00.989792-05	\N	{"children": []}	"()"	"{}"	hourly_processing	default@%67e9c3d9f403	2023-01-30 23:30:00.989767-05	hourly processing
615	b23c2ed5-2ed3-4bab-bc55-06b6ef5091f3	SUCCESS	application/json	utf-8	true	2023-02-01 22:15:00.029857-05	\N	{"children": []}	"()"	"{}"	flush_expired_refresh_tokens	default@%5f721f5feee9	2023-02-01 22:15:00.029849-05	flush expired refresh tokens
632	37a1269b-f54f-4ff7-8b44-70c9e30d24cb	SUCCESS	application/json	utf-8	true	2023-02-02 06:15:00.035345-05	\N	{"children": []}	"()"	"{}"	flush_expired_refresh_tokens	default@%5f721f5feee9	2023-02-02 06:15:00.035336-05	flush expired refresh tokens
559	3fe55634-3efb-4c19-875b-5d01556436b7	SUCCESS	application/json	utf-8	true	2023-01-31 00:15:00.012158-05	\N	{"children": []}	"()"	"{}"	flush_expired_refresh_tokens	default@%67e9c3d9f403	2023-01-31 00:15:00.012151-05	flush expired refresh tokens
616	3bf36fbb-c00d-4c72-b6ee-3ae50091fe46	SUCCESS	application/json	utf-8	false	2023-02-01 22:30:01.095547-05	\N	{"children": []}	"()"	"{}"	hourly_processing	default@%5f721f5feee9	2023-02-01 22:30:01.095532-05	hourly processing
633	5df2125e-8370-4d17-b25d-ba20adf3f484	SUCCESS	application/json	utf-8	false	2023-02-02 06:30:01.378065-05	\N	{"children": []}	"()"	"{}"	hourly_processing	default@%5f721f5feee9	2023-02-02 06:30:01.378047-05	hourly processing
560	b599e142-4801-4704-a89f-d7562273880f	SUCCESS	application/json	utf-8	false	2023-01-31 00:30:01.289333-05	\N	{"children": []}	"()"	"{}"	hourly_processing	default@%67e9c3d9f403	2023-01-31 00:30:01.289308-05	hourly processing
617	1fea3fa2-f484-48a6-a47e-639ae3011181	FAILURE	application/json	utf-8	{"exc_type": "IntegrityError", "exc_message": ["update or delete on table \\"django_celery_results_taskresult\\" violates foreign key constraint \\"users_pscmdqueueresu_task_result_id_01ba48ff_fk_django_ce\\" on table \\"users_pscmdqueueresult\\"\\nDETAIL:  Key (id)=(538) is still referenced from table \\"users_pscmdqueueresult\\".\\n"], "exc_module": "django.db.utils"}	2023-02-01 23:00:00.035199-05	Traceback (most recent call last):\n  File "/home/reg_user/.local/lib/python3.11/site-packages/django/db/backends/base/base.py", line 306, in _commit\n    return self.connection.commit()\n           ^^^^^^^^^^^^^^^^^^^^^^^^\npsycopg2.errors.ForeignKeyViolation: update or delete on table "django_celery_results_taskresult" violates foreign key constraint "users_pscmdqueueresu_task_result_id_01ba48ff_fk_django_ce" on table "users_pscmdqueueresult"\nDETAIL:  Key (id)=(538) is still referenced from table "users_pscmdqueueresult".\n\n\nThe above exception was the direct cause of the following exception:\n\nTraceback (most recent call last):\n  File "/home/reg_user/.local/lib/python3.11/site-packages/celery/app/trace.py", line 451, in trace_task\n    R = retval = fun(*args, **kwargs)\n                 ^^^^^^^^^^^^^^^^^^^^\n  File "/home/reg_user/.local/lib/python3.11/site-packages/celery/app/trace.py", line 734, in __protected_call__\n    return self.run(*args, **kwargs)\n           ^^^^^^^^^^^^^^^^^^^^^^^^^\n  File "/home/reg_user/.local/lib/python3.11/site-packages/celery/app/builtins.py", line 22, in backend_cleanup\n    app.backend.cleanup()\n  File "/home/reg_user/.local/lib/python3.11/site-packages/django_celery_results/backends/database.py", line 182, in cleanup\n    self.TaskModel._default_manager.delete_expired(self.expires)\n  File "/home/reg_user/.local/lib/python3.11/site-packages/django_celery_results/managers.py", line 90, in delete_expired\n    with transaction.atomic(using=self.db):\n  File "/home/reg_user/.local/lib/python3.11/site-packages/django/db/transaction.py", line 262, in __exit__\n    connection.commit()\n  File "/home/reg_user/.local/lib/python3.11/site-packages/django/utils/asyncio.py", line 26, in inner\n    return func(*args, **kwargs)\n           ^^^^^^^^^^^^^^^^^^^^^\n  File "/home/reg_user/.local/lib/python3.11/site-packages/django/db/backends/base/base.py", line 330, in commit\n    self._commit()\n  File "/home/reg_user/.local/lib/python3.11/site-packages/django/db/backends/base/base.py", line 305, in _commit\n    with self.wrap_database_errors:\n  File "/home/reg_user/.local/lib/python3.11/site-packages/django/db/utils.py", line 91, in __exit__\n    raise dj_exc_value.with_traceback(traceback) from exc_value\n  File "/home/reg_user/.local/lib/python3.11/site-packages/django/db/backends/base/base.py", line 306, in _commit\n    return self.connection.commit()\n           ^^^^^^^^^^^^^^^^^^^^^^^^\ndjango.db.utils.IntegrityError: update or delete on table "django_celery_results_taskresult" violates foreign key constraint "users_pscmdqueueresu_task_result_id_01ba48ff_fk_django_ce" on table "users_pscmdqueueresult"\nDETAIL:  Key (id)=(538) is still referenced from table "users_pscmdqueueresult".\n\n	{"children": []}	"()"	"{}"	celery.backend_cleanup	default@%5f721f5feee9	2023-02-01 23:00:00.035184-05	celery.backend_cleanup
634	80f2b80b-fba5-44c7-b422-ccc88e7f5c8c	SUCCESS	application/json	utf-8	true	2023-02-02 07:15:00.029663-05	\N	{"children": []}	"()"	"{}"	flush_expired_refresh_tokens	default@%5f721f5feee9	2023-02-02 07:15:00.029653-05	flush expired refresh tokens
561	17de0a07-5bb2-45e2-9f51-262e6f077d81	SUCCESS	application/json	utf-8	true	2023-01-31 01:15:00.02989-05	\N	{"children": []}	"()"	"{}"	flush_expired_refresh_tokens	default@%67e9c3d9f403	2023-01-31 01:15:00.029878-05	flush expired refresh tokens
618	dd9936cf-6f7a-47e1-8621-31a9eff96b78	SUCCESS	application/json	utf-8	true	2023-02-01 23:15:00.027707-05	\N	{"children": []}	"()"	"{}"	flush_expired_refresh_tokens	default@%5f721f5feee9	2023-02-01 23:15:00.027697-05	flush expired refresh tokens
635	6e974365-c113-4b16-a5b8-1645e814e168	SUCCESS	application/json	utf-8	false	2023-02-02 07:30:01.512132-05	\N	{"children": []}	"()"	"{}"	hourly_processing	default@%5f721f5feee9	2023-02-02 07:30:01.512111-05	hourly processing
512	33737b4d-d42c-413f-8a92-db52e6dfabbf	SUCCESS	application/json	utf-8	true	2023-01-30 07:13:08.134793-05	\N	{"children": []}	"()"	"{}"	flush_expired_refresh_tokens	default@%7e2a53c89252	2023-01-30 07:13:08.134762-05	flush expired refresh tokens
513	fcc0728b-5375-487a-a293-ea24b0c09cb6	SUCCESS	application/json	utf-8	null	2023-01-30 07:13:08.141859-05	\N	{"children": []}	"()"	"{}"	celery.backend_cleanup	default@%7e2a53c89252	2023-01-30 07:13:08.141847-05	celery.backend_cleanup
514	11240280-b421-4f58-86e4-97b655d0d273	SUCCESS	application/json	utf-8	null	2023-01-30 07:13:08.144804-05	\N	{"children": []}	"()"	"{}"	purge_ps_cmd_que_rslts	default@%7e2a53c89252	2023-01-30 07:13:08.144791-05	purge_ps_cmd_que_rslts
515	815a7f85-fb46-4c14-8073-6b38f59eabbd	SUCCESS	application/json	utf-8	true	2023-01-30 07:13:20.346192-05	\N	{"children": []}	"()"	"{}"	hourly_processing	default@%7e2a53c89252	2023-01-30 07:13:20.346186-05	hourly processing
562	1459d176-8c37-49d3-8075-802344817a31	SUCCESS	application/json	utf-8	false	2023-01-31 01:30:01.269541-05	\N	{"children": []}	"()"	"{}"	hourly_processing	default@%67e9c3d9f403	2023-01-31 01:30:01.269514-05	hourly processing
619	7217e6f9-40bd-4dad-a4ca-92acd6abdda8	SUCCESS	application/json	utf-8	false	2023-02-01 23:30:01.032513-05	\N	{"children": []}	"()"	"{}"	hourly_processing	default@%5f721f5feee9	2023-02-01 23:30:01.032489-05	hourly processing
636	a0e5142b-d251-4748-84c1-e7fcc8144962	SUCCESS	application/json	utf-8	true	2023-02-02 08:15:00.033639-05	\N	{"children": []}	"()"	"{}"	flush_expired_refresh_tokens	default@%5f721f5feee9	2023-02-02 08:15:00.03363-05	flush expired refresh tokens
644	acc8b1f6-d229-4b1b-aad3-10661ce05060	SUCCESS	application/json	utf-8	true	2023-02-02 14:28:46.678135-05	\N	{"children": []}	"()"	"{}"	flush_expired_refresh_tokens	default@%689c7fe0c401	2023-02-02 14:28:46.678096-05	flush expired refresh tokens
645	37fa9554-2f28-40ee-b43d-d55f8fb8af48	SUCCESS	application/json	utf-8	true	2023-02-02 14:30:17.393417-05	\N	{"children": []}	"()"	"{}"	hourly_processing	default@%b79e124ac80e	2023-02-02 14:30:17.393407-05	hourly processing
646	a507c699-42a2-4bc3-a0f1-767fbcf04301	SUCCESS	application/json	utf-8	true	2023-02-02 15:15:00.043198-05	\N	{"children": []}	"()"	"{}"	flush_expired_refresh_tokens	default@%1c600d819599	2023-02-02 15:15:00.043155-05	flush expired refresh tokens
647	4fe0a086-0a9e-4256-ae2d-d6d13ff02e8e	SUCCESS	application/json	utf-8	true	2023-02-02 15:30:09.155147-05	\N	{"children": []}	"()"	"{}"	hourly_processing	default@%7fb469452853	2023-02-02 15:30:09.155134-05	hourly processing
648	d2c5138e-fa1c-48f9-a55d-24392fc45d8e	SUCCESS	application/json	utf-8	true	2023-02-02 16:15:00.046487-05	\N	{"children": []}	"()"	"{}"	flush_expired_refresh_tokens	default@%87ce2843beb3	2023-02-02 16:15:00.046443-05	flush expired refresh tokens
649	63032bb5-3053-467d-87fe-80deeec272ba	SUCCESS	application/json	utf-8	true	2023-02-02 16:30:07.433656-05	\N	{"children": []}	"()"	"{}"	hourly_processing	default@%87ce2843beb3	2023-02-02 16:30:07.433649-05	hourly processing
650	8f7f0f4b-4ff4-49c3-962b-c4aad42b3f61	SUCCESS	application/json	utf-8	true	2023-02-02 17:15:00.035606-05	\N	{"children": []}	"()"	"{}"	flush_expired_refresh_tokens	default@%87ce2843beb3	2023-02-02 17:15:00.035591-05	flush expired refresh tokens
651	2036efc5-30dd-40f9-ac8b-7f0b6d046258	SUCCESS	application/json	utf-8	true	2023-02-02 17:30:01.527361-05	\N	{"children": []}	"()"	"{}"	hourly_processing	default@%87ce2843beb3	2023-02-02 17:30:01.527352-05	hourly processing
652	6fd22c72-2b3e-4d11-ab42-63ac72d59e18	SUCCESS	application/json	utf-8	true	2023-02-03 09:09:57.317983-05	\N	{"children": []}	"()"	"{}"	flush_expired_refresh_tokens	default@%bea43276f0aa	2023-02-03 09:09:57.317935-05	flush expired refresh tokens
653	bcc7efee-6864-4ec9-95e5-171c1080a579	FAILURE	application/json	utf-8	{"exc_type": "IntegrityError", "exc_message": ["update or delete on table \\"django_celery_results_taskresult\\" violates foreign key constraint \\"users_pscmdqueueresu_task_result_id_01ba48ff_fk_django_ce\\" on table \\"users_pscmdqueueresult\\"\\nDETAIL:  Key (id)=(538) is still referenced from table \\"users_pscmdqueueresult\\".\\n"], "exc_module": "django.db.utils"}	2023-02-03 09:09:57.320378-05	Traceback (most recent call last):\n  File "/home/reg_user/.local/lib/python3.11/site-packages/django/db/backends/base/base.py", line 306, in _commit\n    return self.connection.commit()\n           ^^^^^^^^^^^^^^^^^^^^^^^^\npsycopg2.errors.ForeignKeyViolation: update or delete on table "django_celery_results_taskresult" violates foreign key constraint "users_pscmdqueueresu_task_result_id_01ba48ff_fk_django_ce" on table "users_pscmdqueueresult"\nDETAIL:  Key (id)=(538) is still referenced from table "users_pscmdqueueresult".\n\n\nThe above exception was the direct cause of the following exception:\n\nTraceback (most recent call last):\n  File "/home/reg_user/.local/lib/python3.11/site-packages/celery/app/trace.py", line 451, in trace_task\n    R = retval = fun(*args, **kwargs)\n                 ^^^^^^^^^^^^^^^^^^^^\n  File "/home/reg_user/.local/lib/python3.11/site-packages/celery/app/trace.py", line 734, in __protected_call__\n    return self.run(*args, **kwargs)\n           ^^^^^^^^^^^^^^^^^^^^^^^^^\n  File "/home/reg_user/.local/lib/python3.11/site-packages/celery/app/builtins.py", line 22, in backend_cleanup\n    app.backend.cleanup()\n  File "/home/reg_user/.local/lib/python3.11/site-packages/django_celery_results/backends/database.py", line 182, in cleanup\n    self.TaskModel._default_manager.delete_expired(self.expires)\n  File "/home/reg_user/.local/lib/python3.11/site-packages/django_celery_results/managers.py", line 90, in delete_expired\n    with transaction.atomic(using=self.db):\n  File "/home/reg_user/.local/lib/python3.11/site-packages/django/db/transaction.py", line 262, in __exit__\n    connection.commit()\n  File "/home/reg_user/.local/lib/python3.11/site-packages/django/utils/asyncio.py", line 26, in inner\n    return func(*args, **kwargs)\n           ^^^^^^^^^^^^^^^^^^^^^\n  File "/home/reg_user/.local/lib/python3.11/site-packages/django/db/backends/base/base.py", line 330, in commit\n    self._commit()\n  File "/home/reg_user/.local/lib/python3.11/site-packages/django/db/backends/base/base.py", line 305, in _commit\n    with self.wrap_database_errors:\n  File "/home/reg_user/.local/lib/python3.11/site-packages/django/db/utils.py", line 91, in __exit__\n    raise dj_exc_value.with_traceback(traceback) from exc_value\n  File "/home/reg_user/.local/lib/python3.11/site-packages/django/db/backends/base/base.py", line 306, in _commit\n    return self.connection.commit()\n           ^^^^^^^^^^^^^^^^^^^^^^^^\ndjango.db.utils.IntegrityError: update or delete on table "django_celery_results_taskresult" violates foreign key constraint "users_pscmdqueueresu_task_result_id_01ba48ff_fk_django_ce" on table "users_pscmdqueueresult"\nDETAIL:  Key (id)=(538) is still referenced from table "users_pscmdqueueresult".\n\n	{"children": []}	"()"	"{}"	celery.backend_cleanup	default@%bea43276f0aa	2023-02-03 09:09:57.32037-05	celery.backend_cleanup
654	730625e7-9e58-49a2-924d-06d7e1435f98	SUCCESS	application/json	utf-8	null	2023-02-03 09:09:57.322985-05	\N	{"children": []}	"()"	"{}"	purge_ps_cmd_que_rslts	default@%bea43276f0aa	2023-02-03 09:09:57.322976-05	purge_ps_cmd_que_rslts
655	1c314c18-f111-4973-aab4-284ac9b080df	SUCCESS	application/json	utf-8	true	2023-02-03 09:10:05.006193-05	\N	{"children": []}	"()"	"{}"	hourly_processing	default@%bea43276f0aa	2023-02-03 09:10:05.006184-05	hourly processing
656	64b68037-4190-450f-8d49-b30d235a7adb	SUCCESS	application/json	utf-8	true	2023-02-03 09:15:00.034265-05	\N	{"children": []}	"()"	"{}"	flush_expired_refresh_tokens	default@%bea43276f0aa	2023-02-03 09:15:00.034254-05	flush expired refresh tokens
657	d8c11809-2b13-42d1-b7df-a1cd79eff622	SUCCESS	application/json	utf-8	true	2023-02-03 11:30:49.52895-05	\N	{"children": []}	"()"	"{}"	flush_expired_refresh_tokens	default@%5a96d5cfce8c	2023-02-03 11:30:49.528915-05	flush expired refresh tokens
658	d10373e4-fccd-47f8-b09b-99efdaf15e02	SUCCESS	application/json	utf-8	true	2023-02-03 11:30:56.911582-05	\N	{"children": []}	"()"	"{}"	hourly_processing	default@%5a96d5cfce8c	2023-02-03 11:30:56.911574-05	hourly processing
659	ecf4b06f-87f6-48dc-9d8b-887d29fae725	SUCCESS	application/json	utf-8	true	2023-02-03 11:31:59.48185-05	\N	{"children": []}	"()"	"{}"	flush_expired_refresh_tokens	default@%a203e0ad864d	2023-02-03 11:31:59.481801-05	flush expired refresh tokens
660	a9b2b660-92d8-497a-af6f-d3e610fba042	SUCCESS	application/json	utf-8	true	2023-02-03 13:16:47.801983-05	\N	{"children": []}	"()"	"{}"	flush_expired_refresh_tokens	default@%47f702002788	2023-02-03 13:16:47.801955-05	flush expired refresh tokens
661	ff66a068-d7f7-48c4-a0bd-a3ed5d779bbd	SUCCESS	application/json	utf-8	true	2023-02-03 13:16:49.687119-05	\N	{"children": []}	"()"	"{}"	hourly_processing	default@%47f702002788	2023-02-03 13:16:49.687112-05	hourly processing
662	68bd3669-7c35-4492-ac39-d3a14396203e	SUCCESS	application/json	utf-8	true	2023-02-03 13:30:02.690329-05	\N	{"children": []}	"()"	"{}"	hourly_processing	default@%47f702002788	2023-02-03 13:30:02.690316-05	hourly processing
663	1fbd97a0-f9ab-40ba-ae0d-fb6684e6f76e	SUCCESS	application/json	utf-8	true	2023-02-03 14:19:58.090494-05	\N	{"children": []}	"()"	"{}"	flush_expired_refresh_tokens	default@%373dd11d2ea1	2023-02-03 14:19:58.090453-05	flush expired refresh tokens
664	e8c20ca3-a884-4827-8be3-28061c87be1d	SUCCESS	application/json	utf-8	true	2023-02-03 14:30:01.801374-05	\N	{"children": []}	"()"	"{}"	hourly_processing	default@%c1f7e0c908e3	2023-02-03 14:30:01.801368-05	hourly processing
665	2e04146a-2a05-4885-a017-ebad75b38303	SUCCESS	application/json	utf-8	true	2023-02-03 15:46:36.078832-05	\N	{"children": []}	"()"	"{}"	flush_expired_refresh_tokens	default@%25d32842baa2	2023-02-03 15:46:36.07879-05	flush expired refresh tokens
666	c55204a0-93a5-4136-8ac8-60a539c01d74	SUCCESS	application/json	utf-8	true	2023-02-03 15:46:38.548765-05	\N	{"children": []}	"()"	"{}"	hourly_processing	default@%25d32842baa2	2023-02-03 15:46:38.548757-05	hourly processing
\.


--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.django_migrations (id, app, name, applied) FROM stdin;
1	django_celery_results	0001_initial	2023-01-06 07:40:06.076221-05
2	django_celery_results	0002_add_task_name_args_kwargs	2023-01-06 07:40:06.078841-05
3	django_celery_results	0003_auto_20181106_1101	2023-01-06 07:40:06.080041-05
4	django_celery_results	0004_auto_20190516_0412	2023-01-06 07:40:06.089325-05
5	django_celery_results	0005_taskresult_worker	2023-01-06 07:40:06.092319-05
6	django_celery_results	0006_taskresult_date_created	2023-01-06 07:40:06.095943-05
7	django_celery_results	0007_remove_taskresult_hidden	2023-01-06 07:40:06.097201-05
8	django_celery_results	0008_chordcounter	2023-01-06 07:40:06.102827-05
9	django_celery_results	0009_groupresult	2023-01-06 07:40:06.128178-05
10	django_celery_results	0010_remove_duplicate_indices	2023-01-06 07:40:06.130235-05
11	django_celery_results	0011_taskresult_periodic_task_name	2023-01-06 07:40:06.131638-05
12	contenttypes	0001_initial	2023-01-06 07:40:06.135361-05
13	contenttypes	0002_remove_content_type_name	2023-01-06 07:40:06.138168-05
14	auth	0001_initial	2023-01-06 07:40:06.15133-05
15	auth	0002_alter_permission_name_max_length	2023-01-06 07:40:06.153153-05
16	auth	0003_alter_user_email_max_length	2023-01-06 07:40:06.155139-05
17	auth	0004_alter_user_username_opts	2023-01-06 07:40:06.157112-05
18	auth	0005_alter_user_last_login_null	2023-01-06 07:40:06.158967-05
19	auth	0006_require_contenttypes_0002	2023-01-06 07:40:06.159664-05
20	auth	0007_alter_validators_add_error_messages	2023-01-06 07:40:06.161506-05
21	auth	0008_alter_user_username_max_length	2023-01-06 07:40:06.163405-05
22	auth	0009_alter_user_last_name_max_length	2023-01-06 07:40:06.165238-05
23	auth	0010_alter_group_name_max_length	2023-01-06 07:40:06.167435-05
24	auth	0011_update_proxy_permissions	2023-01-06 07:40:06.170705-05
25	auth	0012_alter_user_first_name_max_length	2023-01-06 07:40:06.172545-05
26	users	0001_initial	2023-01-06 07:40:06.231105-05
27	admin	0001_initial	2023-01-06 07:40:06.240509-05
28	admin	0002_logentry_remove_auto_add	2023-01-06 07:40:06.24437-05
29	admin	0003_logentry_add_action_flag_choices	2023-01-06 07:40:06.247977-05
30	captcha	0001_initial	2023-01-06 07:40:06.252-05
31	captcha	0002_alter_captchastore_id	2023-01-06 07:40:06.254141-05
32	django_celery_beat	0001_initial	2023-01-06 07:40:06.266227-05
33	django_celery_beat	0002_auto_20161118_0346	2023-01-06 07:40:06.271165-05
34	django_celery_beat	0003_auto_20161209_0049	2023-01-06 07:40:06.27453-05
35	django_celery_beat	0004_auto_20170221_0000	2023-01-06 07:40:06.276157-05
36	django_celery_beat	0005_add_solarschedule_events_choices	2023-01-06 07:40:06.277817-05
37	django_celery_beat	0006_auto_20180322_0932	2023-01-06 07:40:06.286062-05
38	django_celery_beat	0007_auto_20180521_0826	2023-01-06 07:40:06.28997-05
39	django_celery_beat	0008_auto_20180914_1922	2023-01-06 07:40:06.296405-05
40	django_celery_beat	0006_auto_20180210_1226	2023-01-06 07:40:06.300237-05
41	django_celery_beat	0006_periodictask_priority	2023-01-06 07:40:06.303152-05
42	django_celery_beat	0009_periodictask_headers	2023-01-06 07:40:06.306063-05
43	django_celery_beat	0010_auto_20190429_0326	2023-01-06 07:40:06.366028-05
44	django_celery_beat	0011_auto_20190508_0153	2023-01-06 07:40:06.372699-05
45	django_celery_beat	0012_periodictask_expire_seconds	2023-01-06 07:40:06.375158-05
46	django_celery_beat	0013_auto_20200609_0727	2023-01-06 07:40:06.377299-05
47	django_celery_beat	0014_remove_clockedschedule_enabled	2023-01-06 07:40:06.379032-05
48	django_celery_beat	0015_edit_solarschedule_events_choices	2023-01-06 07:40:06.380797-05
49	django_celery_beat	0016_alter_crontabschedule_timezone	2023-01-06 07:40:06.382729-05
50	sessions	0001_initial	2023-01-06 07:40:06.387336-05
51	token_blacklist	0001_initial	2023-01-06 07:40:06.403825-05
52	token_blacklist	0002_outstandingtoken_jti_hex	2023-01-06 07:40:06.408091-05
53	token_blacklist	0003_auto_20171017_2007	2023-01-06 07:40:06.415286-05
54	token_blacklist	0004_auto_20171017_2013	2023-01-06 07:40:06.42129-05
55	token_blacklist	0005_remove_outstandingtoken_jti	2023-01-06 07:40:06.426308-05
56	token_blacklist	0006_auto_20171017_2113	2023-01-06 07:40:06.430771-05
57	token_blacklist	0007_auto_20171017_2214	2023-01-06 07:40:06.441661-05
58	token_blacklist	0008_migrate_to_bigautofield	2023-01-06 07:40:06.461543-05
59	token_blacklist	0010_fix_migrate_to_bigautofield	2023-01-06 07:40:06.469261-05
60	token_blacklist	0011_linearizes_history	2023-01-06 07:40:06.470109-05
61	token_blacklist	0012_alter_outstandingtoken_user	2023-01-06 07:40:06.475695-05
62	users	0002_auto_20221202_2142	2023-01-06 07:40:06.48486-05
63	users	0003_alter_orgaccount_cur_ddt_alter_orgaccount_max_ddt_and_more	2023-01-06 07:40:06.49668-05
64	users	0004_orgaccount_is_public	2023-01-06 07:40:06.502836-05
65	users	0005_orgaccount_pcqr_display_age_in_hours_and_more	2023-01-06 07:40:06.516289-05
66	account	0001_initial	2023-01-12 15:14:16.949107-05
67	account	0002_email_max_length	2023-01-12 15:14:16.958168-05
68	sites	0001_initial	2023-01-12 15:14:16.961892-05
69	sites	0002_alter_domain_unique	2023-01-12 15:14:16.966802-05
70	socialaccount	0001_initial	2023-01-12 15:14:17.012121-05
71	socialaccount	0002_token_max_lengths	2023-01-12 15:14:17.041212-05
72	socialaccount	0003_extra_data_default_dict	2023-01-12 15:14:17.050503-05
73	users	0006_remove_user_phone_number	2023-01-19 15:53:13.067461-05
74	users	0007_orgnumnode_show_expire_tm_and_more	2023-01-31 11:49:43.68084-05
75	users	0008_orgaccount_fytd_accrued_cost_and_more	2023-02-01 09:25:44.515415-05
\.


--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.django_session (session_key, session_data, expire_date) FROM stdin;
fpy6etufv3p4r8oau4cqxr6cmf1laatw	.eJwVirEKgDAMBf_lzYJbBzfB3UVcRCTEogVtiokgSP_dut0d90KFAx3ELHe0RY3Mo5leRP8YGtSokC5hr1rskC3EUpQllQ0F6bZ9SXTR-Q_IFUJwa-_OwXXtiDl_o-cggw:1pIrjh:-dzzX_bR4g8tJ4c3PA2HhO4glDZs7b-wg3jKrqKkgSU	2023-02-03 08:47:17.624218-05
vgp50pohs3fnooq9qdgrhf55vp5pt4iz	.eJxVj81OwzAQhN8lZ4j8szY2R-48g7XrXRO3KK7sVFBVvDuJ1EuvM9980tyndMExflrn1GXIls5ym94nqqGcwisIkwKImhwD5KjBY3YOGaI4Hcr0MiW8bku6Dump8r60zxlhPst6FHzC9avNua1brzQfyPxox_zZWL4_HuyTYMGx7OtgOdtijbdMbFUkIaBM6DKUN-VIaePJawrBGAgqRCXBgUONYpwu-pAOGaO2Ncnvpfb9pTYqeqX-_gEpE1Pf:1pICUo:B9oemsYh4SGgYboI2De2lJ1B1fUOpnT3DRwKgYYVsu0	2023-02-01 12:45:10.160246-05
8ryu3ii7tylplo0z7ee9l105cprm4et3	.eJxVjDsOwjAQBe_iGlk2Wf8o6XMGa71e4wBypDipEHeHSCmgfTPzXiLitta4dV7ilMVFaHH63RLSg9sO8h3bbZY0t3WZktwVedAuxznz83q4fwcVe_3W3oC1Kp2BkwnZIg4IrJGKVlZ5CAwE4AxqBy4UznkgHQAgEJLXxYr3B9UiN6g:1pIDJm:QeD8RCFECl7h-Ml-RkqoxB8huRk1ozvPOPf2dl--cyo	2023-02-01 13:37:50.652894-05
0up7fnbe9olbonsrud8y9qlce7it7teh	.eJxVjMsOwiAQRf-FtSE8K-3Svd9AZmBqUQMNtInG-O_apAvd3nPueTEP6zL5tVH1KbKBaXb43RDCjfIG4hXypfBQ8lIT8k3hO238XCLdT7v7F5igTd-30zHoUatOR4xa9EhoMCDYYMajsCik6rCT6JxSxgnXC3LWWJBAyspRbtFGraWSPT3mVJ9sEO8PjWw-xw:1pO0cH:op83ZDryflsPhw_bPfSnDGdU0bPezJlRXeRcP7c3l-U	2023-02-17 13:16:53.697717-05
8nq67cml4cc4tq45wdo4swpdwgjmnvpe	.eJxVjMsOwiAQRf-FtSE8K-3Svd9AZmBqUQMNtInG-O_apAvd3nPueTEP6zL5tVH1KbKBaXb43RDCjfIG4hXypfBQ8lIT8k3hO238XCLdT7v7F5igTd-30zHoUatOR4xa9EhoMCDYYMajsCik6rCT6JxSxgnXC3LWWJBAyspRbtFGraWSPT3mVJ9sEO8PjWw-xw:1pO2xF:XDRnNzpFTODdb1c8MMc1ha02Yu91D9SDrqtjdFgxoZc	2023-02-17 15:46:41.123735-05
\.


--
-- Data for Name: django_site; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.django_site (id, domain, name) FROM stdin;
2	http://127.0.0.1:8080	http://127.0.0.1:8080
\.


--
-- Data for Name: my_cache_table; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.my_cache_table (cache_key, value, expires) FROM stdin;
:1:allauth:rl:manage_email:user:3	gAWVDQAAAAAAAABdlEdB2PIEBKKZ1GEu	2023-01-18 10:29:18-05
:1:allauth:rl:confirm_email:c5cd3a140ae7fe6a36d20ccc954279fd445cc56b96577842e4a25fc3650d239e	gAWVDQAAAAAAAABdlEdB2PIEBKMBvmEu	2023-01-18 10:31:18-05
:1:allauth:rl:change_password:user:3	gAWVDQAAAAAAAABdlEdB2PIHrFRNa2Eu	2023-01-18 11:31:41-05
:1:allauth:rl:reset_password:user:3	gAWVDQAAAAAAAABdlEdB2PIJyQhQlmEu	2023-01-18 12:07:44-05
:1:allauth:rl:reset_password_email:c5cd3a140ae7fe6a36d20ccc954279fd445cc56b96577842e4a25fc3650d239e	gAWVDQAAAAAAAABdlEdB2PIJyQlEyGEu	2023-01-18 12:07:44-05
:1:allauth:rl:reset_password_from_key:ip:192.168.48.1	gAWVFwAAAAAAAABdlChHQdjyCrhYr0ZHQdjyCrQRcdplLg==	2023-01-18 12:23:41-05
:1:allauth:rl:login_failed:79245e0d8f777b36c4f7bd8673a73b7269fc3a4e74e06fde587b33c29252c690	gAWVDQAAAAAAAABdlEdB2PJog+1mm2Eu	2023-01-19 15:08:27-05
\.


--
-- Data for Name: socialaccount_socialaccount; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.socialaccount_socialaccount (id, provider, uid, last_login, date_joined, extra_data, user_id) FROM stdin;
3	github	14032362	2023-01-20 08:47:05.569345-05	2023-01-18 12:45:10.154346-05	{"login": "cugarteblair", "id": 14032362, "node_id": "MDQ6VXNlcjE0MDMyMzYy", "avatar_url": "https://avatars.githubusercontent.com/u/14032362?v=4", "gravatar_id": "", "url": "https://api.github.com/users/cugarteblair", "html_url": "https://github.com/cugarteblair", "followers_url": "https://api.github.com/users/cugarteblair/followers", "following_url": "https://api.github.com/users/cugarteblair/following{/other_user}", "gists_url": "https://api.github.com/users/cugarteblair/gists{/gist_id}", "starred_url": "https://api.github.com/users/cugarteblair/starred{/owner}{/repo}", "subscriptions_url": "https://api.github.com/users/cugarteblair/subscriptions", "organizations_url": "https://api.github.com/users/cugarteblair/orgs", "repos_url": "https://api.github.com/users/cugarteblair/repos", "events_url": "https://api.github.com/users/cugarteblair/events{/privacy}", "received_events_url": "https://api.github.com/users/cugarteblair/received_events", "type": "User", "site_admin": false, "name": "Carlos E. Ugarte", "company": null, "blog": "", "location": "Bethesda, MD", "email": "cugarteblair@gmail.com", "hireable": null, "bio": "Seasoned Software Engineer", "twitter_username": null, "public_repos": 0, "public_gists": 0, "followers": 4, "following": 1, "created_at": "2015-08-29T17:35:38Z", "updated_at": "2023-01-19T18:53:46Z"}	3
\.


--
-- Data for Name: socialaccount_socialapp; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.socialaccount_socialapp (id, provider, name, client_id, secret, key) FROM stdin;
1	github	oath-github-prov-sys	209c9d050e7fc04d716d	e0c28ddf8f0118526b912b6c8c266c7ce7c4c476	
2	google	google-oauth	201018676779-hqssnc0c7lp6fd318frak1m03nqv0hjb.apps.googleusercontent.com	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	
\.


--
-- Data for Name: socialaccount_socialapp_sites; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.socialaccount_socialapp_sites (id, socialapp_id, site_id) FROM stdin;
2	1	2
3	2	2
\.


--
-- Data for Name: socialaccount_socialtoken; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.socialaccount_socialtoken (id, token, token_secret, expires_at, account_id, app_id) FROM stdin;
\.


--
-- Data for Name: token_blacklist_outstandingtoken; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.token_blacklist_outstandingtoken (id, token, created_at, expires_at, user_id, jti) FROM stdin;
\.


--
-- Data for Name: token_blacklist_blacklistedtoken; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.token_blacklist_blacklistedtoken (id, blacklisted_at, token_id) FROM stdin;
\.


--
-- Data for Name: users_orgaccount; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.users_orgaccount (id, name, point_of_contact_name, email, max_allowance, monthly_allowance, balance, creation_date, modified_date, node_mgr_fixed_cost, node_fixed_cost, desired_num_nodes, cur_nodes, min_node_cap, max_node_cap, max_hrly, cur_hrly, min_hrly, min_ddt, cur_ddt, max_ddt, most_recent_charge_time, most_recent_credit_time, most_recent_recon_time, fc_min_hourly, fc_min_daily, fc_min_monthly, fc_cur_hourly, fc_cur_daily, fc_cur_monthly, fc_max_hourly, fc_max_daily, fc_max_monthly, version, mfa_code, admin_max_node_cap, tokens, tokens_time, time_to_live_in_mins, expire_time, allow_deploy_by_token, destroy_when_no_nodes, owner_id, is_public, pcqr_display_age_in_hours, pcqr_retention_age_in_days, fytd_accrued_cost) FROM stdin;
b5edeee0-8425-446c-a73f-47e5a20ef3ce	unit-test-org	support team	sps.sliderule@gmail.com	2000.00	20.00	1028.21	2023-01-06 08:22:01.94411-05	2023-02-03 15:46:38.536785-05	0.153	0.226	0	0	0	10	2.4130000000000003	0.0001	0.0001	3196-01-26 11:46:37.88594-05	3196-01-26 11:46:37.88598-05	2023-02-21 09:53:23.687932-05	2023-02-01 19:00:00-05	2023-01-31 19:00:00-05	2023-02-03 11:30:53.479479-05	"{\\"tm\\": [\\"2023-02-03T16:30\\", \\"2023-02-03T17:30\\", \\"2023-02-03T18:30\\", \\"2023-02-03T19:30\\", \\"2023-02-03T20:30\\", \\"2023-02-03T21:30\\", \\"2023-02-03T22:30\\", \\"2023-02-03T23:30\\", \\"2023-02-04T00:30\\", \\"2023-02-04T01:30\\", \\"2023-02-04T02:30\\", \\"2023-02-04T03:30\\", \\"2023-02-04T04:30\\", \\"2023-02-04T05:30\\", \\"2023-02-04T06:30\\", \\"2023-02-04T07:30\\", \\"2023-02-04T08:30\\", \\"2023-02-04T09:30\\", \\"2023-02-04T10:30\\", \\"2023-02-04T11:30\\", \\"2023-02-04T12:30\\", \\"2023-02-04T13:30\\", \\"2023-02-04T14:30\\", \\"2023-02-04T15:30\\", \\"2023-02-04T16:30\\", \\"2023-02-04T17:30\\", \\"2023-02-04T18:30\\", \\"2023-02-04T19:30\\", \\"2023-02-04T20:30\\", \\"2023-02-04T21:30\\", \\"2023-02-04T22:30\\", \\"2023-02-04T23:30\\", \\"2023-02-05T00:30\\", \\"2023-02-05T01:30\\", \\"2023-02-05T02:30\\", \\"2023-02-05T03:30\\", \\"2023-02-05T04:30\\", \\"2023-02-05T05:30\\", \\"2023-02-05T06:30\\", \\"2023-02-05T07:30\\", \\"2023-02-05T08:30\\", \\"2023-02-05T09:30\\", \\"2023-02-05T10:30\\", \\"2023-02-05T11:30\\", \\"2023-02-05T12:30\\", \\"2023-02-05T13:30\\", \\"2023-02-05T14:30\\", \\"2023-02-05T15:30\\", \\"2023-02-05T16:30\\", \\"2023-02-05T17:30\\", \\"2023-02-05T18:30\\", \\"2023-02-05T19:30\\", \\"2023-02-05T20:30\\", \\"2023-02-05T21:30\\", \\"2023-02-05T22:30\\", \\"2023-02-05T23:30\\", \\"2023-02-06T00:30\\", \\"2023-02-06T01:30\\", \\"2023-02-06T02:30\\", \\"2023-02-06T03:30\\", \\"2023-02-06T04:30\\", \\"2023-02-06T05:30\\", \\"2023-02-06T06:30\\", \\"2023-02-06T07:30\\", \\"2023-02-06T08:30\\", \\"2023-02-06T09:30\\", \\"2023-02-06T10:30\\", \\"2023-02-06T11:30\\", \\"2023-02-06T12:30\\", \\"2023-02-06T13:30\\", \\"2023-02-06T14:30\\", \\"2023-02-06T15:30\\", \\"2023-02-06T16:30\\", \\"2023-02-06T17:30\\", \\"2023-02-06T18:30\\", \\"2023-02-06T19:30\\", \\"2023-02-06T20:30\\", \\"2023-02-06T21:30\\", \\"2023-02-06T22:30\\", \\"2023-02-06T23:30\\", \\"2023-02-07T00:30\\", \\"2023-02-07T01:30\\", \\"2023-02-07T02:30\\", \\"2023-02-07T03:30\\", \\"2023-02-07T04:30\\", \\"2023-02-07T05:30\\", \\"2023-02-07T06:30\\", \\"2023-02-07T07:30\\", \\"2023-02-07T08:30\\", \\"2023-02-07T09:30\\", \\"2023-02-07T10:30\\", \\"2023-02-07T11:30\\", \\"2023-02-07T12:30\\", \\"2023-02-07T13:30\\", \\"2023-02-07T14:30\\", \\"2023-02-07T15:30\\", \\"2023-02-07T16:30\\", \\"2023-02-07T17:30\\", \\"2023-02-07T18:30\\", \\"2023-02-07T19:30\\", \\"2023-02-07T20:30\\", \\"2023-02-07T21:30\\", \\"2023-02-07T22:30\\", \\"2023-02-07T23:30\\", \\"2023-02-08T00:30\\", \\"2023-02-08T01:30\\", \\"2023-02-08T02:30\\", \\"2023-02-08T03:30\\", \\"2023-02-08T04:30\\", \\"2023-02-08T05:30\\", \\"2023-02-08T06:30\\", \\"2023-02-08T07:30\\", \\"2023-02-08T08:30\\", \\"2023-02-08T09:30\\", \\"2023-02-08T10:30\\", \\"2023-02-08T11:30\\", \\"2023-02-08T12:30\\", \\"2023-02-08T13:30\\", \\"2023-02-08T14:30\\", \\"2023-02-08T15:30\\", \\"2023-02-08T16:30\\", \\"2023-02-08T17:30\\", \\"2023-02-08T18:30\\", \\"2023-02-08T19:30\\", \\"2023-02-08T20:30\\", \\"2023-02-08T21:30\\", \\"2023-02-08T22:30\\", \\"2023-02-08T23:30\\", \\"2023-02-09T00:30\\", \\"2023-02-09T01:30\\", \\"2023-02-09T02:30\\", \\"2023-02-09T03:30\\", \\"2023-02-09T04:30\\", \\"2023-02-09T05:30\\", \\"2023-02-09T06:30\\", \\"2023-02-09T07:30\\", \\"2023-02-09T08:30\\", \\"2023-02-09T09:30\\", \\"2023-02-09T10:30\\", \\"2023-02-09T11:30\\", \\"2023-02-09T12:30\\", \\"2023-02-09T13:30\\", \\"2023-02-09T14:30\\", \\"2023-02-09T15:30\\", \\"2023-02-09T16:30\\", \\"2023-02-09T17:30\\", \\"2023-02-09T18:30\\", \\"2023-02-09T19:30\\", \\"2023-02-09T20:30\\", \\"2023-02-09T21:30\\", \\"2023-02-09T22:30\\", \\"2023-02-09T23:30\\", \\"2023-02-10T00:30\\", \\"2023-02-10T01:30\\", \\"2023-02-10T02:30\\", \\"2023-02-10T03:30\\", \\"2023-02-10T04:30\\", \\"2023-02-10T05:30\\", \\"2023-02-10T06:30\\", \\"2023-02-10T07:30\\", \\"2023-02-10T08:30\\", \\"2023-02-10T09:30\\", \\"2023-02-10T10:30\\", \\"2023-02-10T11:30\\", \\"2023-02-10T12:30\\", \\"2023-02-10T13:30\\", \\"2023-02-10T14:30\\", \\"2023-02-10T15:30\\", \\"2023-02-10T16:30\\", \\"2023-02-10T17:30\\", \\"2023-02-10T18:30\\", \\"2023-02-10T19:30\\", \\"2023-02-10T20:30\\", \\"2023-02-10T21:30\\", \\"2023-02-10T22:30\\", \\"2023-02-10T23:30\\", \\"2023-02-11T00:30\\", \\"2023-02-11T01:30\\", \\"2023-02-11T02:30\\", \\"2023-02-11T03:30\\", \\"2023-02-11T04:30\\", \\"2023-02-11T05:30\\", \\"2023-02-11T06:30\\", \\"2023-02-11T07:30\\", \\"2023-02-11T08:30\\", \\"2023-02-11T09:30\\", \\"2023-02-11T10:30\\", \\"2023-02-11T11:30\\", \\"2023-02-11T12:30\\", \\"2023-02-11T13:30\\", \\"2023-02-11T14:30\\", \\"2023-02-11T15:30\\", \\"2023-02-11T16:30\\", \\"2023-02-11T17:30\\", \\"2023-02-11T18:30\\", \\"2023-02-11T19:30\\", \\"2023-02-11T20:30\\", \\"2023-02-11T21:30\\", \\"2023-02-11T22:30\\", \\"2023-02-11T23:30\\", \\"2023-02-12T00:30\\", \\"2023-02-12T01:30\\", \\"2023-02-12T02:30\\", \\"2023-02-12T03:30\\", \\"2023-02-12T04:30\\", \\"2023-02-12T05:30\\", \\"2023-02-12T06:30\\", \\"2023-02-12T07:30\\", \\"2023-02-12T08:30\\", \\"2023-02-12T09:30\\", \\"2023-02-12T10:30\\", \\"2023-02-12T11:30\\", \\"2023-02-12T12:30\\", \\"2023-02-12T13:30\\", \\"2023-02-12T14:30\\", \\"2023-02-12T15:30\\", \\"2023-02-12T16:30\\", \\"2023-02-12T17:30\\", \\"2023-02-12T18:30\\", \\"2023-02-12T19:30\\", \\"2023-02-12T20:30\\", \\"2023-02-12T21:30\\", \\"2023-02-12T22:30\\", \\"2023-02-12T23:30\\", \\"2023-02-13T00:30\\", \\"2023-02-13T01:30\\", \\"2023-02-13T02:30\\", \\"2023-02-13T03:30\\", \\"2023-02-13T04:30\\", \\"2023-02-13T05:30\\", \\"2023-02-13T06:30\\", \\"2023-02-13T07:30\\", \\"2023-02-13T08:30\\", \\"2023-02-13T09:30\\", \\"2023-02-13T10:30\\", \\"2023-02-13T11:30\\", \\"2023-02-13T12:30\\", \\"2023-02-13T13:30\\", \\"2023-02-13T14:30\\", \\"2023-02-13T15:30\\", \\"2023-02-13T16:30\\", \\"2023-02-13T17:30\\", \\"2023-02-13T18:30\\", \\"2023-02-13T19:30\\", \\"2023-02-13T20:30\\", \\"2023-02-13T21:30\\", \\"2023-02-13T22:30\\", \\"2023-02-13T23:30\\", \\"2023-02-14T00:30\\", \\"2023-02-14T01:30\\", \\"2023-02-14T02:30\\", \\"2023-02-14T03:30\\", \\"2023-02-14T04:30\\", \\"2023-02-14T05:30\\", \\"2023-02-14T06:30\\", \\"2023-02-14T07:30\\", \\"2023-02-14T08:30\\", \\"2023-02-14T09:30\\", \\"2023-02-14T10:30\\", \\"2023-02-14T11:30\\", \\"2023-02-14T12:30\\", \\"2023-02-14T13:30\\", \\"2023-02-14T14:30\\", \\"2023-02-14T15:30\\", \\"2023-02-14T16:30\\", \\"2023-02-14T17:30\\", \\"2023-02-14T18:30\\", \\"2023-02-14T19:30\\", \\"2023-02-14T20:30\\", \\"2023-02-14T21:30\\", \\"2023-02-14T22:30\\", \\"2023-02-14T23:30\\", \\"2023-02-15T00:30\\", \\"2023-02-15T01:30\\", \\"2023-02-15T02:30\\", \\"2023-02-15T03:30\\", \\"2023-02-15T04:30\\", \\"2023-02-15T05:30\\", \\"2023-02-15T06:30\\", \\"2023-02-15T07:30\\", \\"2023-02-15T08:30\\", \\"2023-02-15T09:30\\", \\"2023-02-15T10:30\\", \\"2023-02-15T11:30\\", \\"2023-02-15T12:30\\", \\"2023-02-15T13:30\\", \\"2023-02-15T14:30\\", \\"2023-02-15T15:30\\", \\"2023-02-15T16:30\\", \\"2023-02-15T17:30\\", \\"2023-02-15T18:30\\", \\"2023-02-15T19:30\\", \\"2023-02-15T20:30\\", \\"2023-02-15T21:30\\", \\"2023-02-15T22:30\\", \\"2023-02-15T23:30\\", \\"2023-02-16T00:30\\", \\"2023-02-16T01:30\\", \\"2023-02-16T02:30\\", \\"2023-02-16T03:30\\", \\"2023-02-16T04:30\\", \\"2023-02-16T05:30\\", \\"2023-02-16T06:30\\", \\"2023-02-16T07:30\\", \\"2023-02-16T08:30\\", \\"2023-02-16T09:30\\", \\"2023-02-16T10:30\\", \\"2023-02-16T11:30\\", \\"2023-02-16T12:30\\", \\"2023-02-16T13:30\\", \\"2023-02-16T14:30\\", \\"2023-02-16T15:30\\", \\"2023-02-16T16:30\\", \\"2023-02-16T17:30\\", \\"2023-02-16T18:30\\", \\"2023-02-16T19:30\\", \\"2023-02-16T20:30\\", \\"2023-02-16T21:30\\", \\"2023-02-16T22:30\\", \\"2023-02-16T23:30\\", \\"2023-02-17T00:30\\", \\"2023-02-17T01:30\\", \\"2023-02-17T02:30\\", \\"2023-02-17T03:30\\", \\"2023-02-17T04:30\\", \\"2023-02-17T05:30\\", \\"2023-02-17T06:30\\", \\"2023-02-17T07:30\\", \\"2023-02-17T08:30\\", \\"2023-02-17T09:30\\", \\"2023-02-17T10:30\\", \\"2023-02-17T11:30\\", \\"2023-02-17T12:30\\", \\"2023-02-17T13:30\\", \\"2023-02-17T14:30\\", \\"2023-02-17T15:30\\"], \\"bal\\": [1028.2099, 1028.2098, 1028.2097, 1028.2096000000001, 1028.2095000000002, 1028.2094000000002, 1028.2093000000002, 1028.2092000000002, 1028.2091000000003, 1028.2090000000003, 1028.2089000000003, 1028.2088000000003, 1028.2087000000004, 1028.2086000000004, 1028.2085000000004, 1028.2084000000004, 1028.2083000000005, 1028.2082000000005, 1028.2081000000005, 1028.2080000000005, 1028.2079000000006, 1028.2078000000006, 1028.2077000000006, 1028.2076000000006, 1028.2075000000007, 1028.2074000000007, 1028.2073000000007, 1028.2072000000007, 1028.2071000000008, 1028.2070000000008, 1028.2069000000008, 1028.2068000000008, 1028.2067000000009, 1028.206600000001, 1028.206500000001, 1028.206400000001, 1028.206300000001, 1028.206200000001, 1028.206100000001, 1028.206000000001, 1028.205900000001, 1028.205800000001, 1028.2057000000011, 1028.2056000000011, 1028.2055000000012, 1028.2054000000012, 1028.2053000000012, 1028.2052000000012, 1028.2051000000013, 1028.2050000000013, 1028.2049000000013, 1028.2048000000013, 1028.2047000000014, 1028.2046000000014, 1028.2045000000014, 1028.2044000000014, 1028.2043000000015, 1028.2042000000015, 1028.2041000000015, 1028.2040000000015, 1028.2039000000016, 1028.2038000000016, 1028.2037000000016, 1028.2036000000016, 1028.2035000000017, 1028.2034000000017, 1028.2033000000017, 1028.2032000000017, 1028.2031000000018, 1028.2030000000018, 1028.2029000000018, 1028.2028000000018, 1028.2027000000019, 1028.202600000002, 1028.202500000002, 1028.202400000002, 1028.202300000002, 1028.202200000002, 1028.202100000002, 1028.202000000002, 1028.201900000002, 1028.201800000002, 1028.2017000000021, 1028.2016000000021, 1028.2015000000022, 1028.2014000000022, 1028.2013000000022, 1028.2012000000022, 1028.2011000000023, 1028.2010000000023, 1028.2009000000023, 1028.2008000000023, 1028.2007000000024, 1028.2006000000024, 1028.2005000000024, 1028.2004000000024, 1028.2003000000025, 1028.2002000000025, 1028.2001000000025, 1028.2000000000025, 1028.1999000000026, 1028.1998000000026, 1028.1997000000026, 1028.1996000000026, 1028.1995000000027, 1028.1994000000027, 1028.1993000000027, 1028.1992000000027, 1028.1991000000028, 1028.1990000000028, 1028.1989000000028, 1028.1988000000028, 1028.1987000000029, 1028.198600000003, 1028.198500000003, 1028.198400000003, 1028.198300000003, 1028.198200000003, 1028.198100000003, 1028.198000000003, 1028.197900000003, 1028.197800000003, 1028.1977000000031, 1028.1976000000031, 1028.1975000000032, 1028.1974000000032, 1028.1973000000032, 1028.1972000000032, 1028.1971000000033, 1028.1970000000033, 1028.1969000000033, 1028.1968000000033, 1028.1967000000034, 1028.1966000000034, 1028.1965000000034, 1028.1964000000035, 1028.1963000000035, 1028.1962000000035, 1028.1961000000035, 1028.1960000000036, 1028.1959000000036, 1028.1958000000036, 1028.1957000000036, 1028.1956000000037, 1028.1955000000037, 1028.1954000000037, 1028.1953000000037, 1028.1952000000038, 1028.1951000000038, 1028.1950000000038, 1028.1949000000038, 1028.1948000000039, 1028.1947000000039, 1028.194600000004, 1028.194500000004, 1028.194400000004, 1028.194300000004, 1028.194200000004, 1028.194100000004, 1028.194000000004, 1028.193900000004, 1028.193800000004, 1028.1937000000041, 1028.1936000000042, 1028.1935000000042, 1028.1934000000042, 1028.1933000000042, 1028.1932000000043, 1028.1931000000043, 1028.1930000000043, 1028.1929000000043, 1028.1928000000044, 1028.1927000000044, 1028.1926000000044, 1028.1925000000044, 1028.1924000000045, 1028.1923000000045, 1028.1922000000045, 1028.1921000000045, 1028.1920000000046, 1028.1919000000046, 1028.1918000000046, 1028.1917000000046, 1028.1916000000047, 1028.1915000000047, 1028.1914000000047, 1028.1913000000047, 1028.1912000000048, 1028.1911000000048, 1028.1910000000048, 1028.1909000000048, 1028.1908000000049, 1028.1907000000049, 1028.190600000005, 1028.190500000005, 1028.190400000005, 1028.190300000005, 1028.190200000005, 1028.190100000005, 1028.190000000005, 1028.189900000005, 1028.189800000005, 1028.1897000000051, 1028.1896000000052, 1028.1895000000052, 1028.1894000000052, 1028.1893000000052, 1028.1892000000053, 1028.1891000000053, 1028.1890000000053, 1028.1889000000053, 1028.1888000000054, 1028.1887000000054, 1028.1886000000054, 1028.1885000000054, 1028.1884000000055, 1028.1883000000055, 1028.1882000000055, 1028.1881000000055, 1028.1880000000056, 1028.1879000000056, 1028.1878000000056, 1028.1877000000056, 1028.1876000000057, 1028.1875000000057, 1028.1874000000057, 1028.1873000000057, 1028.1872000000058, 1028.1871000000058, 1028.1870000000058, 1028.1869000000058, 1028.1868000000059, 1028.1867000000059, 1028.186600000006, 1028.186500000006, 1028.186400000006, 1028.186300000006, 1028.186200000006, 1028.186100000006, 1028.186000000006, 1028.185900000006, 1028.185800000006, 1028.1857000000061, 1028.1856000000062, 1028.1855000000062, 1028.1854000000062, 1028.1853000000062, 1028.1852000000063, 1028.1851000000063, 1028.1850000000063, 1028.1849000000063, 1028.1848000000064, 1028.1847000000064, 1028.1846000000064, 1028.1845000000064, 1028.1844000000065, 1028.1843000000065, 1028.1842000000065, 1028.1841000000065, 1028.1840000000066, 1028.1839000000066, 1028.1838000000066, 1028.1837000000066, 1028.1836000000067, 1028.1835000000067, 1028.1834000000067, 1028.1833000000067, 1028.1832000000068, 1028.1831000000068, 1028.1830000000068, 1028.1829000000068, 1028.1828000000069, 1028.182700000007, 1028.182600000007, 1028.182500000007, 1028.182400000007, 1028.182300000007, 1028.182200000007, 1028.182100000007, 1028.182000000007, 1028.181900000007, 1028.1818000000071, 1028.1817000000071, 1028.1816000000072, 1028.1815000000072, 1028.1814000000072, 1028.1813000000072, 1028.1812000000073, 1028.1811000000073, 1028.1810000000073, 1028.1809000000073, 1028.1808000000074, 1028.1807000000074, 1028.1806000000074, 1028.1805000000074, 1028.1804000000075, 1028.1803000000075, 1028.1802000000075, 1028.1801000000075, 1028.1800000000076, 1028.1799000000076, 1028.1798000000076, 1028.1797000000076, 1028.1796000000077, 1028.1795000000077, 1028.1794000000077, 1028.1793000000077, 1028.1792000000078, 1028.1791000000078, 1028.1790000000078, 1028.1789000000078, 1028.1788000000079, 1028.178700000008, 1028.178600000008, 1028.178500000008, 1028.178400000008, 1028.178300000008, 1028.178200000008, 1028.178100000008, 1028.178000000008, 1028.177900000008, 1028.1778000000081, 1028.1777000000081, 1028.1776000000082, 1028.1775000000082, 1028.1774000000082, 1028.1773000000082, 1028.1772000000083, 1028.1771000000083, 1028.1770000000083, 1028.1769000000083, 1028.1768000000084, 1028.1767000000084, 1028.1766000000084, 1028.1765000000084, 1028.1764000000085]}"	"{\\"tm\\": [\\"2023-02-04\\", \\"2023-02-05\\", \\"2023-02-06\\", \\"2023-02-07\\", \\"2023-02-08\\", \\"2023-02-09\\", \\"2023-02-10\\", \\"2023-02-11\\", \\"2023-02-12\\", \\"2023-02-13\\", \\"2023-02-14\\", \\"2023-02-15\\", \\"2023-02-16\\", \\"2023-02-17\\", \\"2023-02-18\\", \\"2023-02-19\\", \\"2023-02-20\\", \\"2023-02-21\\", \\"2023-02-22\\", \\"2023-02-23\\", \\"2023-02-24\\", \\"2023-02-25\\", \\"2023-02-26\\", \\"2023-02-27\\", \\"2023-02-28\\", \\"2023-03-01\\", \\"2023-03-02\\", \\"2023-03-03\\", \\"2023-03-04\\", \\"2023-03-05\\", \\"2023-03-06\\"], \\"bal\\": [1028.2051999999999, 1028.2027999999998, 1028.2003999999997, 1028.1979999999996, 1028.1955999999996, 1028.1931999999995, 1028.1907999999994, 1028.1883999999993, 1028.1859999999992, 1028.1835999999992, 1028.181199999999, 1028.178799999999, 1028.176399999999, 1028.1739999999988, 1028.1715999999988, 1028.1691999999987, 1028.1667999999986, 1028.1643999999985, 1028.1619999999984, 1028.1595999999984, 1028.1571999999983, 1028.1547999999982, 1028.1523999999981, 1028.149999999998, 1028.147599999998, 1048.1451999999979, 1048.1427999999978, 1048.1403999999977, 1048.1379999999976, 1048.1355999999976, 1048.1331999999975]}"	"{\\"tm\\": [\\"2023-02\\", \\"2023-03\\", \\"2023-04\\", \\"2023-05\\", \\"2023-06\\", \\"2023-07\\", \\"2023-08\\", \\"2023-09\\", \\"2023-10\\", \\"2023-11\\", \\"2023-12\\", \\"2024-01\\", \\"2024-02\\"], \\"bal\\": [1028.147599999998, 1048.073199999998, 1068.001199999998, 1087.9267999999981, 1107.8547999999982, 1127.7803999999983, 1147.7059999999983, 1167.6339999999984, 1187.5595999999985, 1207.4875999999986, 1227.4131999999986, 1247.3387999999986, 1267.2691999999986]}"	"{\\"tm\\": [\\"2023-02-03T16:30\\", \\"2023-02-03T17:30\\", \\"2023-02-03T18:30\\", \\"2023-02-03T19:30\\", \\"2023-02-03T20:30\\", \\"2023-02-03T21:30\\", \\"2023-02-03T22:30\\", \\"2023-02-03T23:30\\", \\"2023-02-04T00:30\\", \\"2023-02-04T01:30\\", \\"2023-02-04T02:30\\", \\"2023-02-04T03:30\\", \\"2023-02-04T04:30\\", \\"2023-02-04T05:30\\", \\"2023-02-04T06:30\\", \\"2023-02-04T07:30\\", \\"2023-02-04T08:30\\", \\"2023-02-04T09:30\\", \\"2023-02-04T10:30\\", \\"2023-02-04T11:30\\", \\"2023-02-04T12:30\\", \\"2023-02-04T13:30\\", \\"2023-02-04T14:30\\", \\"2023-02-04T15:30\\", \\"2023-02-04T16:30\\", \\"2023-02-04T17:30\\", \\"2023-02-04T18:30\\", \\"2023-02-04T19:30\\", \\"2023-02-04T20:30\\", \\"2023-02-04T21:30\\", \\"2023-02-04T22:30\\", \\"2023-02-04T23:30\\", \\"2023-02-05T00:30\\", \\"2023-02-05T01:30\\", \\"2023-02-05T02:30\\", \\"2023-02-05T03:30\\", \\"2023-02-05T04:30\\", \\"2023-02-05T05:30\\", \\"2023-02-05T06:30\\", \\"2023-02-05T07:30\\", \\"2023-02-05T08:30\\", \\"2023-02-05T09:30\\", \\"2023-02-05T10:30\\", \\"2023-02-05T11:30\\", \\"2023-02-05T12:30\\", \\"2023-02-05T13:30\\", \\"2023-02-05T14:30\\", \\"2023-02-05T15:30\\", \\"2023-02-05T16:30\\", \\"2023-02-05T17:30\\", \\"2023-02-05T18:30\\", \\"2023-02-05T19:30\\", \\"2023-02-05T20:30\\", \\"2023-02-05T21:30\\", \\"2023-02-05T22:30\\", \\"2023-02-05T23:30\\", \\"2023-02-06T00:30\\", \\"2023-02-06T01:30\\", \\"2023-02-06T02:30\\", \\"2023-02-06T03:30\\", \\"2023-02-06T04:30\\", \\"2023-02-06T05:30\\", \\"2023-02-06T06:30\\", \\"2023-02-06T07:30\\", \\"2023-02-06T08:30\\", \\"2023-02-06T09:30\\", \\"2023-02-06T10:30\\", \\"2023-02-06T11:30\\", \\"2023-02-06T12:30\\", \\"2023-02-06T13:30\\", \\"2023-02-06T14:30\\", \\"2023-02-06T15:30\\", \\"2023-02-06T16:30\\", \\"2023-02-06T17:30\\", \\"2023-02-06T18:30\\", \\"2023-02-06T19:30\\", \\"2023-02-06T20:30\\", \\"2023-02-06T21:30\\", \\"2023-02-06T22:30\\", \\"2023-02-06T23:30\\", \\"2023-02-07T00:30\\", \\"2023-02-07T01:30\\", \\"2023-02-07T02:30\\", \\"2023-02-07T03:30\\", \\"2023-02-07T04:30\\", \\"2023-02-07T05:30\\", \\"2023-02-07T06:30\\", \\"2023-02-07T07:30\\", \\"2023-02-07T08:30\\", \\"2023-02-07T09:30\\", \\"2023-02-07T10:30\\", \\"2023-02-07T11:30\\", \\"2023-02-07T12:30\\", \\"2023-02-07T13:30\\", \\"2023-02-07T14:30\\", \\"2023-02-07T15:30\\", \\"2023-02-07T16:30\\", \\"2023-02-07T17:30\\", \\"2023-02-07T18:30\\", \\"2023-02-07T19:30\\", \\"2023-02-07T20:30\\", \\"2023-02-07T21:30\\", \\"2023-02-07T22:30\\", \\"2023-02-07T23:30\\", \\"2023-02-08T00:30\\", \\"2023-02-08T01:30\\", \\"2023-02-08T02:30\\", \\"2023-02-08T03:30\\", \\"2023-02-08T04:30\\", \\"2023-02-08T05:30\\", \\"2023-02-08T06:30\\", \\"2023-02-08T07:30\\", \\"2023-02-08T08:30\\", \\"2023-02-08T09:30\\", \\"2023-02-08T10:30\\", \\"2023-02-08T11:30\\", \\"2023-02-08T12:30\\", \\"2023-02-08T13:30\\", \\"2023-02-08T14:30\\", \\"2023-02-08T15:30\\", \\"2023-02-08T16:30\\", \\"2023-02-08T17:30\\", \\"2023-02-08T18:30\\", \\"2023-02-08T19:30\\", \\"2023-02-08T20:30\\", \\"2023-02-08T21:30\\", \\"2023-02-08T22:30\\", \\"2023-02-08T23:30\\", \\"2023-02-09T00:30\\", \\"2023-02-09T01:30\\", \\"2023-02-09T02:30\\", \\"2023-02-09T03:30\\", \\"2023-02-09T04:30\\", \\"2023-02-09T05:30\\", \\"2023-02-09T06:30\\", \\"2023-02-09T07:30\\", \\"2023-02-09T08:30\\", \\"2023-02-09T09:30\\", \\"2023-02-09T10:30\\", \\"2023-02-09T11:30\\", \\"2023-02-09T12:30\\", \\"2023-02-09T13:30\\", \\"2023-02-09T14:30\\", \\"2023-02-09T15:30\\", \\"2023-02-09T16:30\\", \\"2023-02-09T17:30\\", \\"2023-02-09T18:30\\", \\"2023-02-09T19:30\\", \\"2023-02-09T20:30\\", \\"2023-02-09T21:30\\", \\"2023-02-09T22:30\\", \\"2023-02-09T23:30\\", \\"2023-02-10T00:30\\", \\"2023-02-10T01:30\\", \\"2023-02-10T02:30\\", \\"2023-02-10T03:30\\", \\"2023-02-10T04:30\\", \\"2023-02-10T05:30\\", \\"2023-02-10T06:30\\", \\"2023-02-10T07:30\\", \\"2023-02-10T08:30\\", \\"2023-02-10T09:30\\", \\"2023-02-10T10:30\\", \\"2023-02-10T11:30\\", \\"2023-02-10T12:30\\", \\"2023-02-10T13:30\\", \\"2023-02-10T14:30\\", \\"2023-02-10T15:30\\", \\"2023-02-10T16:30\\", \\"2023-02-10T17:30\\", \\"2023-02-10T18:30\\", \\"2023-02-10T19:30\\", \\"2023-02-10T20:30\\", \\"2023-02-10T21:30\\", \\"2023-02-10T22:30\\", \\"2023-02-10T23:30\\", \\"2023-02-11T00:30\\", \\"2023-02-11T01:30\\", \\"2023-02-11T02:30\\", \\"2023-02-11T03:30\\", \\"2023-02-11T04:30\\", \\"2023-02-11T05:30\\", \\"2023-02-11T06:30\\", \\"2023-02-11T07:30\\", \\"2023-02-11T08:30\\", \\"2023-02-11T09:30\\", \\"2023-02-11T10:30\\", \\"2023-02-11T11:30\\", \\"2023-02-11T12:30\\", \\"2023-02-11T13:30\\", \\"2023-02-11T14:30\\", \\"2023-02-11T15:30\\", \\"2023-02-11T16:30\\", \\"2023-02-11T17:30\\", \\"2023-02-11T18:30\\", \\"2023-02-11T19:30\\", \\"2023-02-11T20:30\\", \\"2023-02-11T21:30\\", \\"2023-02-11T22:30\\", \\"2023-02-11T23:30\\", \\"2023-02-12T00:30\\", \\"2023-02-12T01:30\\", \\"2023-02-12T02:30\\", \\"2023-02-12T03:30\\", \\"2023-02-12T04:30\\", \\"2023-02-12T05:30\\", \\"2023-02-12T06:30\\", \\"2023-02-12T07:30\\", \\"2023-02-12T08:30\\", \\"2023-02-12T09:30\\", \\"2023-02-12T10:30\\", \\"2023-02-12T11:30\\", \\"2023-02-12T12:30\\", \\"2023-02-12T13:30\\", \\"2023-02-12T14:30\\", \\"2023-02-12T15:30\\", \\"2023-02-12T16:30\\", \\"2023-02-12T17:30\\", \\"2023-02-12T18:30\\", \\"2023-02-12T19:30\\", \\"2023-02-12T20:30\\", \\"2023-02-12T21:30\\", \\"2023-02-12T22:30\\", \\"2023-02-12T23:30\\", \\"2023-02-13T00:30\\", \\"2023-02-13T01:30\\", \\"2023-02-13T02:30\\", \\"2023-02-13T03:30\\", \\"2023-02-13T04:30\\", \\"2023-02-13T05:30\\", \\"2023-02-13T06:30\\", \\"2023-02-13T07:30\\", \\"2023-02-13T08:30\\", \\"2023-02-13T09:30\\", \\"2023-02-13T10:30\\", \\"2023-02-13T11:30\\", \\"2023-02-13T12:30\\", \\"2023-02-13T13:30\\", \\"2023-02-13T14:30\\", \\"2023-02-13T15:30\\", \\"2023-02-13T16:30\\", \\"2023-02-13T17:30\\", \\"2023-02-13T18:30\\", \\"2023-02-13T19:30\\", \\"2023-02-13T20:30\\", \\"2023-02-13T21:30\\", \\"2023-02-13T22:30\\", \\"2023-02-13T23:30\\", \\"2023-02-14T00:30\\", \\"2023-02-14T01:30\\", \\"2023-02-14T02:30\\", \\"2023-02-14T03:30\\", \\"2023-02-14T04:30\\", \\"2023-02-14T05:30\\", \\"2023-02-14T06:30\\", \\"2023-02-14T07:30\\", \\"2023-02-14T08:30\\", \\"2023-02-14T09:30\\", \\"2023-02-14T10:30\\", \\"2023-02-14T11:30\\", \\"2023-02-14T12:30\\", \\"2023-02-14T13:30\\", \\"2023-02-14T14:30\\", \\"2023-02-14T15:30\\", \\"2023-02-14T16:30\\", \\"2023-02-14T17:30\\", \\"2023-02-14T18:30\\", \\"2023-02-14T19:30\\", \\"2023-02-14T20:30\\", \\"2023-02-14T21:30\\", \\"2023-02-14T22:30\\", \\"2023-02-14T23:30\\", \\"2023-02-15T00:30\\", \\"2023-02-15T01:30\\", \\"2023-02-15T02:30\\", \\"2023-02-15T03:30\\", \\"2023-02-15T04:30\\", \\"2023-02-15T05:30\\", \\"2023-02-15T06:30\\", \\"2023-02-15T07:30\\", \\"2023-02-15T08:30\\", \\"2023-02-15T09:30\\", \\"2023-02-15T10:30\\", \\"2023-02-15T11:30\\", \\"2023-02-15T12:30\\", \\"2023-02-15T13:30\\", \\"2023-02-15T14:30\\", \\"2023-02-15T15:30\\", \\"2023-02-15T16:30\\", \\"2023-02-15T17:30\\", \\"2023-02-15T18:30\\", \\"2023-02-15T19:30\\", \\"2023-02-15T20:30\\", \\"2023-02-15T21:30\\", \\"2023-02-15T22:30\\", \\"2023-02-15T23:30\\", \\"2023-02-16T00:30\\", \\"2023-02-16T01:30\\", \\"2023-02-16T02:30\\", \\"2023-02-16T03:30\\", \\"2023-02-16T04:30\\", \\"2023-02-16T05:30\\", \\"2023-02-16T06:30\\", \\"2023-02-16T07:30\\", \\"2023-02-16T08:30\\", \\"2023-02-16T09:30\\", \\"2023-02-16T10:30\\", \\"2023-02-16T11:30\\", \\"2023-02-16T12:30\\", \\"2023-02-16T13:30\\", \\"2023-02-16T14:30\\", \\"2023-02-16T15:30\\", \\"2023-02-16T16:30\\", \\"2023-02-16T17:30\\", \\"2023-02-16T18:30\\", \\"2023-02-16T19:30\\", \\"2023-02-16T20:30\\", \\"2023-02-16T21:30\\", \\"2023-02-16T22:30\\", \\"2023-02-16T23:30\\", \\"2023-02-17T00:30\\", \\"2023-02-17T01:30\\", \\"2023-02-17T02:30\\", \\"2023-02-17T03:30\\", \\"2023-02-17T04:30\\", \\"2023-02-17T05:30\\", \\"2023-02-17T06:30\\", \\"2023-02-17T07:30\\", \\"2023-02-17T08:30\\", \\"2023-02-17T09:30\\", \\"2023-02-17T10:30\\", \\"2023-02-17T11:30\\", \\"2023-02-17T12:30\\", \\"2023-02-17T13:30\\", \\"2023-02-17T14:30\\", \\"2023-02-17T15:30\\"], \\"bal\\": [1028.2099, 1028.2098, 1028.2097, 1028.2096000000001, 1028.2095000000002, 1028.2094000000002, 1028.2093000000002, 1028.2092000000002, 1028.2091000000003, 1028.2090000000003, 1028.2089000000003, 1028.2088000000003, 1028.2087000000004, 1028.2086000000004, 1028.2085000000004, 1028.2084000000004, 1028.2083000000005, 1028.2082000000005, 1028.2081000000005, 1028.2080000000005, 1028.2079000000006, 1028.2078000000006, 1028.2077000000006, 1028.2076000000006, 1028.2075000000007, 1028.2074000000007, 1028.2073000000007, 1028.2072000000007, 1028.2071000000008, 1028.2070000000008, 1028.2069000000008, 1028.2068000000008, 1028.2067000000009, 1028.206600000001, 1028.206500000001, 1028.206400000001, 1028.206300000001, 1028.206200000001, 1028.206100000001, 1028.206000000001, 1028.205900000001, 1028.205800000001, 1028.2057000000011, 1028.2056000000011, 1028.2055000000012, 1028.2054000000012, 1028.2053000000012, 1028.2052000000012, 1028.2051000000013, 1028.2050000000013, 1028.2049000000013, 1028.2048000000013, 1028.2047000000014, 1028.2046000000014, 1028.2045000000014, 1028.2044000000014, 1028.2043000000015, 1028.2042000000015, 1028.2041000000015, 1028.2040000000015, 1028.2039000000016, 1028.2038000000016, 1028.2037000000016, 1028.2036000000016, 1028.2035000000017, 1028.2034000000017, 1028.2033000000017, 1028.2032000000017, 1028.2031000000018, 1028.2030000000018, 1028.2029000000018, 1028.2028000000018, 1028.2027000000019, 1028.202600000002, 1028.202500000002, 1028.202400000002, 1028.202300000002, 1028.202200000002, 1028.202100000002, 1028.202000000002, 1028.201900000002, 1028.201800000002, 1028.2017000000021, 1028.2016000000021, 1028.2015000000022, 1028.2014000000022, 1028.2013000000022, 1028.2012000000022, 1028.2011000000023, 1028.2010000000023, 1028.2009000000023, 1028.2008000000023, 1028.2007000000024, 1028.2006000000024, 1028.2005000000024, 1028.2004000000024, 1028.2003000000025, 1028.2002000000025, 1028.2001000000025, 1028.2000000000025, 1028.1999000000026, 1028.1998000000026, 1028.1997000000026, 1028.1996000000026, 1028.1995000000027, 1028.1994000000027, 1028.1993000000027, 1028.1992000000027, 1028.1991000000028, 1028.1990000000028, 1028.1989000000028, 1028.1988000000028, 1028.1987000000029, 1028.198600000003, 1028.198500000003, 1028.198400000003, 1028.198300000003, 1028.198200000003, 1028.198100000003, 1028.198000000003, 1028.197900000003, 1028.197800000003, 1028.1977000000031, 1028.1976000000031, 1028.1975000000032, 1028.1974000000032, 1028.1973000000032, 1028.1972000000032, 1028.1971000000033, 1028.1970000000033, 1028.1969000000033, 1028.1968000000033, 1028.1967000000034, 1028.1966000000034, 1028.1965000000034, 1028.1964000000035, 1028.1963000000035, 1028.1962000000035, 1028.1961000000035, 1028.1960000000036, 1028.1959000000036, 1028.1958000000036, 1028.1957000000036, 1028.1956000000037, 1028.1955000000037, 1028.1954000000037, 1028.1953000000037, 1028.1952000000038, 1028.1951000000038, 1028.1950000000038, 1028.1949000000038, 1028.1948000000039, 1028.1947000000039, 1028.194600000004, 1028.194500000004, 1028.194400000004, 1028.194300000004, 1028.194200000004, 1028.194100000004, 1028.194000000004, 1028.193900000004, 1028.193800000004, 1028.1937000000041, 1028.1936000000042, 1028.1935000000042, 1028.1934000000042, 1028.1933000000042, 1028.1932000000043, 1028.1931000000043, 1028.1930000000043, 1028.1929000000043, 1028.1928000000044, 1028.1927000000044, 1028.1926000000044, 1028.1925000000044, 1028.1924000000045, 1028.1923000000045, 1028.1922000000045, 1028.1921000000045, 1028.1920000000046, 1028.1919000000046, 1028.1918000000046, 1028.1917000000046, 1028.1916000000047, 1028.1915000000047, 1028.1914000000047, 1028.1913000000047, 1028.1912000000048, 1028.1911000000048, 1028.1910000000048, 1028.1909000000048, 1028.1908000000049, 1028.1907000000049, 1028.190600000005, 1028.190500000005, 1028.190400000005, 1028.190300000005, 1028.190200000005, 1028.190100000005, 1028.190000000005, 1028.189900000005, 1028.189800000005, 1028.1897000000051, 1028.1896000000052, 1028.1895000000052, 1028.1894000000052, 1028.1893000000052, 1028.1892000000053, 1028.1891000000053, 1028.1890000000053, 1028.1889000000053, 1028.1888000000054, 1028.1887000000054, 1028.1886000000054, 1028.1885000000054, 1028.1884000000055, 1028.1883000000055, 1028.1882000000055, 1028.1881000000055, 1028.1880000000056, 1028.1879000000056, 1028.1878000000056, 1028.1877000000056, 1028.1876000000057, 1028.1875000000057, 1028.1874000000057, 1028.1873000000057, 1028.1872000000058, 1028.1871000000058, 1028.1870000000058, 1028.1869000000058, 1028.1868000000059, 1028.1867000000059, 1028.186600000006, 1028.186500000006, 1028.186400000006, 1028.186300000006, 1028.186200000006, 1028.186100000006, 1028.186000000006, 1028.185900000006, 1028.185800000006, 1028.1857000000061, 1028.1856000000062, 1028.1855000000062, 1028.1854000000062, 1028.1853000000062, 1028.1852000000063, 1028.1851000000063, 1028.1850000000063, 1028.1849000000063, 1028.1848000000064, 1028.1847000000064, 1028.1846000000064, 1028.1845000000064, 1028.1844000000065, 1028.1843000000065, 1028.1842000000065, 1028.1841000000065, 1028.1840000000066, 1028.1839000000066, 1028.1838000000066, 1028.1837000000066, 1028.1836000000067, 1028.1835000000067, 1028.1834000000067, 1028.1833000000067, 1028.1832000000068, 1028.1831000000068, 1028.1830000000068, 1028.1829000000068, 1028.1828000000069, 1028.182700000007, 1028.182600000007, 1028.182500000007, 1028.182400000007, 1028.182300000007, 1028.182200000007, 1028.182100000007, 1028.182000000007, 1028.181900000007, 1028.1818000000071, 1028.1817000000071, 1028.1816000000072, 1028.1815000000072, 1028.1814000000072, 1028.1813000000072, 1028.1812000000073, 1028.1811000000073, 1028.1810000000073, 1028.1809000000073, 1028.1808000000074, 1028.1807000000074, 1028.1806000000074, 1028.1805000000074, 1028.1804000000075, 1028.1803000000075, 1028.1802000000075, 1028.1801000000075, 1028.1800000000076, 1028.1799000000076, 1028.1798000000076, 1028.1797000000076, 1028.1796000000077, 1028.1795000000077, 1028.1794000000077, 1028.1793000000077, 1028.1792000000078, 1028.1791000000078, 1028.1790000000078, 1028.1789000000078, 1028.1788000000079, 1028.178700000008, 1028.178600000008, 1028.178500000008, 1028.178400000008, 1028.178300000008, 1028.178200000008, 1028.178100000008, 1028.178000000008, 1028.177900000008, 1028.1778000000081, 1028.1777000000081, 1028.1776000000082, 1028.1775000000082, 1028.1774000000082, 1028.1773000000082, 1028.1772000000083, 1028.1771000000083, 1028.1770000000083, 1028.1769000000083, 1028.1768000000084, 1028.1767000000084, 1028.1766000000084, 1028.1765000000084, 1028.1764000000085]}"	"{\\"tm\\": [\\"2023-02-04\\", \\"2023-02-05\\", \\"2023-02-06\\", \\"2023-02-07\\", \\"2023-02-08\\", \\"2023-02-09\\", \\"2023-02-10\\", \\"2023-02-11\\", \\"2023-02-12\\", \\"2023-02-13\\", \\"2023-02-14\\", \\"2023-02-15\\", \\"2023-02-16\\", \\"2023-02-17\\", \\"2023-02-18\\", \\"2023-02-19\\", \\"2023-02-20\\", \\"2023-02-21\\", \\"2023-02-22\\", \\"2023-02-23\\", \\"2023-02-24\\", \\"2023-02-25\\", \\"2023-02-26\\", \\"2023-02-27\\", \\"2023-02-28\\", \\"2023-03-01\\", \\"2023-03-02\\", \\"2023-03-03\\", \\"2023-03-04\\", \\"2023-03-05\\", \\"2023-03-06\\"], \\"bal\\": [1028.2051999999999, 1028.2027999999998, 1028.2003999999997, 1028.1979999999996, 1028.1955999999996, 1028.1931999999995, 1028.1907999999994, 1028.1883999999993, 1028.1859999999992, 1028.1835999999992, 1028.181199999999, 1028.178799999999, 1028.176399999999, 1028.1739999999988, 1028.1715999999988, 1028.1691999999987, 1028.1667999999986, 1028.1643999999985, 1028.1619999999984, 1028.1595999999984, 1028.1571999999983, 1028.1547999999982, 1028.1523999999981, 1028.149999999998, 1028.147599999998, 1048.1451999999979, 1048.1427999999978, 1048.1403999999977, 1048.1379999999976, 1048.1355999999976, 1048.1331999999975]}"	"{\\"tm\\": [\\"2023-02\\", \\"2023-03\\", \\"2023-04\\", \\"2023-05\\", \\"2023-06\\", \\"2023-07\\", \\"2023-08\\", \\"2023-09\\", \\"2023-10\\", \\"2023-11\\", \\"2023-12\\", \\"2024-01\\", \\"2024-02\\"], \\"bal\\": [1028.147599999998, 1048.073199999998, 1068.001199999998, 1087.9267999999981, 1107.8547999999982, 1127.7803999999983, 1147.7059999999983, 1167.6339999999984, 1187.5595999999985, 1207.4875999999986, 1227.4131999999986, 1247.3387999999986, 1267.2691999999986]}"	"{\\"tm\\": [\\"2023-02-03T16:30\\", \\"2023-02-03T17:30\\", \\"2023-02-03T18:30\\", \\"2023-02-03T19:30\\", \\"2023-02-03T20:30\\", \\"2023-02-03T21:30\\", \\"2023-02-03T22:30\\", \\"2023-02-03T23:30\\", \\"2023-02-04T00:30\\", \\"2023-02-04T01:30\\", \\"2023-02-04T02:30\\", \\"2023-02-04T03:30\\", \\"2023-02-04T04:30\\", \\"2023-02-04T05:30\\", \\"2023-02-04T06:30\\", \\"2023-02-04T07:30\\", \\"2023-02-04T08:30\\", \\"2023-02-04T09:30\\", \\"2023-02-04T10:30\\", \\"2023-02-04T11:30\\", \\"2023-02-04T12:30\\", \\"2023-02-04T13:30\\", \\"2023-02-04T14:30\\", \\"2023-02-04T15:30\\", \\"2023-02-04T16:30\\", \\"2023-02-04T17:30\\", \\"2023-02-04T18:30\\", \\"2023-02-04T19:30\\", \\"2023-02-04T20:30\\", \\"2023-02-04T21:30\\", \\"2023-02-04T22:30\\", \\"2023-02-04T23:30\\", \\"2023-02-05T00:30\\", \\"2023-02-05T01:30\\", \\"2023-02-05T02:30\\", \\"2023-02-05T03:30\\", \\"2023-02-05T04:30\\", \\"2023-02-05T05:30\\", \\"2023-02-05T06:30\\", \\"2023-02-05T07:30\\", \\"2023-02-05T08:30\\", \\"2023-02-05T09:30\\", \\"2023-02-05T10:30\\", \\"2023-02-05T11:30\\", \\"2023-02-05T12:30\\", \\"2023-02-05T13:30\\", \\"2023-02-05T14:30\\", \\"2023-02-05T15:30\\", \\"2023-02-05T16:30\\", \\"2023-02-05T17:30\\", \\"2023-02-05T18:30\\", \\"2023-02-05T19:30\\", \\"2023-02-05T20:30\\", \\"2023-02-05T21:30\\", \\"2023-02-05T22:30\\", \\"2023-02-05T23:30\\", \\"2023-02-06T00:30\\", \\"2023-02-06T01:30\\", \\"2023-02-06T02:30\\", \\"2023-02-06T03:30\\", \\"2023-02-06T04:30\\", \\"2023-02-06T05:30\\", \\"2023-02-06T06:30\\", \\"2023-02-06T07:30\\", \\"2023-02-06T08:30\\", \\"2023-02-06T09:30\\", \\"2023-02-06T10:30\\", \\"2023-02-06T11:30\\", \\"2023-02-06T12:30\\", \\"2023-02-06T13:30\\", \\"2023-02-06T14:30\\", \\"2023-02-06T15:30\\", \\"2023-02-06T16:30\\", \\"2023-02-06T17:30\\", \\"2023-02-06T18:30\\", \\"2023-02-06T19:30\\", \\"2023-02-06T20:30\\", \\"2023-02-06T21:30\\", \\"2023-02-06T22:30\\", \\"2023-02-06T23:30\\", \\"2023-02-07T00:30\\", \\"2023-02-07T01:30\\", \\"2023-02-07T02:30\\", \\"2023-02-07T03:30\\", \\"2023-02-07T04:30\\", \\"2023-02-07T05:30\\", \\"2023-02-07T06:30\\", \\"2023-02-07T07:30\\", \\"2023-02-07T08:30\\", \\"2023-02-07T09:30\\", \\"2023-02-07T10:30\\", \\"2023-02-07T11:30\\", \\"2023-02-07T12:30\\", \\"2023-02-07T13:30\\", \\"2023-02-07T14:30\\", \\"2023-02-07T15:30\\", \\"2023-02-07T16:30\\", \\"2023-02-07T17:30\\", \\"2023-02-07T18:30\\", \\"2023-02-07T19:30\\", \\"2023-02-07T20:30\\", \\"2023-02-07T21:30\\", \\"2023-02-07T22:30\\", \\"2023-02-07T23:30\\", \\"2023-02-08T00:30\\", \\"2023-02-08T01:30\\", \\"2023-02-08T02:30\\", \\"2023-02-08T03:30\\", \\"2023-02-08T04:30\\", \\"2023-02-08T05:30\\", \\"2023-02-08T06:30\\", \\"2023-02-08T07:30\\", \\"2023-02-08T08:30\\", \\"2023-02-08T09:30\\", \\"2023-02-08T10:30\\", \\"2023-02-08T11:30\\", \\"2023-02-08T12:30\\", \\"2023-02-08T13:30\\", \\"2023-02-08T14:30\\", \\"2023-02-08T15:30\\", \\"2023-02-08T16:30\\", \\"2023-02-08T17:30\\", \\"2023-02-08T18:30\\", \\"2023-02-08T19:30\\", \\"2023-02-08T20:30\\", \\"2023-02-08T21:30\\", \\"2023-02-08T22:30\\", \\"2023-02-08T23:30\\", \\"2023-02-09T00:30\\", \\"2023-02-09T01:30\\", \\"2023-02-09T02:30\\", \\"2023-02-09T03:30\\", \\"2023-02-09T04:30\\", \\"2023-02-09T05:30\\", \\"2023-02-09T06:30\\", \\"2023-02-09T07:30\\", \\"2023-02-09T08:30\\", \\"2023-02-09T09:30\\", \\"2023-02-09T10:30\\", \\"2023-02-09T11:30\\", \\"2023-02-09T12:30\\", \\"2023-02-09T13:30\\", \\"2023-02-09T14:30\\", \\"2023-02-09T15:30\\", \\"2023-02-09T16:30\\", \\"2023-02-09T17:30\\", \\"2023-02-09T18:30\\", \\"2023-02-09T19:30\\", \\"2023-02-09T20:30\\", \\"2023-02-09T21:30\\", \\"2023-02-09T22:30\\", \\"2023-02-09T23:30\\", \\"2023-02-10T00:30\\", \\"2023-02-10T01:30\\", \\"2023-02-10T02:30\\", \\"2023-02-10T03:30\\", \\"2023-02-10T04:30\\", \\"2023-02-10T05:30\\", \\"2023-02-10T06:30\\", \\"2023-02-10T07:30\\", \\"2023-02-10T08:30\\", \\"2023-02-10T09:30\\", \\"2023-02-10T10:30\\", \\"2023-02-10T11:30\\", \\"2023-02-10T12:30\\", \\"2023-02-10T13:30\\", \\"2023-02-10T14:30\\", \\"2023-02-10T15:30\\", \\"2023-02-10T16:30\\", \\"2023-02-10T17:30\\", \\"2023-02-10T18:30\\", \\"2023-02-10T19:30\\", \\"2023-02-10T20:30\\", \\"2023-02-10T21:30\\", \\"2023-02-10T22:30\\", \\"2023-02-10T23:30\\", \\"2023-02-11T00:30\\", \\"2023-02-11T01:30\\", \\"2023-02-11T02:30\\", \\"2023-02-11T03:30\\", \\"2023-02-11T04:30\\", \\"2023-02-11T05:30\\", \\"2023-02-11T06:30\\", \\"2023-02-11T07:30\\", \\"2023-02-11T08:30\\", \\"2023-02-11T09:30\\", \\"2023-02-11T10:30\\", \\"2023-02-11T11:30\\", \\"2023-02-11T12:30\\", \\"2023-02-11T13:30\\", \\"2023-02-11T14:30\\", \\"2023-02-11T15:30\\", \\"2023-02-11T16:30\\", \\"2023-02-11T17:30\\", \\"2023-02-11T18:30\\", \\"2023-02-11T19:30\\", \\"2023-02-11T20:30\\", \\"2023-02-11T21:30\\", \\"2023-02-11T22:30\\", \\"2023-02-11T23:30\\", \\"2023-02-12T00:30\\", \\"2023-02-12T01:30\\", \\"2023-02-12T02:30\\", \\"2023-02-12T03:30\\", \\"2023-02-12T04:30\\", \\"2023-02-12T05:30\\", \\"2023-02-12T06:30\\", \\"2023-02-12T07:30\\", \\"2023-02-12T08:30\\", \\"2023-02-12T09:30\\", \\"2023-02-12T10:30\\", \\"2023-02-12T11:30\\", \\"2023-02-12T12:30\\", \\"2023-02-12T13:30\\", \\"2023-02-12T14:30\\", \\"2023-02-12T15:30\\", \\"2023-02-12T16:30\\", \\"2023-02-12T17:30\\", \\"2023-02-12T18:30\\", \\"2023-02-12T19:30\\", \\"2023-02-12T20:30\\", \\"2023-02-12T21:30\\", \\"2023-02-12T22:30\\", \\"2023-02-12T23:30\\", \\"2023-02-13T00:30\\", \\"2023-02-13T01:30\\", \\"2023-02-13T02:30\\", \\"2023-02-13T03:30\\", \\"2023-02-13T04:30\\", \\"2023-02-13T05:30\\", \\"2023-02-13T06:30\\", \\"2023-02-13T07:30\\", \\"2023-02-13T08:30\\", \\"2023-02-13T09:30\\", \\"2023-02-13T10:30\\", \\"2023-02-13T11:30\\", \\"2023-02-13T12:30\\", \\"2023-02-13T13:30\\", \\"2023-02-13T14:30\\", \\"2023-02-13T15:30\\", \\"2023-02-13T16:30\\", \\"2023-02-13T17:30\\", \\"2023-02-13T18:30\\", \\"2023-02-13T19:30\\", \\"2023-02-13T20:30\\", \\"2023-02-13T21:30\\", \\"2023-02-13T22:30\\", \\"2023-02-13T23:30\\", \\"2023-02-14T00:30\\", \\"2023-02-14T01:30\\", \\"2023-02-14T02:30\\", \\"2023-02-14T03:30\\", \\"2023-02-14T04:30\\", \\"2023-02-14T05:30\\", \\"2023-02-14T06:30\\", \\"2023-02-14T07:30\\", \\"2023-02-14T08:30\\", \\"2023-02-14T09:30\\", \\"2023-02-14T10:30\\", \\"2023-02-14T11:30\\", \\"2023-02-14T12:30\\", \\"2023-02-14T13:30\\", \\"2023-02-14T14:30\\", \\"2023-02-14T15:30\\", \\"2023-02-14T16:30\\", \\"2023-02-14T17:30\\", \\"2023-02-14T18:30\\", \\"2023-02-14T19:30\\", \\"2023-02-14T20:30\\", \\"2023-02-14T21:30\\", \\"2023-02-14T22:30\\", \\"2023-02-14T23:30\\", \\"2023-02-15T00:30\\", \\"2023-02-15T01:30\\", \\"2023-02-15T02:30\\", \\"2023-02-15T03:30\\", \\"2023-02-15T04:30\\", \\"2023-02-15T05:30\\", \\"2023-02-15T06:30\\", \\"2023-02-15T07:30\\", \\"2023-02-15T08:30\\", \\"2023-02-15T09:30\\", \\"2023-02-15T10:30\\", \\"2023-02-15T11:30\\", \\"2023-02-15T12:30\\", \\"2023-02-15T13:30\\", \\"2023-02-15T14:30\\", \\"2023-02-15T15:30\\", \\"2023-02-15T16:30\\", \\"2023-02-15T17:30\\", \\"2023-02-15T18:30\\", \\"2023-02-15T19:30\\", \\"2023-02-15T20:30\\", \\"2023-02-15T21:30\\", \\"2023-02-15T22:30\\", \\"2023-02-15T23:30\\", \\"2023-02-16T00:30\\", \\"2023-02-16T01:30\\", \\"2023-02-16T02:30\\", \\"2023-02-16T03:30\\", \\"2023-02-16T04:30\\", \\"2023-02-16T05:30\\", \\"2023-02-16T06:30\\", \\"2023-02-16T07:30\\", \\"2023-02-16T08:30\\", \\"2023-02-16T09:30\\", \\"2023-02-16T10:30\\", \\"2023-02-16T11:30\\", \\"2023-02-16T12:30\\", \\"2023-02-16T13:30\\", \\"2023-02-16T14:30\\", \\"2023-02-16T15:30\\", \\"2023-02-16T16:30\\", \\"2023-02-16T17:30\\", \\"2023-02-16T18:30\\", \\"2023-02-16T19:30\\", \\"2023-02-16T20:30\\", \\"2023-02-16T21:30\\", \\"2023-02-16T22:30\\", \\"2023-02-16T23:30\\", \\"2023-02-17T00:30\\", \\"2023-02-17T01:30\\", \\"2023-02-17T02:30\\", \\"2023-02-17T03:30\\", \\"2023-02-17T04:30\\", \\"2023-02-17T05:30\\", \\"2023-02-17T06:30\\", \\"2023-02-17T07:30\\", \\"2023-02-17T08:30\\", \\"2023-02-17T09:30\\", \\"2023-02-17T10:30\\", \\"2023-02-17T11:30\\", \\"2023-02-17T12:30\\", \\"2023-02-17T13:30\\", \\"2023-02-17T14:30\\", \\"2023-02-17T15:30\\"], \\"bal\\": [1025.797, 1023.384, 1020.971, 1018.558, 1016.145, 1013.732, 1011.319, 1008.906, 1006.4929999999999, 1004.0799999999999, 1001.6669999999999, 999.2539999999999, 996.8409999999999, 994.4279999999999, 992.0149999999999, 989.6019999999999, 987.1889999999999, 984.7759999999998, 982.3629999999998, 979.9499999999998, 977.5369999999998, 975.1239999999998, 972.7109999999998, 970.2979999999998, 967.8849999999998, 965.4719999999998, 963.0589999999997, 960.6459999999997, 958.2329999999997, 955.8199999999997, 953.4069999999997, 950.9939999999997, 948.5809999999997, 946.1679999999997, 943.7549999999997, 941.3419999999996, 938.9289999999996, 936.5159999999996, 934.1029999999996, 931.6899999999996, 929.2769999999996, 926.8639999999996, 924.4509999999996, 922.0379999999996, 919.6249999999995, 917.2119999999995, 914.7989999999995, 912.3859999999995, 909.9729999999995, 907.5599999999995, 905.1469999999995, 902.7339999999995, 900.3209999999995, 897.9079999999994, 895.4949999999994, 893.0819999999994, 890.6689999999994, 888.2559999999994, 885.8429999999994, 883.4299999999994, 881.0169999999994, 878.6039999999994, 876.1909999999993, 873.7779999999993, 871.3649999999993, 868.9519999999993, 866.5389999999993, 864.1259999999993, 861.7129999999993, 859.2999999999993, 856.8869999999993, 854.4739999999993, 852.0609999999992, 849.6479999999992, 847.2349999999992, 844.8219999999992, 842.4089999999992, 839.9959999999992, 837.5829999999992, 835.1699999999992, 832.7569999999992, 830.3439999999991, 827.9309999999991, 825.5179999999991, 823.1049999999991, 820.6919999999991, 818.2789999999991, 815.8659999999991, 813.4529999999991, 811.039999999999, 808.626999999999, 806.213999999999, 803.800999999999, 801.387999999999, 798.974999999999, 796.561999999999, 794.148999999999, 791.735999999999, 789.322999999999, 786.909999999999, 784.4969999999989, 782.0839999999989, 779.6709999999989, 777.2579999999989, 774.8449999999989, 772.4319999999989, 770.0189999999989, 767.6059999999989, 765.1929999999988, 762.7799999999988, 760.3669999999988, 757.9539999999988, 755.5409999999988, 753.1279999999988, 750.7149999999988, 748.3019999999988, 745.8889999999988, 743.4759999999987, 741.0629999999987, 738.6499999999987, 736.2369999999987, 733.8239999999987, 731.4109999999987, 728.9979999999987, 726.5849999999987, 724.1719999999987, 721.7589999999987, 719.3459999999986, 716.9329999999986, 714.5199999999986, 712.1069999999986, 709.6939999999986, 707.2809999999986, 704.8679999999986, 702.4549999999986, 700.0419999999986, 697.6289999999985, 695.2159999999985, 692.8029999999985, 690.3899999999985, 687.9769999999985, 685.5639999999985, 683.1509999999985, 680.7379999999985, 678.3249999999985, 675.9119999999984, 673.4989999999984, 671.0859999999984, 668.6729999999984, 666.2599999999984, 663.8469999999984, 661.4339999999984, 659.0209999999984, 656.6079999999984, 654.1949999999983, 651.7819999999983, 649.3689999999983, 646.9559999999983, 644.5429999999983, 642.1299999999983, 639.7169999999983, 637.3039999999983, 634.8909999999983, 632.4779999999982, 630.0649999999982, 627.6519999999982, 625.2389999999982, 622.8259999999982, 620.4129999999982, 617.9999999999982, 615.5869999999982, 613.1739999999982, 610.7609999999981, 608.3479999999981, 605.9349999999981, 603.5219999999981, 601.1089999999981, 598.6959999999981, 596.2829999999981, 593.8699999999981, 591.4569999999981, 589.043999999998, 586.630999999998, 584.217999999998, 581.804999999998, 579.391999999998, 576.978999999998, 574.565999999998, 572.152999999998, 569.739999999998, 567.326999999998, 564.9139999999979, 562.5009999999979, 560.0879999999979, 557.6749999999979, 555.2619999999979, 552.8489999999979, 550.4359999999979, 548.0229999999979, 545.6099999999979, 543.1969999999978, 540.7839999999978, 538.3709999999978, 535.9579999999978, 533.5449999999978, 531.1319999999978, 528.7189999999978, 526.3059999999978, 523.8929999999978, 521.4799999999977, 519.0669999999977, 516.6539999999977, 514.2409999999977, 511.8279999999977, 509.4149999999977, 507.0019999999977, 504.58899999999767, 502.17599999999766, 499.76299999999765, 497.34999999999764, 494.9369999999976, 492.5239999999976, 490.1109999999976, 487.6979999999976, 485.2849999999976, 482.87199999999757, 480.45899999999756, 478.04599999999755, 475.63299999999754, 473.2199999999975, 470.8069999999975, 468.3939999999975, 465.9809999999975, 463.5679999999975, 461.1549999999975, 458.74199999999746, 456.32899999999745, 453.91599999999744, 451.5029999999974, 449.0899999999974, 446.6769999999974, 444.2639999999974, 441.8509999999974, 439.4379999999974, 437.02499999999736, 434.61199999999735, 432.19899999999734, 429.78599999999733, 427.3729999999973, 424.9599999999973, 422.5469999999973, 420.1339999999973, 417.7209999999973, 415.30799999999726, 412.89499999999725, 410.48199999999724, 408.06899999999723, 405.6559999999972, 403.2429999999972, 400.8299999999972, 398.4169999999972, 396.0039999999972, 393.59099999999717, 391.17799999999716, 388.76499999999714, 386.35199999999713, 383.9389999999971, 381.5259999999971, 379.1129999999971, 376.6999999999971, 374.2869999999971, 371.87399999999707, 369.46099999999706, 367.04799999999705, 364.63499999999704, 362.221999999997, 359.808999999997, 357.395999999997, 354.982999999997, 352.569999999997, 350.15699999999697, 347.74399999999696, 345.33099999999695, 342.91799999999694, 340.5049999999969, 338.0919999999969, 335.6789999999969, 333.2659999999969, 330.8529999999969, 328.43999999999687, 326.02699999999686, 323.61399999999685, 321.20099999999684, 318.7879999999968, 316.3749999999968, 313.9619999999968, 311.5489999999968, 309.1359999999968, 306.7229999999968, 304.30999999999676, 301.89699999999675, 299.48399999999674, 297.07099999999673, 294.6579999999967, 292.2449999999967, 289.8319999999967, 287.4189999999967, 285.0059999999967, 282.59299999999666, 280.17999999999665, 277.76699999999664, 275.35399999999663, 272.9409999999966, 270.5279999999966, 268.1149999999966, 265.7019999999966, 263.2889999999966, 260.87599999999657, 258.46299999999655, 256.04999999999654, 253.63699999999653, 251.22399999999652, 248.8109999999965, 246.3979999999965, 243.9849999999965, 241.57199999999648, 239.15899999999647, 236.74599999999646, 234.33299999999645, 231.91999999999643, 229.50699999999642, 227.0939999999964, 224.6809999999964, 222.2679999999964, 219.85499999999638, 217.44199999999637]}"	"{\\"tm\\": [\\"2023-02-04\\", \\"2023-02-05\\", \\"2023-02-06\\", \\"2023-02-07\\", \\"2023-02-08\\", \\"2023-02-09\\", \\"2023-02-10\\", \\"2023-02-11\\", \\"2023-02-12\\", \\"2023-02-13\\", \\"2023-02-14\\", \\"2023-02-15\\", \\"2023-02-16\\", \\"2023-02-17\\", \\"2023-02-18\\", \\"2023-02-19\\", \\"2023-02-20\\", \\"2023-02-21\\", \\"2023-02-22\\", \\"2023-02-23\\", \\"2023-02-24\\", \\"2023-02-25\\", \\"2023-02-26\\", \\"2023-02-27\\", \\"2023-02-28\\", \\"2023-03-01\\", \\"2023-03-02\\", \\"2023-03-03\\", \\"2023-03-04\\", \\"2023-03-05\\", \\"2023-03-06\\"], \\"bal\\": [912.386, 854.4739999999999, 796.5619999999999, 738.6499999999999, 680.7379999999998, 622.8259999999998, 564.9139999999998, 507.0019999999997, 449.0899999999997, 391.17799999999966, 333.2659999999996, 275.3539999999996, 217.44199999999958, 159.52999999999957, 101.61799999999957, 43.70599999999956, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]}"	"{\\"tm\\": [\\"2023-02\\", \\"2023-03\\", \\"2023-04\\", \\"2023-05\\", \\"2023-06\\", \\"2023-07\\", \\"2023-08\\", \\"2023-09\\", \\"2023-10\\", \\"2023-11\\", \\"2023-12\\", \\"2024-01\\", \\"2024-02\\"], \\"bal\\": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]}"	latest	sliderule_1492	10	{"": ""}	2023-01-06 08:21:40-05	60	2023-01-06 08:21:40-05	f	t	3	f	72	14	0.00
\.


--
-- Data for Name: users_cluster; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.users_cluster (org_id, creation_date, modified_date, mgr_ip_address, active_ps_cmd, is_deployed, deployed_state, connection_status, version_query_log, cqro_id, cnnro_id) FROM stdin;
b5edeee0-8425-446c-a73f-47e5a20ef3ce	2023-01-06 08:22:01.945617-05	2023-01-31 10:54:05.267337-05	0.0.0.0		f	NOT deployed	unknown		ead26cb2-3ec0-44e5-8967-ad40538f970e	\N
\.


--
-- Data for Name: users_granchoice; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.users_granchoice (granularity) FROM stdin;
HOURLY
DAILY
MONTHLY
\.


--
-- Data for Name: users_membership; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.users_membership (id, active, creation_date, modified_date, delete_requested, activation_date, org_id, user_id) FROM stdin;
118bfc6c-8a20-45ba-84b7-03ab237722f4	t	2023-01-06 08:22:01.953704-05	2023-01-06 08:22:01.95371-05	f	2023-01-06 08:22:01.953713-05	b5edeee0-8425-446c-a73f-47e5a20ef3ce	3
\.


--
-- Data for Name: users_orgcost; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.users_orgcost (id, creation_date, modified_date, tm, cnt, avg, min, max, std, ccr, cost_refresh_time, gran_id, org_id) FROM stdin;
3	2023-01-06 08:22:01.950622-05	2023-02-03 11:30:52.926567-05	2023-01-31 19:00:00-05	0	0.8451381847615385	0	10.871156177	3.012613042400426	"{\\n  \\"orgName\\": \\"unit-test-org\\",\\n  \\"granularity\\": \\"MONTHLY\\",\\n  \\"total\\": 10.9867964019,\\n  \\"unit\\": \\"USD\\",\\n  \\"tm\\": [\\n    \\"2022-02-03\\",\\n    \\"2022-03-01\\",\\n    \\"2022-04-01\\",\\n    \\"2022-05-01\\",\\n    \\"2022-06-01\\",\\n    \\"2022-07-01\\",\\n    \\"2022-08-01\\",\\n    \\"2022-09-01\\",\\n    \\"2022-10-01\\",\\n    \\"2022-11-01\\",\\n    \\"2022-12-01\\",\\n    \\"2023-01-01\\",\\n    \\"2023-02-01\\"\\n  ],\\n  \\"cost\\": [\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.1156402249,\\n    10.871156177,\\n    0.0\\n  ],\\n  \\"stats\\": {\\n    \\"avg\\": 0.8451381847615385,\\n    \\"max\\": 10.871156177,\\n    \\"std\\": 3.012613042400426\\n  }\\n}"	2023-02-03 11:30:50.22791-05	MONTHLY	b5edeee0-8425-446c-a73f-47e5a20ef3ce
2	2023-01-06 08:22:01.949494-05	2023-02-03 09:10:00.662211-05	2023-02-01 19:00:00-05	0	0.03010081206	0	7.0983400722	0.42030612309748394	"{\\n  \\"orgName\\": \\"unit-test-org\\",\\n  \\"granularity\\": \\"DAILY\\",\\n  \\"total\\": 10.9867964019,\\n  \\"unit\\": \\"USD\\",\\n  \\"tm\\": [\\n    \\"2022-02-03\\",\\n    \\"2022-02-04\\",\\n    \\"2022-02-05\\",\\n    \\"2022-02-06\\",\\n    \\"2022-02-07\\",\\n    \\"2022-02-08\\",\\n    \\"2022-02-09\\",\\n    \\"2022-02-10\\",\\n    \\"2022-02-11\\",\\n    \\"2022-02-12\\",\\n    \\"2022-02-13\\",\\n    \\"2022-02-14\\",\\n    \\"2022-02-15\\",\\n    \\"2022-02-16\\",\\n    \\"2022-02-17\\",\\n    \\"2022-02-18\\",\\n    \\"2022-02-19\\",\\n    \\"2022-02-20\\",\\n    \\"2022-02-21\\",\\n    \\"2022-02-22\\",\\n    \\"2022-02-23\\",\\n    \\"2022-02-24\\",\\n    \\"2022-02-25\\",\\n    \\"2022-02-26\\",\\n    \\"2022-02-27\\",\\n    \\"2022-02-28\\",\\n    \\"2022-03-01\\",\\n    \\"2022-03-02\\",\\n    \\"2022-03-03\\",\\n    \\"2022-03-04\\",\\n    \\"2022-03-05\\",\\n    \\"2022-03-06\\",\\n    \\"2022-03-07\\",\\n    \\"2022-03-08\\",\\n    \\"2022-03-09\\",\\n    \\"2022-03-10\\",\\n    \\"2022-03-11\\",\\n    \\"2022-03-12\\",\\n    \\"2022-03-13\\",\\n    \\"2022-03-14\\",\\n    \\"2022-03-15\\",\\n    \\"2022-03-16\\",\\n    \\"2022-03-17\\",\\n    \\"2022-03-18\\",\\n    \\"2022-03-19\\",\\n    \\"2022-03-20\\",\\n    \\"2022-03-21\\",\\n    \\"2022-03-22\\",\\n    \\"2022-03-23\\",\\n    \\"2022-03-24\\",\\n    \\"2022-03-25\\",\\n    \\"2022-03-26\\",\\n    \\"2022-03-27\\",\\n    \\"2022-03-28\\",\\n    \\"2022-03-29\\",\\n    \\"2022-03-30\\",\\n    \\"2022-03-31\\",\\n    \\"2022-04-01\\",\\n    \\"2022-04-02\\",\\n    \\"2022-04-03\\",\\n    \\"2022-04-04\\",\\n    \\"2022-04-05\\",\\n    \\"2022-04-06\\",\\n    \\"2022-04-07\\",\\n    \\"2022-04-08\\",\\n    \\"2022-04-09\\",\\n    \\"2022-04-10\\",\\n    \\"2022-04-11\\",\\n    \\"2022-04-12\\",\\n    \\"2022-04-13\\",\\n    \\"2022-04-14\\",\\n    \\"2022-04-15\\",\\n    \\"2022-04-16\\",\\n    \\"2022-04-17\\",\\n    \\"2022-04-18\\",\\n    \\"2022-04-19\\",\\n    \\"2022-04-20\\",\\n    \\"2022-04-21\\",\\n    \\"2022-04-22\\",\\n    \\"2022-04-23\\",\\n    \\"2022-04-24\\",\\n    \\"2022-04-25\\",\\n    \\"2022-04-26\\",\\n    \\"2022-04-27\\",\\n    \\"2022-04-28\\",\\n    \\"2022-04-29\\",\\n    \\"2022-04-30\\",\\n    \\"2022-05-01\\",\\n    \\"2022-05-02\\",\\n    \\"2022-05-03\\",\\n    \\"2022-05-04\\",\\n    \\"2022-05-05\\",\\n    \\"2022-05-06\\",\\n    \\"2022-05-07\\",\\n    \\"2022-05-08\\",\\n    \\"2022-05-09\\",\\n    \\"2022-05-10\\",\\n    \\"2022-05-11\\",\\n    \\"2022-05-12\\",\\n    \\"2022-05-13\\",\\n    \\"2022-05-14\\",\\n    \\"2022-05-15\\",\\n    \\"2022-05-16\\",\\n    \\"2022-05-17\\",\\n    \\"2022-05-18\\",\\n    \\"2022-05-19\\",\\n    \\"2022-05-20\\",\\n    \\"2022-05-21\\",\\n    \\"2022-05-22\\",\\n    \\"2022-05-23\\",\\n    \\"2022-05-24\\",\\n    \\"2022-05-25\\",\\n    \\"2022-05-26\\",\\n    \\"2022-05-27\\",\\n    \\"2022-05-28\\",\\n    \\"2022-05-29\\",\\n    \\"2022-05-30\\",\\n    \\"2022-05-31\\",\\n    \\"2022-06-01\\",\\n    \\"2022-06-02\\",\\n    \\"2022-06-03\\",\\n    \\"2022-06-04\\",\\n    \\"2022-06-05\\",\\n    \\"2022-06-06\\",\\n    \\"2022-06-07\\",\\n    \\"2022-06-08\\",\\n    \\"2022-06-09\\",\\n    \\"2022-06-10\\",\\n    \\"2022-06-11\\",\\n    \\"2022-06-12\\",\\n    \\"2022-06-13\\",\\n    \\"2022-06-14\\",\\n    \\"2022-06-15\\",\\n    \\"2022-06-16\\",\\n    \\"2022-06-17\\",\\n    \\"2022-06-18\\",\\n    \\"2022-06-19\\",\\n    \\"2022-06-20\\",\\n    \\"2022-06-21\\",\\n    \\"2022-06-22\\",\\n    \\"2022-06-23\\",\\n    \\"2022-06-24\\",\\n    \\"2022-06-25\\",\\n    \\"2022-06-26\\",\\n    \\"2022-06-27\\",\\n    \\"2022-06-28\\",\\n    \\"2022-06-29\\",\\n    \\"2022-06-30\\",\\n    \\"2022-07-01\\",\\n    \\"2022-07-02\\",\\n    \\"2022-07-03\\",\\n    \\"2022-07-04\\",\\n    \\"2022-07-05\\",\\n    \\"2022-07-06\\",\\n    \\"2022-07-07\\",\\n    \\"2022-07-08\\",\\n    \\"2022-07-09\\",\\n    \\"2022-07-10\\",\\n    \\"2022-07-11\\",\\n    \\"2022-07-12\\",\\n    \\"2022-07-13\\",\\n    \\"2022-07-14\\",\\n    \\"2022-07-15\\",\\n    \\"2022-07-16\\",\\n    \\"2022-07-17\\",\\n    \\"2022-07-18\\",\\n    \\"2022-07-19\\",\\n    \\"2022-07-20\\",\\n    \\"2022-07-21\\",\\n    \\"2022-07-22\\",\\n    \\"2022-07-23\\",\\n    \\"2022-07-24\\",\\n    \\"2022-07-25\\",\\n    \\"2022-07-26\\",\\n    \\"2022-07-27\\",\\n    \\"2022-07-28\\",\\n    \\"2022-07-29\\",\\n    \\"2022-07-30\\",\\n    \\"2022-07-31\\",\\n    \\"2022-08-01\\",\\n    \\"2022-08-02\\",\\n    \\"2022-08-03\\",\\n    \\"2022-08-04\\",\\n    \\"2022-08-05\\",\\n    \\"2022-08-06\\",\\n    \\"2022-08-07\\",\\n    \\"2022-08-08\\",\\n    \\"2022-08-09\\",\\n    \\"2022-08-10\\",\\n    \\"2022-08-11\\",\\n    \\"2022-08-12\\",\\n    \\"2022-08-13\\",\\n    \\"2022-08-14\\",\\n    \\"2022-08-15\\",\\n    \\"2022-08-16\\",\\n    \\"2022-08-17\\",\\n    \\"2022-08-18\\",\\n    \\"2022-08-19\\",\\n    \\"2022-08-20\\",\\n    \\"2022-08-21\\",\\n    \\"2022-08-22\\",\\n    \\"2022-08-23\\",\\n    \\"2022-08-24\\",\\n    \\"2022-08-25\\",\\n    \\"2022-08-26\\",\\n    \\"2022-08-27\\",\\n    \\"2022-08-28\\",\\n    \\"2022-08-29\\",\\n    \\"2022-08-30\\",\\n    \\"2022-08-31\\",\\n    \\"2022-09-01\\",\\n    \\"2022-09-02\\",\\n    \\"2022-09-03\\",\\n    \\"2022-09-04\\",\\n    \\"2022-09-05\\",\\n    \\"2022-09-06\\",\\n    \\"2022-09-07\\",\\n    \\"2022-09-08\\",\\n    \\"2022-09-09\\",\\n    \\"2022-09-10\\",\\n    \\"2022-09-11\\",\\n    \\"2022-09-12\\",\\n    \\"2022-09-13\\",\\n    \\"2022-09-14\\",\\n    \\"2022-09-15\\",\\n    \\"2022-09-16\\",\\n    \\"2022-09-17\\",\\n    \\"2022-09-18\\",\\n    \\"2022-09-19\\",\\n    \\"2022-09-20\\",\\n    \\"2022-09-21\\",\\n    \\"2022-09-22\\",\\n    \\"2022-09-23\\",\\n    \\"2022-09-24\\",\\n    \\"2022-09-25\\",\\n    \\"2022-09-26\\",\\n    \\"2022-09-27\\",\\n    \\"2022-09-28\\",\\n    \\"2022-09-29\\",\\n    \\"2022-09-30\\",\\n    \\"2022-10-01\\",\\n    \\"2022-10-02\\",\\n    \\"2022-10-03\\",\\n    \\"2022-10-04\\",\\n    \\"2022-10-05\\",\\n    \\"2022-10-06\\",\\n    \\"2022-10-07\\",\\n    \\"2022-10-08\\",\\n    \\"2022-10-09\\",\\n    \\"2022-10-10\\",\\n    \\"2022-10-11\\",\\n    \\"2022-10-12\\",\\n    \\"2022-10-13\\",\\n    \\"2022-10-14\\",\\n    \\"2022-10-15\\",\\n    \\"2022-10-16\\",\\n    \\"2022-10-17\\",\\n    \\"2022-10-18\\",\\n    \\"2022-10-19\\",\\n    \\"2022-10-20\\",\\n    \\"2022-10-21\\",\\n    \\"2022-10-22\\",\\n    \\"2022-10-23\\",\\n    \\"2022-10-24\\",\\n    \\"2022-10-25\\",\\n    \\"2022-10-26\\",\\n    \\"2022-10-27\\",\\n    \\"2022-10-28\\",\\n    \\"2022-10-29\\",\\n    \\"2022-10-30\\",\\n    \\"2022-10-31\\",\\n    \\"2022-11-01\\",\\n    \\"2022-11-02\\",\\n    \\"2022-11-03\\",\\n    \\"2022-11-04\\",\\n    \\"2022-11-05\\",\\n    \\"2022-11-06\\",\\n    \\"2022-11-07\\",\\n    \\"2022-11-08\\",\\n    \\"2022-11-09\\",\\n    \\"2022-11-10\\",\\n    \\"2022-11-11\\",\\n    \\"2022-11-12\\",\\n    \\"2022-11-13\\",\\n    \\"2022-11-14\\",\\n    \\"2022-11-15\\",\\n    \\"2022-11-16\\",\\n    \\"2022-11-17\\",\\n    \\"2022-11-18\\",\\n    \\"2022-11-19\\",\\n    \\"2022-11-20\\",\\n    \\"2022-11-21\\",\\n    \\"2022-11-22\\",\\n    \\"2022-11-23\\",\\n    \\"2022-11-24\\",\\n    \\"2022-11-25\\",\\n    \\"2022-11-26\\",\\n    \\"2022-11-27\\",\\n    \\"2022-11-28\\",\\n    \\"2022-11-29\\",\\n    \\"2022-11-30\\",\\n    \\"2022-12-01\\",\\n    \\"2022-12-02\\",\\n    \\"2022-12-03\\",\\n    \\"2022-12-04\\",\\n    \\"2022-12-05\\",\\n    \\"2022-12-06\\",\\n    \\"2022-12-07\\",\\n    \\"2022-12-08\\",\\n    \\"2022-12-09\\",\\n    \\"2022-12-10\\",\\n    \\"2022-12-11\\",\\n    \\"2022-12-12\\",\\n    \\"2022-12-13\\",\\n    \\"2022-12-14\\",\\n    \\"2022-12-15\\",\\n    \\"2022-12-16\\",\\n    \\"2022-12-17\\",\\n    \\"2022-12-18\\",\\n    \\"2022-12-19\\",\\n    \\"2022-12-20\\",\\n    \\"2022-12-21\\",\\n    \\"2022-12-22\\",\\n    \\"2022-12-23\\",\\n    \\"2022-12-24\\",\\n    \\"2022-12-25\\",\\n    \\"2022-12-26\\",\\n    \\"2022-12-27\\",\\n    \\"2022-12-28\\",\\n    \\"2022-12-29\\",\\n    \\"2022-12-30\\",\\n    \\"2022-12-31\\",\\n    \\"2023-01-01\\",\\n    \\"2023-01-02\\",\\n    \\"2023-01-03\\",\\n    \\"2023-01-04\\",\\n    \\"2023-01-05\\",\\n    \\"2023-01-06\\",\\n    \\"2023-01-07\\",\\n    \\"2023-01-08\\",\\n    \\"2023-01-09\\",\\n    \\"2023-01-10\\",\\n    \\"2023-01-11\\",\\n    \\"2023-01-12\\",\\n    \\"2023-01-13\\",\\n    \\"2023-01-14\\",\\n    \\"2023-01-15\\",\\n    \\"2023-01-16\\",\\n    \\"2023-01-17\\",\\n    \\"2023-01-18\\",\\n    \\"2023-01-19\\",\\n    \\"2023-01-20\\",\\n    \\"2023-01-21\\",\\n    \\"2023-01-22\\",\\n    \\"2023-01-23\\",\\n    \\"2023-01-24\\",\\n    \\"2023-01-25\\",\\n    \\"2023-01-26\\",\\n    \\"2023-01-27\\",\\n    \\"2023-01-28\\",\\n    \\"2023-01-29\\",\\n    \\"2023-01-30\\",\\n    \\"2023-01-31\\",\\n    \\"2023-02-01\\",\\n    \\"2023-02-02\\"\\n  ],\\n  \\"cost\\": [\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.1156402249,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    3.7728161048,\\n    7.0983400722,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0\\n  ],\\n  \\"stats\\": {\\n    \\"avg\\": 0.03010081206,\\n    \\"max\\": 7.0983400722,\\n    \\"std\\": 0.42030612309748394\\n  }\\n}"	2023-02-03 09:09:58.002113-05	DAILY	b5edeee0-8425-446c-a73f-47e5a20ef3ce
1	2023-01-06 08:22:01.947661-05	2023-02-03 15:46:37.121633-05	2023-01-24 09:00:00-05	0	0.031245406130059522	0	0.3786418627	0.10348915212516253	"{\\n  \\"orgName\\": \\"unit-test-org\\",\\n  \\"granularity\\": \\"HOURLY\\",\\n  \\"total\\": 10.4984564597,\\n  \\"unit\\": \\"USD\\",\\n  \\"tm\\": [\\n    \\"2023-01-10T15:00:00Z\\",\\n    \\"2023-01-10T16:00:00Z\\",\\n    \\"2023-01-10T17:00:00Z\\",\\n    \\"2023-01-10T18:00:00Z\\",\\n    \\"2023-01-10T19:00:00Z\\",\\n    \\"2023-01-10T20:00:00Z\\",\\n    \\"2023-01-10T21:00:00Z\\",\\n    \\"2023-01-10T22:00:00Z\\",\\n    \\"2023-01-10T23:00:00Z\\",\\n    \\"2023-01-11T00:00:00Z\\",\\n    \\"2023-01-11T01:00:00Z\\",\\n    \\"2023-01-11T02:00:00Z\\",\\n    \\"2023-01-11T03:00:00Z\\",\\n    \\"2023-01-11T04:00:00Z\\",\\n    \\"2023-01-11T05:00:00Z\\",\\n    \\"2023-01-11T06:00:00Z\\",\\n    \\"2023-01-11T07:00:00Z\\",\\n    \\"2023-01-11T08:00:00Z\\",\\n    \\"2023-01-11T09:00:00Z\\",\\n    \\"2023-01-11T10:00:00Z\\",\\n    \\"2023-01-11T11:00:00Z\\",\\n    \\"2023-01-11T12:00:00Z\\",\\n    \\"2023-01-11T13:00:00Z\\",\\n    \\"2023-01-11T14:00:00Z\\",\\n    \\"2023-01-11T15:00:00Z\\",\\n    \\"2023-01-11T16:00:00Z\\",\\n    \\"2023-01-11T17:00:00Z\\",\\n    \\"2023-01-11T18:00:00Z\\",\\n    \\"2023-01-11T19:00:00Z\\",\\n    \\"2023-01-11T20:00:00Z\\",\\n    \\"2023-01-11T21:00:00Z\\",\\n    \\"2023-01-11T22:00:00Z\\",\\n    \\"2023-01-11T23:00:00Z\\",\\n    \\"2023-01-12T00:00:00Z\\",\\n    \\"2023-01-12T01:00:00Z\\",\\n    \\"2023-01-12T02:00:00Z\\",\\n    \\"2023-01-12T03:00:00Z\\",\\n    \\"2023-01-12T04:00:00Z\\",\\n    \\"2023-01-12T05:00:00Z\\",\\n    \\"2023-01-12T06:00:00Z\\",\\n    \\"2023-01-12T07:00:00Z\\",\\n    \\"2023-01-12T08:00:00Z\\",\\n    \\"2023-01-12T09:00:00Z\\",\\n    \\"2023-01-12T10:00:00Z\\",\\n    \\"2023-01-12T11:00:00Z\\",\\n    \\"2023-01-12T12:00:00Z\\",\\n    \\"2023-01-12T13:00:00Z\\",\\n    \\"2023-01-12T14:00:00Z\\",\\n    \\"2023-01-12T15:00:00Z\\",\\n    \\"2023-01-12T16:00:00Z\\",\\n    \\"2023-01-12T17:00:00Z\\",\\n    \\"2023-01-12T18:00:00Z\\",\\n    \\"2023-01-12T19:00:00Z\\",\\n    \\"2023-01-12T20:00:00Z\\",\\n    \\"2023-01-12T21:00:00Z\\",\\n    \\"2023-01-12T22:00:00Z\\",\\n    \\"2023-01-12T23:00:00Z\\",\\n    \\"2023-01-13T00:00:00Z\\",\\n    \\"2023-01-13T01:00:00Z\\",\\n    \\"2023-01-13T02:00:00Z\\",\\n    \\"2023-01-13T03:00:00Z\\",\\n    \\"2023-01-13T04:00:00Z\\",\\n    \\"2023-01-13T05:00:00Z\\",\\n    \\"2023-01-13T06:00:00Z\\",\\n    \\"2023-01-13T07:00:00Z\\",\\n    \\"2023-01-13T08:00:00Z\\",\\n    \\"2023-01-13T09:00:00Z\\",\\n    \\"2023-01-13T10:00:00Z\\",\\n    \\"2023-01-13T11:00:00Z\\",\\n    \\"2023-01-13T12:00:00Z\\",\\n    \\"2023-01-13T13:00:00Z\\",\\n    \\"2023-01-13T14:00:00Z\\",\\n    \\"2023-01-13T15:00:00Z\\",\\n    \\"2023-01-13T16:00:00Z\\",\\n    \\"2023-01-13T17:00:00Z\\",\\n    \\"2023-01-13T18:00:00Z\\",\\n    \\"2023-01-13T19:00:00Z\\",\\n    \\"2023-01-13T20:00:00Z\\",\\n    \\"2023-01-13T21:00:00Z\\",\\n    \\"2023-01-13T22:00:00Z\\",\\n    \\"2023-01-13T23:00:00Z\\",\\n    \\"2023-01-14T00:00:00Z\\",\\n    \\"2023-01-14T01:00:00Z\\",\\n    \\"2023-01-14T02:00:00Z\\",\\n    \\"2023-01-14T03:00:00Z\\",\\n    \\"2023-01-14T04:00:00Z\\",\\n    \\"2023-01-14T05:00:00Z\\",\\n    \\"2023-01-14T06:00:00Z\\",\\n    \\"2023-01-14T07:00:00Z\\",\\n    \\"2023-01-14T08:00:00Z\\",\\n    \\"2023-01-14T09:00:00Z\\",\\n    \\"2023-01-14T10:00:00Z\\",\\n    \\"2023-01-14T11:00:00Z\\",\\n    \\"2023-01-14T12:00:00Z\\",\\n    \\"2023-01-14T13:00:00Z\\",\\n    \\"2023-01-14T14:00:00Z\\",\\n    \\"2023-01-14T15:00:00Z\\",\\n    \\"2023-01-14T16:00:00Z\\",\\n    \\"2023-01-14T17:00:00Z\\",\\n    \\"2023-01-14T18:00:00Z\\",\\n    \\"2023-01-14T19:00:00Z\\",\\n    \\"2023-01-14T20:00:00Z\\",\\n    \\"2023-01-14T21:00:00Z\\",\\n    \\"2023-01-14T22:00:00Z\\",\\n    \\"2023-01-14T23:00:00Z\\",\\n    \\"2023-01-15T00:00:00Z\\",\\n    \\"2023-01-15T01:00:00Z\\",\\n    \\"2023-01-15T02:00:00Z\\",\\n    \\"2023-01-15T03:00:00Z\\",\\n    \\"2023-01-15T04:00:00Z\\",\\n    \\"2023-01-15T05:00:00Z\\",\\n    \\"2023-01-15T06:00:00Z\\",\\n    \\"2023-01-15T07:00:00Z\\",\\n    \\"2023-01-15T08:00:00Z\\",\\n    \\"2023-01-15T09:00:00Z\\",\\n    \\"2023-01-15T10:00:00Z\\",\\n    \\"2023-01-15T11:00:00Z\\",\\n    \\"2023-01-15T12:00:00Z\\",\\n    \\"2023-01-15T13:00:00Z\\",\\n    \\"2023-01-15T14:00:00Z\\",\\n    \\"2023-01-15T15:00:00Z\\",\\n    \\"2023-01-15T16:00:00Z\\",\\n    \\"2023-01-15T17:00:00Z\\",\\n    \\"2023-01-15T18:00:00Z\\",\\n    \\"2023-01-15T19:00:00Z\\",\\n    \\"2023-01-15T20:00:00Z\\",\\n    \\"2023-01-15T21:00:00Z\\",\\n    \\"2023-01-15T22:00:00Z\\",\\n    \\"2023-01-15T23:00:00Z\\",\\n    \\"2023-01-16T00:00:00Z\\",\\n    \\"2023-01-16T01:00:00Z\\",\\n    \\"2023-01-16T02:00:00Z\\",\\n    \\"2023-01-16T03:00:00Z\\",\\n    \\"2023-01-16T04:00:00Z\\",\\n    \\"2023-01-16T05:00:00Z\\",\\n    \\"2023-01-16T06:00:00Z\\",\\n    \\"2023-01-16T07:00:00Z\\",\\n    \\"2023-01-16T08:00:00Z\\",\\n    \\"2023-01-16T09:00:00Z\\",\\n    \\"2023-01-16T10:00:00Z\\",\\n    \\"2023-01-16T11:00:00Z\\",\\n    \\"2023-01-16T12:00:00Z\\",\\n    \\"2023-01-16T13:00:00Z\\",\\n    \\"2023-01-16T14:00:00Z\\",\\n    \\"2023-01-16T15:00:00Z\\",\\n    \\"2023-01-16T16:00:00Z\\",\\n    \\"2023-01-16T17:00:00Z\\",\\n    \\"2023-01-16T18:00:00Z\\",\\n    \\"2023-01-16T19:00:00Z\\",\\n    \\"2023-01-16T20:00:00Z\\",\\n    \\"2023-01-16T21:00:00Z\\",\\n    \\"2023-01-16T22:00:00Z\\",\\n    \\"2023-01-16T23:00:00Z\\",\\n    \\"2023-01-17T00:00:00Z\\",\\n    \\"2023-01-17T01:00:00Z\\",\\n    \\"2023-01-17T02:00:00Z\\",\\n    \\"2023-01-17T03:00:00Z\\",\\n    \\"2023-01-17T04:00:00Z\\",\\n    \\"2023-01-17T05:00:00Z\\",\\n    \\"2023-01-17T06:00:00Z\\",\\n    \\"2023-01-17T07:00:00Z\\",\\n    \\"2023-01-17T08:00:00Z\\",\\n    \\"2023-01-17T09:00:00Z\\",\\n    \\"2023-01-17T10:00:00Z\\",\\n    \\"2023-01-17T11:00:00Z\\",\\n    \\"2023-01-17T12:00:00Z\\",\\n    \\"2023-01-17T13:00:00Z\\",\\n    \\"2023-01-17T14:00:00Z\\",\\n    \\"2023-01-17T15:00:00Z\\",\\n    \\"2023-01-17T16:00:00Z\\",\\n    \\"2023-01-17T17:00:00Z\\",\\n    \\"2023-01-17T18:00:00Z\\",\\n    \\"2023-01-17T19:00:00Z\\",\\n    \\"2023-01-17T20:00:00Z\\",\\n    \\"2023-01-17T21:00:00Z\\",\\n    \\"2023-01-17T22:00:00Z\\",\\n    \\"2023-01-17T23:00:00Z\\",\\n    \\"2023-01-18T00:00:00Z\\",\\n    \\"2023-01-18T01:00:00Z\\",\\n    \\"2023-01-18T02:00:00Z\\",\\n    \\"2023-01-18T03:00:00Z\\",\\n    \\"2023-01-18T04:00:00Z\\",\\n    \\"2023-01-18T05:00:00Z\\",\\n    \\"2023-01-18T06:00:00Z\\",\\n    \\"2023-01-18T07:00:00Z\\",\\n    \\"2023-01-18T08:00:00Z\\",\\n    \\"2023-01-18T09:00:00Z\\",\\n    \\"2023-01-18T10:00:00Z\\",\\n    \\"2023-01-18T11:00:00Z\\",\\n    \\"2023-01-18T12:00:00Z\\",\\n    \\"2023-01-18T13:00:00Z\\",\\n    \\"2023-01-18T14:00:00Z\\",\\n    \\"2023-01-18T15:00:00Z\\",\\n    \\"2023-01-18T16:00:00Z\\",\\n    \\"2023-01-18T17:00:00Z\\",\\n    \\"2023-01-18T18:00:00Z\\",\\n    \\"2023-01-18T19:00:00Z\\",\\n    \\"2023-01-18T20:00:00Z\\",\\n    \\"2023-01-18T21:00:00Z\\",\\n    \\"2023-01-18T22:00:00Z\\",\\n    \\"2023-01-18T23:00:00Z\\",\\n    \\"2023-01-19T00:00:00Z\\",\\n    \\"2023-01-19T01:00:00Z\\",\\n    \\"2023-01-19T02:00:00Z\\",\\n    \\"2023-01-19T03:00:00Z\\",\\n    \\"2023-01-19T04:00:00Z\\",\\n    \\"2023-01-19T05:00:00Z\\",\\n    \\"2023-01-19T06:00:00Z\\",\\n    \\"2023-01-19T07:00:00Z\\",\\n    \\"2023-01-19T08:00:00Z\\",\\n    \\"2023-01-19T09:00:00Z\\",\\n    \\"2023-01-19T10:00:00Z\\",\\n    \\"2023-01-19T11:00:00Z\\",\\n    \\"2023-01-19T12:00:00Z\\",\\n    \\"2023-01-19T13:00:00Z\\",\\n    \\"2023-01-19T14:00:00Z\\",\\n    \\"2023-01-19T15:00:00Z\\",\\n    \\"2023-01-19T16:00:00Z\\",\\n    \\"2023-01-19T17:00:00Z\\",\\n    \\"2023-01-19T18:00:00Z\\",\\n    \\"2023-01-19T19:00:00Z\\",\\n    \\"2023-01-19T20:00:00Z\\",\\n    \\"2023-01-19T21:00:00Z\\",\\n    \\"2023-01-19T22:00:00Z\\",\\n    \\"2023-01-19T23:00:00Z\\",\\n    \\"2023-01-20T00:00:00Z\\",\\n    \\"2023-01-20T01:00:00Z\\",\\n    \\"2023-01-20T02:00:00Z\\",\\n    \\"2023-01-20T03:00:00Z\\",\\n    \\"2023-01-20T04:00:00Z\\",\\n    \\"2023-01-20T05:00:00Z\\",\\n    \\"2023-01-20T06:00:00Z\\",\\n    \\"2023-01-20T07:00:00Z\\",\\n    \\"2023-01-20T08:00:00Z\\",\\n    \\"2023-01-20T09:00:00Z\\",\\n    \\"2023-01-20T10:00:00Z\\",\\n    \\"2023-01-20T11:00:00Z\\",\\n    \\"2023-01-20T12:00:00Z\\",\\n    \\"2023-01-20T13:00:00Z\\",\\n    \\"2023-01-20T14:00:00Z\\",\\n    \\"2023-01-20T15:00:00Z\\",\\n    \\"2023-01-20T16:00:00Z\\",\\n    \\"2023-01-20T17:00:00Z\\",\\n    \\"2023-01-20T18:00:00Z\\",\\n    \\"2023-01-20T19:00:00Z\\",\\n    \\"2023-01-20T20:00:00Z\\",\\n    \\"2023-01-20T21:00:00Z\\",\\n    \\"2023-01-20T22:00:00Z\\",\\n    \\"2023-01-20T23:00:00Z\\",\\n    \\"2023-01-21T00:00:00Z\\",\\n    \\"2023-01-21T01:00:00Z\\",\\n    \\"2023-01-21T02:00:00Z\\",\\n    \\"2023-01-21T03:00:00Z\\",\\n    \\"2023-01-21T04:00:00Z\\",\\n    \\"2023-01-21T05:00:00Z\\",\\n    \\"2023-01-21T06:00:00Z\\",\\n    \\"2023-01-21T07:00:00Z\\",\\n    \\"2023-01-21T08:00:00Z\\",\\n    \\"2023-01-21T09:00:00Z\\",\\n    \\"2023-01-21T10:00:00Z\\",\\n    \\"2023-01-21T11:00:00Z\\",\\n    \\"2023-01-21T12:00:00Z\\",\\n    \\"2023-01-21T13:00:00Z\\",\\n    \\"2023-01-21T14:00:00Z\\",\\n    \\"2023-01-21T15:00:00Z\\",\\n    \\"2023-01-21T16:00:00Z\\",\\n    \\"2023-01-21T17:00:00Z\\",\\n    \\"2023-01-21T18:00:00Z\\",\\n    \\"2023-01-21T19:00:00Z\\",\\n    \\"2023-01-21T20:00:00Z\\",\\n    \\"2023-01-21T21:00:00Z\\",\\n    \\"2023-01-21T22:00:00Z\\",\\n    \\"2023-01-21T23:00:00Z\\",\\n    \\"2023-01-22T00:00:00Z\\",\\n    \\"2023-01-22T01:00:00Z\\",\\n    \\"2023-01-22T02:00:00Z\\",\\n    \\"2023-01-22T03:00:00Z\\",\\n    \\"2023-01-22T04:00:00Z\\",\\n    \\"2023-01-22T05:00:00Z\\",\\n    \\"2023-01-22T06:00:00Z\\",\\n    \\"2023-01-22T07:00:00Z\\",\\n    \\"2023-01-22T08:00:00Z\\",\\n    \\"2023-01-22T09:00:00Z\\",\\n    \\"2023-01-22T10:00:00Z\\",\\n    \\"2023-01-22T11:00:00Z\\",\\n    \\"2023-01-22T12:00:00Z\\",\\n    \\"2023-01-22T13:00:00Z\\",\\n    \\"2023-01-22T14:00:00Z\\",\\n    \\"2023-01-22T15:00:00Z\\",\\n    \\"2023-01-22T16:00:00Z\\",\\n    \\"2023-01-22T17:00:00Z\\",\\n    \\"2023-01-22T18:00:00Z\\",\\n    \\"2023-01-22T19:00:00Z\\",\\n    \\"2023-01-22T20:00:00Z\\",\\n    \\"2023-01-22T21:00:00Z\\",\\n    \\"2023-01-22T22:00:00Z\\",\\n    \\"2023-01-22T23:00:00Z\\",\\n    \\"2023-01-23T00:00:00Z\\",\\n    \\"2023-01-23T01:00:00Z\\",\\n    \\"2023-01-23T02:00:00Z\\",\\n    \\"2023-01-23T03:00:00Z\\",\\n    \\"2023-01-23T04:00:00Z\\",\\n    \\"2023-01-23T05:00:00Z\\",\\n    \\"2023-01-23T06:00:00Z\\",\\n    \\"2023-01-23T07:00:00Z\\",\\n    \\"2023-01-23T08:00:00Z\\",\\n    \\"2023-01-23T09:00:00Z\\",\\n    \\"2023-01-23T10:00:00Z\\",\\n    \\"2023-01-23T11:00:00Z\\",\\n    \\"2023-01-23T12:00:00Z\\",\\n    \\"2023-01-23T13:00:00Z\\",\\n    \\"2023-01-23T14:00:00Z\\",\\n    \\"2023-01-23T15:00:00Z\\",\\n    \\"2023-01-23T16:00:00Z\\",\\n    \\"2023-01-23T17:00:00Z\\",\\n    \\"2023-01-23T18:00:00Z\\",\\n    \\"2023-01-23T19:00:00Z\\",\\n    \\"2023-01-23T20:00:00Z\\",\\n    \\"2023-01-23T21:00:00Z\\",\\n    \\"2023-01-23T22:00:00Z\\",\\n    \\"2023-01-23T23:00:00Z\\",\\n    \\"2023-01-24T00:00:00Z\\",\\n    \\"2023-01-24T01:00:00Z\\",\\n    \\"2023-01-24T02:00:00Z\\",\\n    \\"2023-01-24T03:00:00Z\\",\\n    \\"2023-01-24T04:00:00Z\\",\\n    \\"2023-01-24T05:00:00Z\\",\\n    \\"2023-01-24T06:00:00Z\\",\\n    \\"2023-01-24T07:00:00Z\\",\\n    \\"2023-01-24T08:00:00Z\\",\\n    \\"2023-01-24T09:00:00Z\\",\\n    \\"2023-01-24T10:00:00Z\\",\\n    \\"2023-01-24T11:00:00Z\\",\\n    \\"2023-01-24T12:00:00Z\\",\\n    \\"2023-01-24T13:00:00Z\\",\\n    \\"2023-01-24T14:00:00Z\\"\\n  ],\\n  \\"cost\\": [\\n    0.377547682,\\n    0.3775476016,\\n    0.3775475871,\\n    0.3775475824,\\n    0.3775478477,\\n    0.3775496823,\\n    0.3775476033,\\n    0.3786389384,\\n    0.3786418627,\\n    0.377548312,\\n    0.3786388453,\\n    0.3775476297,\\n    0.3775495034,\\n    0.3775486058,\\n    0.3775476424,\\n    0.3775501741,\\n    0.3775477045,\\n    0.3775482287,\\n    0.3775814747,\\n    0.3775752755,\\n    0.3775476054,\\n    0.3775481495,\\n    0.3775486261,\\n    0.3775489892,\\n    0.377548004,\\n    0.3775476405,\\n    0.3775476197,\\n    0.2491780436,\\n    0.0511486882,\\n    0.0009933099,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0,\\n    0.0\\n  ],\\n  \\"stats\\": {\\n    \\"avg\\": 0.031245406130059522,\\n    \\"max\\": 0.3786418627,\\n    \\"std\\": 0.10348915212516253\\n  }\\n}"	2023-01-24 09:30:00.046011-05	HOURLY	b5edeee0-8425-446c-a73f-47e5a20ef3ce
\.


--
-- Data for Name: users_orgnumnode; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.users_orgnumnode (id, desired_num_nodes, expiration, has_active_ps_cmd, org_id, user_id, show_expire_tm) FROM stdin;
\.


--
-- Data for Name: users_pscmdqueueresult; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.users_pscmdqueueresult (id, ps_cmd_output, error, creation_date, ps_cmd_summary_label, org_id, task_result_id, expiration, show_expire_tm) FROM stdin;
b73b5924-83c2-4076-8351-090213c2e98b		FAILED to acquire lock	2023-01-30 16:54:19.007256-05	2023-01-30 21:54:19 UTC --- Refresh unit-test-org ceugarteblair	b5edeee0-8425-446c-a73f-47e5a20ef3ce	538	2023-01-30 16:54:18.997261-05	t
5f2c1efa-8902-444d-b247-c6a3ace9d84b		FAILED to acquire lock	2023-01-30 17:04:01.150301-05	2023-01-30 22:04:01 UTC --- Refresh unit-test-org ceugarteblair	b5edeee0-8425-446c-a73f-47e5a20ef3ce	539	2023-01-30 17:04:01.141403-05	t
e868d611-b235-41eb-8c75-51c76f235bb2		FAILED to acquire lock	2023-01-30 17:16:51.912254-05	2023-01-30 22:16:51 UTC --- Refresh unit-test-org ceugarteblair	b5edeee0-8425-446c-a73f-47e5a20ef3ce	542	2023-01-30 17:16:51.903409-05	t
c68aa7aa-01e3-433e-b84e-420db99bb1b6		FAILED to acquire lock	2023-01-30 16:05:32.17463-05	2023-01-30 21:05:32 UTC --- Refresh unit-test-org ceugarteblair	b5edeee0-8425-446c-a73f-47e5a20ef3ce	533	2023-01-30 16:05:32.164917-05	t
60e592e3-0968-41ee-a069-0036b4e4a1cb		FAILED to acquire lock	2023-01-30 16:31:10.125173-05	2023-01-30 21:31:10 UTC --- Refresh unit-test-org ceugarteblair	b5edeee0-8425-446c-a73f-47e5a20ef3ce	537	2023-01-30 16:31:10.116383-05	t
0937513a-477c-4f1d-90d3-474a73487177	\n**************** cmd submitted: ['rm', '-rf', '/ps_server/unit-test-org/terraform'] at 2023-01-31 12:30:29 UTC\n\n**************** cmd submitted: ['mkdir', '-p', '/ps_server/unit-test-org/terraform'] at 2023-01-31 12:30:30 UTC\n\n**************** cmd submitted: ['terraform', '-chdir=/ps_server/unit-test-org/terraform', 'init'] at 2023-01-31 12:30:37 UTC\n\n<span style="font-weight: bold">Initializing the backend...</span>\n<span style="color: #00aa00">\nSuccessfully configured the backend "s3"! Terraform will automatically\nuse this backend unless the backend configuration changes.</span>\n\n<span style="font-weight: bold">Initializing provider plugins...</span>\n- Reusing previous version of hashicorp/aws from the dependency lock file\n- Installing hashicorp/aws v4.34.0...\n- Installed hashicorp/aws v4.34.0 (signed by HashiCorp)\n\n<span style="font-weight: bold"></span><span style="font-weight: bold; color: #00aa00">Terraform has been successfully initialized!</span><span style="color: #00aa00"></span>\n<span style="color: #00aa00">\nYou may now begin working with Terraform. Try running "terraform plan" to see\nany changes that are required for your infrastructure. All Terraform commands\nshould now work.\n\nIf you ever set or change modules or backend configuration for Terraform,\nrerun this command to reinitialize your working directory. If you forget, other\ncommands will detect it and remind you to do so if necessary.</span>\n\n**************** cmd submitted: ['terraform', '-chdir=/ps_server/unit-test-org/terraform', 'validate'] at 2023-01-31 12:30:46 UTC\n<span style="color: #aa5500">╷</span>\n<span style="color: #aa5500">│</span> <span style="font-weight: bold"></span><span style="font-weight: bold; color: #aa5500">Warning: </span><span style="font-weight: bold">Argument is deprecated</span>\n<span style="color: #aa5500">│</span> \n<span style="color: #aa5500">│</span>   with aws_s3_bucket_object.docker-compose-config,\n<span style="color: #aa5500">│</span>   on config-files.tf line 4, in resource "aws_s3_bucket_object" "docker-compose-config":\n<span style="color: #aa5500">│</span>    4:   bucket = <span style="text-decoration: underline">"sliderule"</span>\n<span style="color: #aa5500">│</span> \n<span style="color: #aa5500">│</span> Use the aws_s3_object resource instead\n<span style="color: #aa5500">│</span> \n<span style="color: #aa5500">│</span> (and 3 more similar warnings elsewhere)\n<span style="color: #aa5500">╵</span>\n<span style="color: #00aa00"></span><span style="font-weight: bold; color: #00aa00">Success!</span> The configuration is valid, but there were some\nvalidation warnings as shown above.\n\n\n**************** cmd submitted: ['terraform', '-chdir=/ps_server/unit-test-org/terraform', 'workspace', 'select', 'testsliderule.org-unit-test-org'] at 2023-01-31 12:30:49 UTC\n<span style="color: #00aa00">Switched to workspace "testsliderule.org-unit-test-org".</span>\n\n**************** cmd submitted: ['terraform', '-chdir=/ps_server/unit-test-org/terraform', 'refresh', '-var', 'domain=testsliderule.org'] at 2023-01-31 12:30:50 UTC\n<span style="font-weight: bold">data.aws_secretsmanager_secret_version.creds: Reading...</span>\n<span style="font-weight: bold">data.aws_acm_certificate.sliderule_cluster_cert: Reading...</span>\n<span style="font-weight: bold">data.aws_ami.sliderule_cluster_ami: Reading...</span>\n<span style="font-weight: bold">data.aws_route53_zone.selected: Reading...</span>\n<span style="font-weight: bold">data.aws_ami.sliderule_cluster_ami: Read complete after 1s [id=ami-04b964f30f3ed3e82]</span>\n<span style="font-weight: bold">data.aws_secretsmanager_secret_version.creds: Read complete after 1s [id=prod/provsys/secrets|AWSCURRENT]</span>\n<span style="font-weight: bold">data.aws_acm_certificate.sliderule_cluster_cert: Read complete after 1s [id=arn:aws:acm:us-west-2:742127912612:certificate/b7b5d7f2-a862-4243-9548-223587c36877]</span>\n<span style="font-weight: bold">data.aws_route53_zone.selected: Read complete after 4s [id=Z1039660300QJ4GJRI5NT]</span>\n<span style="color: #aa5500">╷</span>\n<span style="color: #aa5500">│</span> <span style="font-weight: bold"></span><span style="font-weight: bold; color: #aa5500">Warning: </span><span style="font-weight: bold">Empty or non-existent state</span>\n<span style="color: #aa5500">│</span> \n<span style="color: #aa5500">│</span> There are currently no remote objects tracked in the state, so there is\n<span style="color: #aa5500">│</span> nothing to refresh.\n<span style="color: #aa5500">╵</span>\n<span style="color: #aa5500">╷</span>\n<span style="color: #aa5500">│</span> <span style="font-weight: bold"></span><span style="font-weight: bold; color: #aa5500">Warning: </span><span style="font-weight: bold">Argument is deprecated</span>\n<span style="color: #aa5500">│</span> \n<span style="color: #aa5500">│</span>   with aws_s3_bucket_object.docker-compose-config,\n<span style="color: #aa5500">│</span>   on config-files.tf line 4, in resource "aws_s3_bucket_object" "docker-compose-config":\n<span style="color: #aa5500">│</span>    4:   bucket = <span style="text-decoration: underline">"sliderule"</span>\n<span style="color: #aa5500">│</span> \n<span style="color: #aa5500">│</span> Use the aws_s3_object resource instead\n<span style="color: #aa5500">│</span> \n<span style="color: #aa5500">│</span> (and 13 more similar warnings elsewhere)\n<span style="color: #aa5500">╵</span>\n\n**************** cmd submitted: ['terraform', '-chdir=/ps_server/unit-test-org/terraform', 'state', 'list'] at 2023-01-31 12:30:59 UTC\ndata.aws_acm_certificate.sliderule_cluster_cert\ndata.aws_ami.sliderule_cluster_ami\ndata.aws_route53_zone.selected\ndata.aws_secretsmanager_secret_version.creds\n\n**************** cmd submitted: ['terraform', '-chdir=/ps_server/unit-test-org/terraform', 'output'] at 2023-01-31 12:31:01 UTC\n<span style="color: #aa5500">╷</span>\n<span style="color: #aa5500">│</span> <span style="font-weight: bold"></span><span style="font-weight: bold; color: #aa5500">Warning: </span><span style="font-weight: bold">No outputs found</span>\n<span style="color: #aa5500">│</span> \n<span style="color: #aa5500">│</span> The state file either has no outputs defined, or all the defined outputs\n<span style="color: #aa5500">│</span> are empty. Please define an output in your configuration with the `output`\n<span style="color: #aa5500">│</span> keyword and run `terraform refresh` for it to become available. If you are\n<span style="color: #aa5500">│</span> using interpolation, please verify the interpolated value is not empty. You\n<span style="color: #aa5500">│</span> can use the `terraform console` command to assist.\n<span style="color: #aa5500">╵</span>\n**************** unit-test-org Refresh Completed 2023-01-31 12:31:02 UTC elasped:datetime.timedelta(seconds=33, microseconds=43777)		2023-01-31 07:30:29.645139-05	2023-01-31 12:30:29 UTC --- Refresh unit-test-org  ceugarteblair	b5edeee0-8425-446c-a73f-47e5a20ef3ce	576	2023-01-31 07:30:29.641208-05	t
1e7037d9-6256-4996-adc0-c9a0034e4cfd	\n**************** cmd submitted: ['rm', '-rf', '/ps_server/unit-test-org/terraform'] at 2023-01-31 13:27:20 UTC\n\n**************** cmd submitted: ['mkdir', '-p', '/ps_server/unit-test-org/terraform'] at 2023-01-31 13:27:21 UTC\n\n**************** cmd submitted: ['terraform', '-chdir=/ps_server/unit-test-org/terraform', 'init'] at 2023-01-31 13:27:28 UTC\n\n<span style="font-weight: bold">Initializing the backend...</span>\n<span style="color: #00aa00">\nSuccessfully configured the backend "s3"! Terraform will automatically\nuse this backend unless the backend configuration changes.</span>\n\n<span style="font-weight: bold">Initializing provider plugins...</span>\n- Reusing previous version of hashicorp/aws from the dependency lock file\n- Installing hashicorp/aws v4.34.0...\n- Installed hashicorp/aws v4.34.0 (signed by HashiCorp)\n\n<span style="font-weight: bold"></span><span style="font-weight: bold; color: #00aa00">Terraform has been successfully initialized!</span><span style="color: #00aa00"></span>\n<span style="color: #00aa00">\nYou may now begin working with Terraform. Try running "terraform plan" to see\nany changes that are required for your infrastructure. All Terraform commands\nshould now work.\n\nIf you ever set or change modules or backend configuration for Terraform,\nrerun this command to reinitialize your working directory. If you forget, other\ncommands will detect it and remind you to do so if necessary.</span>\n\n**************** cmd submitted: ['terraform', '-chdir=/ps_server/unit-test-org/terraform', 'validate'] at 2023-01-31 13:27:38 UTC\n<span style="color: #aa5500">╷</span>\n<span style="color: #aa5500">│</span> <span style="font-weight: bold"></span><span style="font-weight: bold; color: #aa5500">Warning: </span><span style="font-weight: bold">Argument is deprecated</span>\n<span style="color: #aa5500">│</span> \n<span style="color: #aa5500">│</span>   with aws_s3_bucket_object.docker-compose-config,\n<span style="color: #aa5500">│</span>   on config-files.tf line 4, in resource "aws_s3_bucket_object" "docker-compose-config":\n<span style="color: #aa5500">│</span>    4:   bucket = <span style="text-decoration: underline">"sliderule"</span>\n<span style="color: #aa5500">│</span> \n<span style="color: #aa5500">│</span> Use the aws_s3_object resource instead\n<span style="color: #aa5500">│</span> \n<span style="color: #aa5500">│</span> (and 3 more similar warnings elsewhere)\n<span style="color: #aa5500">╵</span>\n<span style="color: #00aa00"></span><span style="font-weight: bold; color: #00aa00">Success!</span> The configuration is valid, but there were some\nvalidation warnings as shown above.\n\n\n**************** cmd submitted: ['terraform', '-chdir=/ps_server/unit-test-org/terraform', 'workspace', 'select', 'testsliderule.org-unit-test-org'] at 2023-01-31 13:27:41 UTC\n<span style="color: #00aa00">Switched to workspace "testsliderule.org-unit-test-org".</span>\n\n**************** cmd submitted: ['terraform', '-chdir=/ps_server/unit-test-org/terraform', 'refresh', '-var', 'domain=testsliderule.org'] at 2023-01-31 13:27:43 UTC\n<span style="font-weight: bold">data.aws_acm_certificate.sliderule_cluster_cert: Reading...</span>\n<span style="font-weight: bold">data.aws_ami.sliderule_cluster_ami: Reading...</span>\n<span style="font-weight: bold">data.aws_route53_zone.selected: Reading...</span>\n<span style="font-weight: bold">data.aws_secretsmanager_secret_version.creds: Reading...</span>\n<span style="font-weight: bold">data.aws_ami.sliderule_cluster_ami: Read complete after 0s [id=ami-04b964f30f3ed3e82]</span>\n<span style="font-weight: bold">data.aws_route53_zone.selected: Read complete after 0s [id=Z1039660300QJ4GJRI5NT]</span>\n<span style="font-weight: bold">data.aws_acm_certificate.sliderule_cluster_cert: Read complete after 1s [id=arn:aws:acm:us-west-2:742127912612:certificate/b7b5d7f2-a862-4243-9548-223587c36877]</span>\n<span style="font-weight: bold">data.aws_secretsmanager_secret_version.creds: Read complete after 3s [id=prod/provsys/secrets|AWSCURRENT]</span>\n<span style="color: #aa5500">╷</span>\n<span style="color: #aa5500">│</span> <span style="font-weight: bold"></span><span style="font-weight: bold; color: #aa5500">Warning: </span><span style="font-weight: bold">Empty or non-existent state</span>\n<span style="color: #aa5500">│</span> \n<span style="color: #aa5500">│</span> There are currently no remote objects tracked in the state, so there is\n<span style="color: #aa5500">│</span> nothing to refresh.\n<span style="color: #aa5500">╵</span>\n<span style="color: #aa5500">╷</span>\n<span style="color: #aa5500">│</span> <span style="font-weight: bold"></span><span style="font-weight: bold; color: #aa5500">Warning: </span><span style="font-weight: bold">Argument is deprecated</span>\n<span style="color: #aa5500">│</span> \n<span style="color: #aa5500">│</span>   with aws_s3_bucket_object.docker-compose-config,\n<span style="color: #aa5500">│</span>   on config-files.tf line 4, in resource "aws_s3_bucket_object" "docker-compose-config":\n<span style="color: #aa5500">│</span>    4:   bucket = <span style="text-decoration: underline">"sliderule"</span>\n<span style="color: #aa5500">│</span> \n<span style="color: #aa5500">│</span> Use the aws_s3_object resource instead\n<span style="color: #aa5500">│</span> \n<span style="color: #aa5500">│</span> (and 13 more similar warnings elsewhere)\n<span style="color: #aa5500">╵</span>\n\n**************** cmd submitted: ['terraform', '-chdir=/ps_server/unit-test-org/terraform', 'state', 'list'] at 2023-01-31 13:27:51 UTC\ndata.aws_acm_certificate.sliderule_cluster_cert\ndata.aws_ami.sliderule_cluster_ami\ndata.aws_route53_zone.selected\ndata.aws_secretsmanager_secret_version.creds\n\n**************** cmd submitted: ['terraform', '-chdir=/ps_server/unit-test-org/terraform', 'output'] at 2023-01-31 13:27:52 UTC\n<span style="color: #aa5500">╷</span>\n<span style="color: #aa5500">│</span> <span style="font-weight: bold"></span><span style="font-weight: bold; color: #aa5500">Warning: </span><span style="font-weight: bold">No outputs found</span>\n<span style="color: #aa5500">│</span> \n<span style="color: #aa5500">│</span> The state file either has no outputs defined, or all the defined outputs\n<span style="color: #aa5500">│</span> are empty. Please define an output in your configuration with the `output`\n<span style="color: #aa5500">│</span> keyword and run `terraform refresh` for it to become available. If you are\n<span style="color: #aa5500">│</span> using interpolation, please verify the interpolated value is not empty. You\n<span style="color: #aa5500">│</span> can use the `terraform console` command to assist.\n<span style="color: #aa5500">╵</span>\n**************** unit-test-org Refresh Completed 2023-01-31 13:27:53 UTC elasped:datetime.timedelta(seconds=33, microseconds=141475)		2023-01-31 08:27:20.573102-05	2023-01-31 13:27:20 UTC --- Refresh unit-test-org  ceugarteblair	b5edeee0-8425-446c-a73f-47e5a20ef3ce	578	2023-01-31 08:27:20.567556-05	t
208cf07e-4c37-453f-bbff-63e696f875a9	\n**************** cmd submitted: ['rm', '-rf', '/ps_server/unit-test-org/terraform'] at 2023-01-31 15:53:30 UTC\n\n**************** cmd submitted: ['mkdir', '-p', '/ps_server/unit-test-org/terraform'] at 2023-01-31 15:53:31 UTC\n\n**************** cmd submitted: ['terraform', '-chdir=/ps_server/unit-test-org/terraform', 'init'] at 2023-01-31 15:53:38 UTC\n\n<span style="font-weight: bold">Initializing the backend...</span>\n<span style="color: #00aa00">\nSuccessfully configured the backend "s3"! Terraform will automatically\nuse this backend unless the backend configuration changes.</span>\n\n<span style="font-weight: bold">Initializing provider plugins...</span>\n- Reusing previous version of hashicorp/aws from the dependency lock file\n- Installing hashicorp/aws v4.34.0...\n- Installed hashicorp/aws v4.34.0 (signed by HashiCorp)\n\n<span style="font-weight: bold"></span><span style="font-weight: bold; color: #00aa00">Terraform has been successfully initialized!</span><span style="color: #00aa00"></span>\n<span style="color: #00aa00">\nYou may now begin working with Terraform. Try running "terraform plan" to see\nany changes that are required for your infrastructure. All Terraform commands\nshould now work.\n\nIf you ever set or change modules or backend configuration for Terraform,\nrerun this command to reinitialize your working directory. If you forget, other\ncommands will detect it and remind you to do so if necessary.</span>\n\n**************** cmd submitted: ['terraform', '-chdir=/ps_server/unit-test-org/terraform', 'validate'] at 2023-01-31 15:53:47 UTC\n<span style="color: #aa5500">╷</span>\n<span style="color: #aa5500">│</span> <span style="font-weight: bold"></span><span style="font-weight: bold; color: #aa5500">Warning: </span><span style="font-weight: bold">Argument is deprecated</span>\n<span style="color: #aa5500">│</span> \n<span style="color: #aa5500">│</span>   with aws_s3_bucket_object.docker-compose-config,\n<span style="color: #aa5500">│</span>   on config-files.tf line 4, in resource "aws_s3_bucket_object" "docker-compose-config":\n<span style="color: #aa5500">│</span>    4:   bucket = <span style="text-decoration: underline">"sliderule"</span>\n<span style="color: #aa5500">│</span> \n<span style="color: #aa5500">│</span> Use the aws_s3_object resource instead\n<span style="color: #aa5500">│</span> \n<span style="color: #aa5500">│</span> (and 3 more similar warnings elsewhere)\n<span style="color: #aa5500">╵</span>\n<span style="color: #00aa00"></span><span style="font-weight: bold; color: #00aa00">Success!</span> The configuration is valid, but there were some\nvalidation warnings as shown above.\n\n\n**************** cmd submitted: ['terraform', '-chdir=/ps_server/unit-test-org/terraform', 'workspace', 'select', 'testsliderule.org-unit-test-org'] at 2023-01-31 15:53:51 UTC\n<span style="color: #00aa00">Switched to workspace "testsliderule.org-unit-test-org".</span>\n\n**************** cmd submitted: ['terraform', '-chdir=/ps_server/unit-test-org/terraform', 'refresh', '-var', 'domain=testsliderule.org'] at 2023-01-31 15:53:53 UTC\n<span style="font-weight: bold">data.aws_secretsmanager_secret_version.creds: Reading...</span>\n<span style="font-weight: bold">data.aws_ami.sliderule_cluster_ami: Reading...</span>\n<span style="font-weight: bold">data.aws_route53_zone.selected: Reading...</span>\n<span style="font-weight: bold">data.aws_acm_certificate.sliderule_cluster_cert: Reading...</span>\n<span style="font-weight: bold">data.aws_ami.sliderule_cluster_ami: Read complete after 0s [id=ami-04b964f30f3ed3e82]</span>\n<span style="font-weight: bold">data.aws_secretsmanager_secret_version.creds: Read complete after 1s [id=prod/provsys/secrets|AWSCURRENT]</span>\n<span style="font-weight: bold">data.aws_route53_zone.selected: Read complete after 1s [id=Z1039660300QJ4GJRI5NT]</span>\n<span style="font-weight: bold">data.aws_acm_certificate.sliderule_cluster_cert: Read complete after 4s [id=arn:aws:acm:us-west-2:742127912612:certificate/b7b5d7f2-a862-4243-9548-223587c36877]</span>\n<span style="color: #aa5500">╷</span>\n<span style="color: #aa5500">│</span> <span style="font-weight: bold"></span><span style="font-weight: bold; color: #aa5500">Warning: </span><span style="font-weight: bold">Empty or non-existent state</span>\n<span style="color: #aa5500">│</span> \n<span style="color: #aa5500">│</span> There are currently no remote objects tracked in the state, so there is\n<span style="color: #aa5500">│</span> nothing to refresh.\n<span style="color: #aa5500">╵</span>\n<span style="color: #aa5500">╷</span>\n<span style="color: #aa5500">│</span> <span style="font-weight: bold"></span><span style="font-weight: bold; color: #aa5500">Warning: </span><span style="font-weight: bold">Argument is deprecated</span>\n<span style="color: #aa5500">│</span> \n<span style="color: #aa5500">│</span>   with aws_s3_bucket_object.docker-compose-config,\n<span style="color: #aa5500">│</span>   on config-files.tf line 4, in resource "aws_s3_bucket_object" "docker-compose-config":\n<span style="color: #aa5500">│</span>    4:   bucket = <span style="text-decoration: underline">"sliderule"</span>\n<span style="color: #aa5500">│</span> \n<span style="color: #aa5500">│</span> Use the aws_s3_object resource instead\n<span style="color: #aa5500">│</span> \n<span style="color: #aa5500">│</span> (and 13 more similar warnings elsewhere)\n<span style="color: #aa5500">╵</span>\n\n**************** cmd submitted: ['terraform', '-chdir=/ps_server/unit-test-org/terraform', 'state', 'list'] at 2023-01-31 15:54:02 UTC\ndata.aws_acm_certificate.sliderule_cluster_cert\ndata.aws_ami.sliderule_cluster_ami\ndata.aws_route53_zone.selected\ndata.aws_secretsmanager_secret_version.creds\n\n**************** cmd submitted: ['terraform', '-chdir=/ps_server/unit-test-org/terraform', 'output'] at 2023-01-31 15:54:04 UTC\n<span style="color: #aa5500">╷</span>\n<span style="color: #aa5500">│</span> <span style="font-weight: bold"></span><span style="font-weight: bold; color: #aa5500">Warning: </span><span style="font-weight: bold">No outputs found</span>\n<span style="color: #aa5500">│</span> \n<span style="color: #aa5500">│</span> The state file either has no outputs defined, or all the defined outputs\n<span style="color: #aa5500">│</span> are empty. Please define an output in your configuration with the `output`\n<span style="color: #aa5500">│</span> keyword and run `terraform refresh` for it to become available. If you are\n<span style="color: #aa5500">│</span> using interpolation, please verify the interpolated value is not empty. You\n<span style="color: #aa5500">│</span> can use the `terraform console` command to assist.\n<span style="color: #aa5500">╵</span>\n**************** unit-test-org Refresh Completed 2023-01-31 15:54:05 UTC elasped:datetime.timedelta(seconds=34, microseconds=686487)		2023-01-31 10:53:30.559124-05	2023-01-31 15:53:30 UTC --- Refresh unit-test-org  ceugarteblair	b5edeee0-8425-446c-a73f-47e5a20ef3ce	582	2023-01-31 10:53:30.555056-05	t
\.


--
-- Data for Name: users_user_groups; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.users_user_groups (id, user_id, group_id) FROM stdin;
1	3	1
\.


--
-- Data for Name: users_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.users_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.


--
-- Name: account_emailaddress_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ps_admin
--

SELECT pg_catalog.setval('public.account_emailaddress_id_seq', 4, true);


--
-- Name: account_emailconfirmation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ps_admin
--

SELECT pg_catalog.setval('public.account_emailconfirmation_id_seq', 1, false);


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ps_admin
--

SELECT pg_catalog.setval('public.auth_group_id_seq', 1, true);


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ps_admin
--

SELECT pg_catalog.setval('public.auth_group_permissions_id_seq', 72, true);


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ps_admin
--

SELECT pg_catalog.setval('public.auth_permission_id_seq', 124, true);


--
-- Name: captcha_captchastore_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ps_admin
--

SELECT pg_catalog.setval('public.captcha_captchastore_id_seq', 1, true);


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ps_admin
--

SELECT pg_catalog.setval('public.django_admin_log_id_seq', 20, true);


--
-- Name: django_celery_beat_clockedschedule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ps_admin
--

SELECT pg_catalog.setval('public.django_celery_beat_clockedschedule_id_seq', 2, true);


--
-- Name: django_celery_beat_crontabschedule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ps_admin
--

SELECT pg_catalog.setval('public.django_celery_beat_crontabschedule_id_seq', 4, true);


--
-- Name: django_celery_beat_intervalschedule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ps_admin
--

SELECT pg_catalog.setval('public.django_celery_beat_intervalschedule_id_seq', 1, false);


--
-- Name: django_celery_beat_periodictask_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ps_admin
--

SELECT pg_catalog.setval('public.django_celery_beat_periodictask_id_seq', 6, true);


--
-- Name: django_celery_beat_solarschedule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ps_admin
--

SELECT pg_catalog.setval('public.django_celery_beat_solarschedule_id_seq', 1, false);


--
-- Name: django_celery_results_chordcounter_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ps_admin
--

SELECT pg_catalog.setval('public.django_celery_results_chordcounter_id_seq', 1, false);


--
-- Name: django_celery_results_groupresult_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ps_admin
--

SELECT pg_catalog.setval('public.django_celery_results_groupresult_id_seq', 1, false);


--
-- Name: django_celery_results_taskresult_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ps_admin
--

SELECT pg_catalog.setval('public.django_celery_results_taskresult_id_seq', 666, true);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ps_admin
--

SELECT pg_catalog.setval('public.django_content_type_id_seq', 31, true);


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ps_admin
--

SELECT pg_catalog.setval('public.django_migrations_id_seq', 75, true);


--
-- Name: django_site_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ps_admin
--

SELECT pg_catalog.setval('public.django_site_id_seq', 2, true);


--
-- Name: socialaccount_socialaccount_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ps_admin
--

SELECT pg_catalog.setval('public.socialaccount_socialaccount_id_seq', 3, true);


--
-- Name: socialaccount_socialapp_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ps_admin
--

SELECT pg_catalog.setval('public.socialaccount_socialapp_id_seq', 2, true);


--
-- Name: socialaccount_socialapp_sites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ps_admin
--

SELECT pg_catalog.setval('public.socialaccount_socialapp_sites_id_seq', 3, true);


--
-- Name: socialaccount_socialtoken_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ps_admin
--

SELECT pg_catalog.setval('public.socialaccount_socialtoken_id_seq', 1, false);


--
-- Name: token_blacklist_blacklistedtoken_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ps_admin
--

SELECT pg_catalog.setval('public.token_blacklist_blacklistedtoken_id_seq', 1, false);


--
-- Name: token_blacklist_outstandingtoken_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ps_admin
--

SELECT pg_catalog.setval('public.token_blacklist_outstandingtoken_id_seq', 1, false);


--
-- Name: users_orgcost_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ps_admin
--

SELECT pg_catalog.setval('public.users_orgcost_id_seq', 3, true);


--
-- Name: users_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ps_admin
--

SELECT pg_catalog.setval('public.users_user_groups_id_seq', 1, true);


--
-- Name: users_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ps_admin
--

SELECT pg_catalog.setval('public.users_user_id_seq', 4, true);


--
-- Name: users_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ps_admin
--

SELECT pg_catalog.setval('public.users_user_user_permissions_id_seq', 1, false);


--
-- PostgreSQL database dump complete
--

