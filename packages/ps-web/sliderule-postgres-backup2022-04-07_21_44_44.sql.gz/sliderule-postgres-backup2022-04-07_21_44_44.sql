--
-- PostgreSQL database dump
--

-- Dumped from database version 12.10 (Debian 12.10-1.pgdg110+1)
-- Dumped by pg_dump version 12.10 (Debian 12.10-1.pgdg110+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: ps_admin
--

CREATE TABLE public.auth_group (
    id integer NOT NULL,
    name character varying(150) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO ps_admin;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: ps_admin
--

CREATE SEQUENCE public.auth_group_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_id_seq OWNER TO ps_admin;

--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ps_admin
--

ALTER SEQUENCE public.auth_group_id_seq OWNED BY public.auth_group.id;


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: ps_admin
--

CREATE TABLE public.auth_group_permissions (
    id bigint NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO ps_admin;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: ps_admin
--

CREATE SEQUENCE public.auth_group_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_permissions_id_seq OWNER TO ps_admin;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ps_admin
--

ALTER SEQUENCE public.auth_group_permissions_id_seq OWNED BY public.auth_group_permissions.id;


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: ps_admin
--

CREATE TABLE public.auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO ps_admin;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: ps_admin
--

CREATE SEQUENCE public.auth_permission_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_permission_id_seq OWNER TO ps_admin;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ps_admin
--

ALTER SEQUENCE public.auth_permission_id_seq OWNED BY public.auth_permission.id;


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: ps_admin
--

CREATE TABLE public.django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id bigint NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO ps_admin;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: ps_admin
--

CREATE SEQUENCE public.django_admin_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_admin_log_id_seq OWNER TO ps_admin;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ps_admin
--

ALTER SEQUENCE public.django_admin_log_id_seq OWNED BY public.django_admin_log.id;


--
-- Name: django_celery_beat_clockedschedule; Type: TABLE; Schema: public; Owner: ps_admin
--

CREATE TABLE public.django_celery_beat_clockedschedule (
    id bigint NOT NULL,
    clocked_time timestamp with time zone NOT NULL
);


ALTER TABLE public.django_celery_beat_clockedschedule OWNER TO ps_admin;

--
-- Name: django_celery_beat_clockedschedule_id_seq; Type: SEQUENCE; Schema: public; Owner: ps_admin
--

CREATE SEQUENCE public.django_celery_beat_clockedschedule_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_celery_beat_clockedschedule_id_seq OWNER TO ps_admin;

--
-- Name: django_celery_beat_clockedschedule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ps_admin
--

ALTER SEQUENCE public.django_celery_beat_clockedschedule_id_seq OWNED BY public.django_celery_beat_clockedschedule.id;


--
-- Name: django_celery_beat_crontabschedule; Type: TABLE; Schema: public; Owner: ps_admin
--

CREATE TABLE public.django_celery_beat_crontabschedule (
    id bigint NOT NULL,
    minute character varying(240) NOT NULL,
    hour character varying(96) NOT NULL,
    day_of_week character varying(64) NOT NULL,
    day_of_month character varying(124) NOT NULL,
    month_of_year character varying(64) NOT NULL,
    timezone character varying(63) NOT NULL
);


ALTER TABLE public.django_celery_beat_crontabschedule OWNER TO ps_admin;

--
-- Name: django_celery_beat_crontabschedule_id_seq; Type: SEQUENCE; Schema: public; Owner: ps_admin
--

CREATE SEQUENCE public.django_celery_beat_crontabschedule_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_celery_beat_crontabschedule_id_seq OWNER TO ps_admin;

--
-- Name: django_celery_beat_crontabschedule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ps_admin
--

ALTER SEQUENCE public.django_celery_beat_crontabschedule_id_seq OWNED BY public.django_celery_beat_crontabschedule.id;


--
-- Name: django_celery_beat_intervalschedule; Type: TABLE; Schema: public; Owner: ps_admin
--

CREATE TABLE public.django_celery_beat_intervalschedule (
    id bigint NOT NULL,
    every integer NOT NULL,
    period character varying(24) NOT NULL
);


ALTER TABLE public.django_celery_beat_intervalschedule OWNER TO ps_admin;

--
-- Name: django_celery_beat_intervalschedule_id_seq; Type: SEQUENCE; Schema: public; Owner: ps_admin
--

CREATE SEQUENCE public.django_celery_beat_intervalschedule_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_celery_beat_intervalschedule_id_seq OWNER TO ps_admin;

--
-- Name: django_celery_beat_intervalschedule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ps_admin
--

ALTER SEQUENCE public.django_celery_beat_intervalschedule_id_seq OWNED BY public.django_celery_beat_intervalschedule.id;


--
-- Name: django_celery_beat_periodictask; Type: TABLE; Schema: public; Owner: ps_admin
--

CREATE TABLE public.django_celery_beat_periodictask (
    id bigint NOT NULL,
    name character varying(200) NOT NULL,
    task character varying(200) NOT NULL,
    args text NOT NULL,
    kwargs text NOT NULL,
    queue character varying(200),
    exchange character varying(200),
    routing_key character varying(200),
    expires timestamp with time zone,
    enabled boolean NOT NULL,
    last_run_at timestamp with time zone,
    total_run_count integer NOT NULL,
    date_changed timestamp with time zone NOT NULL,
    description text NOT NULL,
    crontab_id bigint,
    interval_id bigint,
    solar_id bigint,
    one_off boolean NOT NULL,
    start_time timestamp with time zone,
    priority integer,
    headers text NOT NULL,
    clocked_id bigint,
    expire_seconds integer,
    CONSTRAINT django_celery_beat_periodictask_expire_seconds_check CHECK ((expire_seconds >= 0)),
    CONSTRAINT django_celery_beat_periodictask_priority_check CHECK ((priority >= 0)),
    CONSTRAINT django_celery_beat_periodictask_total_run_count_check CHECK ((total_run_count >= 0))
);


ALTER TABLE public.django_celery_beat_periodictask OWNER TO ps_admin;

--
-- Name: django_celery_beat_periodictask_id_seq; Type: SEQUENCE; Schema: public; Owner: ps_admin
--

CREATE SEQUENCE public.django_celery_beat_periodictask_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_celery_beat_periodictask_id_seq OWNER TO ps_admin;

--
-- Name: django_celery_beat_periodictask_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ps_admin
--

ALTER SEQUENCE public.django_celery_beat_periodictask_id_seq OWNED BY public.django_celery_beat_periodictask.id;


--
-- Name: django_celery_beat_periodictasks; Type: TABLE; Schema: public; Owner: ps_admin
--

CREATE TABLE public.django_celery_beat_periodictasks (
    ident smallint NOT NULL,
    last_update timestamp with time zone NOT NULL
);


ALTER TABLE public.django_celery_beat_periodictasks OWNER TO ps_admin;

--
-- Name: django_celery_beat_solarschedule; Type: TABLE; Schema: public; Owner: ps_admin
--

CREATE TABLE public.django_celery_beat_solarschedule (
    id bigint NOT NULL,
    event character varying(24) NOT NULL,
    latitude numeric(9,6) NOT NULL,
    longitude numeric(9,6) NOT NULL
);


ALTER TABLE public.django_celery_beat_solarschedule OWNER TO ps_admin;

--
-- Name: django_celery_beat_solarschedule_id_seq; Type: SEQUENCE; Schema: public; Owner: ps_admin
--

CREATE SEQUENCE public.django_celery_beat_solarschedule_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_celery_beat_solarschedule_id_seq OWNER TO ps_admin;

--
-- Name: django_celery_beat_solarschedule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ps_admin
--

ALTER SEQUENCE public.django_celery_beat_solarschedule_id_seq OWNED BY public.django_celery_beat_solarschedule.id;


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: ps_admin
--

CREATE TABLE public.django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO ps_admin;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: ps_admin
--

CREATE SEQUENCE public.django_content_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_content_type_id_seq OWNER TO ps_admin;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ps_admin
--

ALTER SEQUENCE public.django_content_type_id_seq OWNED BY public.django_content_type.id;


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: ps_admin
--

CREATE TABLE public.django_migrations (
    id bigint NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.django_migrations OWNER TO ps_admin;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: ps_admin
--

CREATE SEQUENCE public.django_migrations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_migrations_id_seq OWNER TO ps_admin;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ps_admin
--

ALTER SEQUENCE public.django_migrations_id_seq OWNED BY public.django_migrations.id;


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: ps_admin
--

CREATE TABLE public.django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO ps_admin;

--
-- Name: users_cluster; Type: TABLE; Schema: public; Owner: ps_admin
--

CREATE TABLE public.users_cluster (
    org_id uuid NOT NULL,
    creation_date timestamp with time zone NOT NULL,
    modified_date timestamp with time zone NOT NULL,
    mgr_ip_address inet NOT NULL,
    is_deployed boolean NOT NULL,
    deployed_state character varying(64) NOT NULL
);


ALTER TABLE public.users_cluster OWNER TO ps_admin;

--
-- Name: users_granchoices; Type: TABLE; Schema: public; Owner: ps_admin
--

CREATE TABLE public.users_granchoices (
    granularity character varying(7) NOT NULL
);


ALTER TABLE public.users_granchoices OWNER TO ps_admin;

--
-- Name: users_membership; Type: TABLE; Schema: public; Owner: ps_admin
--

CREATE TABLE public.users_membership (
    id uuid NOT NULL,
    active boolean NOT NULL,
    creation_date timestamp with time zone NOT NULL,
    modified_date timestamp with time zone NOT NULL,
    delete_requested boolean NOT NULL,
    activation_date timestamp with time zone NOT NULL,
    org_id uuid,
    user_id bigint
);


ALTER TABLE public.users_membership OWNER TO ps_admin;

--
-- Name: users_orgaccount; Type: TABLE; Schema: public; Owner: ps_admin
--

CREATE TABLE public.users_orgaccount (
    id uuid NOT NULL,
    name character varying(200) NOT NULL,
    point_of_contact_name character varying(200) NOT NULL,
    email character varying(254) NOT NULL,
    max_allowance numeric(8,2) NOT NULL,
    monthly_allowance numeric(8,2) NOT NULL,
    balance numeric(8,2) NOT NULL,
    creation_date timestamp with time zone NOT NULL,
    modified_date timestamp with time zone NOT NULL,
    node_mgr_fixed_cost double precision NOT NULL,
    node_fixed_cost double precision NOT NULL,
    init_num_nodes integer NOT NULL,
    cur_nodes integer NOT NULL,
    min_node_cap integer NOT NULL,
    max_node_cap integer NOT NULL,
    max_hrly double precision NOT NULL,
    cur_hrly double precision NOT NULL,
    min_hrly double precision NOT NULL,
    min_ddt timestamp with time zone NOT NULL,
    cur_ddt timestamp with time zone NOT NULL,
    max_ddt timestamp with time zone NOT NULL,
    most_recent_charge_time timestamp with time zone NOT NULL,
    most_recent_credit_time timestamp with time zone NOT NULL,
    fc_min_hourly jsonb NOT NULL,
    fc_min_daily jsonb NOT NULL,
    fc_min_monthly jsonb NOT NULL,
    fc_cur_hourly jsonb NOT NULL,
    fc_cur_daily jsonb NOT NULL,
    fc_cur_monthly jsonb NOT NULL,
    fc_max_hourly jsonb NOT NULL,
    fc_max_daily jsonb NOT NULL,
    fc_max_monthly jsonb NOT NULL,
    owner_id bigint
);


ALTER TABLE public.users_orgaccount OWNER TO ps_admin;

--
-- Name: users_orgcost; Type: TABLE; Schema: public; Owner: ps_admin
--

CREATE TABLE public.users_orgcost (
    id bigint NOT NULL,
    creation_date timestamp with time zone NOT NULL,
    modified_date timestamp with time zone NOT NULL,
    tm timestamp with time zone NOT NULL,
    cnt integer NOT NULL,
    avg double precision NOT NULL,
    min double precision NOT NULL,
    max double precision NOT NULL,
    std double precision NOT NULL,
    ccr jsonb NOT NULL,
    gran_id character varying(7),
    org_id uuid,
    cost_refresh_time timestamp with time zone NOT NULL
);


ALTER TABLE public.users_orgcost OWNER TO ps_admin;

--
-- Name: users_orgcost_id_seq; Type: SEQUENCE; Schema: public; Owner: ps_admin
--

CREATE SEQUENCE public.users_orgcost_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_orgcost_id_seq OWNER TO ps_admin;

--
-- Name: users_orgcost_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ps_admin
--

ALTER SEQUENCE public.users_orgcost_id_seq OWNED BY public.users_orgcost.id;


--
-- Name: users_user; Type: TABLE; Schema: public; Owner: ps_admin
--

CREATE TABLE public.users_user (
    id bigint NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    username character varying(150) NOT NULL,
    first_name character varying(150) NOT NULL,
    last_name character varying(150) NOT NULL,
    email character varying(254) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL,
    phone_number character varying(128) NOT NULL
);


ALTER TABLE public.users_user OWNER TO ps_admin;

--
-- Name: users_user_groups; Type: TABLE; Schema: public; Owner: ps_admin
--

CREATE TABLE public.users_user_groups (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.users_user_groups OWNER TO ps_admin;

--
-- Name: users_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: ps_admin
--

CREATE SEQUENCE public.users_user_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_user_groups_id_seq OWNER TO ps_admin;

--
-- Name: users_user_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ps_admin
--

ALTER SEQUENCE public.users_user_groups_id_seq OWNED BY public.users_user_groups.id;


--
-- Name: users_user_id_seq; Type: SEQUENCE; Schema: public; Owner: ps_admin
--

CREATE SEQUENCE public.users_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_user_id_seq OWNER TO ps_admin;

--
-- Name: users_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ps_admin
--

ALTER SEQUENCE public.users_user_id_seq OWNED BY public.users_user.id;


--
-- Name: users_user_user_permissions; Type: TABLE; Schema: public; Owner: ps_admin
--

CREATE TABLE public.users_user_user_permissions (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.users_user_user_permissions OWNER TO ps_admin;

--
-- Name: users_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: ps_admin
--

CREATE SEQUENCE public.users_user_user_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_user_user_permissions_id_seq OWNER TO ps_admin;

--
-- Name: users_user_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ps_admin
--

ALTER SEQUENCE public.users_user_user_permissions_id_seq OWNED BY public.users_user_user_permissions.id;


--
-- Name: auth_group id; Type: DEFAULT; Schema: public; Owner: ps_admin
--

ALTER TABLE ONLY public.auth_group ALTER COLUMN id SET DEFAULT nextval('public.auth_group_id_seq'::regclass);


--
-- Name: auth_group_permissions id; Type: DEFAULT; Schema: public; Owner: ps_admin
--

ALTER TABLE ONLY public.auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_group_permissions_id_seq'::regclass);


--
-- Name: auth_permission id; Type: DEFAULT; Schema: public; Owner: ps_admin
--

ALTER TABLE ONLY public.auth_permission ALTER COLUMN id SET DEFAULT nextval('public.auth_permission_id_seq'::regclass);


--
-- Name: django_admin_log id; Type: DEFAULT; Schema: public; Owner: ps_admin
--

ALTER TABLE ONLY public.django_admin_log ALTER COLUMN id SET DEFAULT nextval('public.django_admin_log_id_seq'::regclass);


--
-- Name: django_celery_beat_clockedschedule id; Type: DEFAULT; Schema: public; Owner: ps_admin
--

ALTER TABLE ONLY public.django_celery_beat_clockedschedule ALTER COLUMN id SET DEFAULT nextval('public.django_celery_beat_clockedschedule_id_seq'::regclass);


--
-- Name: django_celery_beat_crontabschedule id; Type: DEFAULT; Schema: public; Owner: ps_admin
--

ALTER TABLE ONLY public.django_celery_beat_crontabschedule ALTER COLUMN id SET DEFAULT nextval('public.django_celery_beat_crontabschedule_id_seq'::regclass);


--
-- Name: django_celery_beat_intervalschedule id; Type: DEFAULT; Schema: public; Owner: ps_admin
--

ALTER TABLE ONLY public.django_celery_beat_intervalschedule ALTER COLUMN id SET DEFAULT nextval('public.django_celery_beat_intervalschedule_id_seq'::regclass);


--
-- Name: django_celery_beat_periodictask id; Type: DEFAULT; Schema: public; Owner: ps_admin
--

ALTER TABLE ONLY public.django_celery_beat_periodictask ALTER COLUMN id SET DEFAULT nextval('public.django_celery_beat_periodictask_id_seq'::regclass);


--
-- Name: django_celery_beat_solarschedule id; Type: DEFAULT; Schema: public; Owner: ps_admin
--

ALTER TABLE ONLY public.django_celery_beat_solarschedule ALTER COLUMN id SET DEFAULT nextval('public.django_celery_beat_solarschedule_id_seq'::regclass);


--
-- Name: django_content_type id; Type: DEFAULT; Schema: public; Owner: ps_admin
--

ALTER TABLE ONLY public.django_content_type ALTER COLUMN id SET DEFAULT nextval('public.django_content_type_id_seq'::regclass);


--
-- Name: django_migrations id; Type: DEFAULT; Schema: public; Owner: ps_admin
--

ALTER TABLE ONLY public.django_migrations ALTER COLUMN id SET DEFAULT nextval('public.django_migrations_id_seq'::regclass);


--
-- Name: users_orgcost id; Type: DEFAULT; Schema: public; Owner: ps_admin
--

ALTER TABLE ONLY public.users_orgcost ALTER COLUMN id SET DEFAULT nextval('public.users_orgcost_id_seq'::regclass);


--
-- Name: users_user id; Type: DEFAULT; Schema: public; Owner: ps_admin
--

ALTER TABLE ONLY public.users_user ALTER COLUMN id SET DEFAULT nextval('public.users_user_id_seq'::regclass);


--
-- Name: users_user_groups id; Type: DEFAULT; Schema: public; Owner: ps_admin
--

ALTER TABLE ONLY public.users_user_groups ALTER COLUMN id SET DEFAULT nextval('public.users_user_groups_id_seq'::regclass);


--
-- Name: users_user_user_permissions id; Type: DEFAULT; Schema: public; Owner: ps_admin
--

ALTER TABLE ONLY public.users_user_user_permissions ALTER COLUMN id SET DEFAULT nextval('public.users_user_user_permissions_id_seq'::regclass);


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.auth_group (id, name) FROM stdin;
1	PS_Developer
\.


--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.auth_group_permissions (id, group_id, permission_id) FROM stdin;
1	1	21
2	1	22
3	1	23
4	1	24
5	1	25
6	1	26
7	1	27
8	1	28
9	1	29
10	1	30
11	1	31
12	1	32
13	1	33
14	1	34
15	1	35
16	1	36
17	1	37
18	1	38
19	1	39
20	1	40
21	1	41
22	1	42
23	1	43
24	1	44
25	1	53
26	1	54
27	1	55
28	1	56
29	1	57
30	1	58
31	1	59
32	1	60
33	1	65
34	1	66
35	1	67
36	1	68
37	1	64
38	1	61
39	1	62
40	1	63
\.


--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.auth_permission (id, name, content_type_id, codename) FROM stdin;
1	Can add log entry	1	add_logentry
2	Can change log entry	1	change_logentry
3	Can delete log entry	1	delete_logentry
4	Can view log entry	1	view_logentry
5	Can add permission	2	add_permission
6	Can change permission	2	change_permission
7	Can delete permission	2	delete_permission
8	Can view permission	2	view_permission
9	Can add group	3	add_group
10	Can change group	3	change_group
11	Can delete group	3	delete_group
12	Can view group	3	view_group
13	Can add content type	4	add_contenttype
14	Can change content type	4	change_contenttype
15	Can delete content type	4	delete_contenttype
16	Can view content type	4	view_contenttype
17	Can add session	5	add_session
18	Can change session	5	change_session
19	Can delete session	5	delete_session
20	Can view session	5	view_session
21	Can add crontab	6	add_crontabschedule
22	Can change crontab	6	change_crontabschedule
23	Can delete crontab	6	delete_crontabschedule
24	Can view crontab	6	view_crontabschedule
25	Can add interval	7	add_intervalschedule
26	Can change interval	7	change_intervalschedule
27	Can delete interval	7	delete_intervalschedule
28	Can view interval	7	view_intervalschedule
29	Can add periodic task	8	add_periodictask
30	Can change periodic task	8	change_periodictask
31	Can delete periodic task	8	delete_periodictask
32	Can view periodic task	8	view_periodictask
33	Can add periodic tasks	9	add_periodictasks
34	Can change periodic tasks	9	change_periodictasks
35	Can delete periodic tasks	9	delete_periodictasks
36	Can view periodic tasks	9	view_periodictasks
37	Can add solar event	10	add_solarschedule
38	Can change solar event	10	change_solarschedule
39	Can delete solar event	10	delete_solarschedule
40	Can view solar event	10	view_solarschedule
41	Can add clocked	11	add_clockedschedule
42	Can change clocked	11	change_clockedschedule
43	Can delete clocked	11	delete_clockedschedule
44	Can view clocked	11	view_clockedschedule
45	Can add user	12	add_user
46	Can change user	12	change_user
47	Can delete user	12	delete_user
48	Can view user	12	view_user
49	Can add gran choices	13	add_granchoices
50	Can change gran choices	13	change_granchoices
51	Can delete gran choices	13	delete_granchoices
52	Can view gran choices	13	view_granchoices
53	Can add org account	14	add_orgaccount
54	Can change org account	14	change_orgaccount
55	Can delete org account	14	delete_orgaccount
56	Can view org account	14	view_orgaccount
57	Can add cluster	15	add_cluster
58	Can change cluster	15	change_cluster
59	Can delete cluster	15	delete_cluster
60	Can view cluster	15	view_cluster
61	Can add org cost	16	add_orgcost
62	Can change org cost	16	change_orgcost
63	Can delete org cost	16	delete_orgcost
64	Can view org cost	16	view_orgcost
65	Can add membership	17	add_membership
66	Can change membership	17	change_membership
67	Can delete membership	17	delete_membership
68	Can view membership	17	view_membership
\.


--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
1	2022-04-01 19:20:19.810685+00	1	PS_Developer	1	[{"added": {}}]	3	1
2	2022-04-01 20:57:03.280989+00	2	ceugarteblair	2	[{"changed": {"fields": ["Groups", "Staff status"]}}]	12	1
3	2022-04-07 12:24:49.141274+00	1	OrgCost object (1)	3		16	1
4	2022-04-07 12:38:19.076441+00	1	PS_Developer	2	[{"changed": {"fields": ["Permissions"]}}]	3	1
5	2022-04-07 12:53:22.868076+00	da16a76c-bfdb-45c4-9075-ee4b87f7f584	UofMDTest:ceugarteblair	3		17	1
6	2022-04-07 12:53:22.871507+00	c98704ad-4885-4430-a526-769757c49505	Developers:ceugarteblair	3		17	1
7	2022-04-07 12:53:22.87269+00	4abd2a6a-985f-4974-967e-a756318024a1	UofMDTest:terpadmin	3		17	1
8	2022-04-07 12:53:36.009753+00	3	OrgCost object (3)	3		16	1
9	2022-04-07 12:53:36.012647+00	2	OrgCost object (2)	3		16	1
10	2022-04-07 12:53:45.2187+00	685d63c3-2b8c-4afc-a132-96e534ea1517	Developers	3		14	1
11	2022-04-07 12:53:45.220339+00	292f4349-dc2a-4722-8d73-c50241221b23	UofMDTest	3		14	1
\.


--
-- Data for Name: django_celery_beat_clockedschedule; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.django_celery_beat_clockedschedule (id, clocked_time) FROM stdin;
\.


--
-- Data for Name: django_celery_beat_crontabschedule; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.django_celery_beat_crontabschedule (id, minute, hour, day_of_week, day_of_month, month_of_year, timezone) FROM stdin;
1	0	4	*	*	*	UTC
2	30	*	*	*	*	UTC
\.


--
-- Data for Name: django_celery_beat_intervalschedule; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.django_celery_beat_intervalschedule (id, every, period) FROM stdin;
\.


--
-- Data for Name: django_celery_beat_periodictask; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.django_celery_beat_periodictask (id, name, task, args, kwargs, queue, exchange, routing_key, expires, enabled, last_run_at, total_run_count, date_changed, description, crontab_id, interval_id, solar_id, one_off, start_time, priority, headers, clocked_id, expire_seconds) FROM stdin;
1	celery.backend_cleanup	celery.backend_cleanup	[]	{}	\N	\N	\N	\N	t	2022-04-07 04:00:00.022639+00	1	2022-04-08 00:53:46.006345+00		1	\N	\N	f	\N	\N	{}	\N	43200
2	hourly processing	hourly_processing	[]	{}	\N	\N	\N	\N	t	2022-04-08 00:34:15.491208+00	44	2022-04-08 00:53:46.017525+00		2	\N	\N	f	\N	\N	{}	\N	\N
\.


--
-- Data for Name: django_celery_beat_periodictasks; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.django_celery_beat_periodictasks (ident, last_update) FROM stdin;
1	2022-04-08 00:53:46.016073+00
\.


--
-- Data for Name: django_celery_beat_solarschedule; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.django_celery_beat_solarschedule (id, event, latitude, longitude) FROM stdin;
\.


--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.django_content_type (id, app_label, model) FROM stdin;
1	admin	logentry
2	auth	permission
3	auth	group
4	contenttypes	contenttype
5	sessions	session
6	django_celery_beat	crontabschedule
7	django_celery_beat	intervalschedule
8	django_celery_beat	periodictask
9	django_celery_beat	periodictasks
10	django_celery_beat	solarschedule
11	django_celery_beat	clockedschedule
12	users	user
13	users	granchoices
14	users	orgaccount
15	users	cluster
16	users	orgcost
17	users	membership
\.


--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.django_migrations (id, app, name, applied) FROM stdin;
1	contenttypes	0001_initial	2022-04-01 19:16:25.390486+00
2	contenttypes	0002_remove_content_type_name	2022-04-01 19:16:25.393927+00
3	auth	0001_initial	2022-04-01 19:16:25.413439+00
4	auth	0002_alter_permission_name_max_length	2022-04-01 19:16:25.416611+00
5	auth	0003_alter_user_email_max_length	2022-04-01 19:16:25.419741+00
6	auth	0004_alter_user_username_opts	2022-04-01 19:16:25.422858+00
7	auth	0005_alter_user_last_login_null	2022-04-01 19:16:25.425861+00
8	auth	0006_require_contenttypes_0002	2022-04-01 19:16:25.427217+00
9	auth	0007_alter_validators_add_error_messages	2022-04-01 19:16:25.430076+00
10	auth	0008_alter_user_username_max_length	2022-04-01 19:16:25.432606+00
11	auth	0009_alter_user_last_name_max_length	2022-04-01 19:16:25.434982+00
12	auth	0010_alter_group_name_max_length	2022-04-01 19:16:25.438599+00
13	auth	0011_update_proxy_permissions	2022-04-01 19:16:25.442073+00
14	auth	0012_alter_user_first_name_max_length	2022-04-01 19:16:25.44465+00
15	users	0001_initial	2022-04-01 19:16:25.506088+00
16	admin	0001_initial	2022-04-01 19:16:25.516713+00
17	admin	0002_logentry_remove_auto_add	2022-04-01 19:16:25.521862+00
18	admin	0003_logentry_add_action_flag_choices	2022-04-01 19:16:25.526086+00
19	django_celery_beat	0001_initial	2022-04-01 19:16:25.540822+00
20	django_celery_beat	0002_auto_20161118_0346	2022-04-01 19:16:25.547758+00
21	django_celery_beat	0003_auto_20161209_0049	2022-04-01 19:16:25.552409+00
22	django_celery_beat	0004_auto_20170221_0000	2022-04-01 19:16:25.554752+00
23	django_celery_beat	0005_add_solarschedule_events_choices	2022-04-01 19:16:25.557231+00
24	django_celery_beat	0006_auto_20180322_0932	2022-04-01 19:16:25.5672+00
25	django_celery_beat	0007_auto_20180521_0826	2022-04-01 19:16:25.572385+00
26	django_celery_beat	0008_auto_20180914_1922	2022-04-01 19:16:25.57943+00
27	django_celery_beat	0006_auto_20180210_1226	2022-04-01 19:16:25.585313+00
28	django_celery_beat	0006_periodictask_priority	2022-04-01 19:16:25.588864+00
29	django_celery_beat	0009_periodictask_headers	2022-04-01 19:16:25.59224+00
30	django_celery_beat	0010_auto_20190429_0326	2022-04-01 19:16:25.631437+00
31	django_celery_beat	0011_auto_20190508_0153	2022-04-01 19:16:25.640994+00
32	django_celery_beat	0012_periodictask_expire_seconds	2022-04-01 19:16:25.644432+00
33	django_celery_beat	0013_auto_20200609_0727	2022-04-01 19:16:25.647249+00
34	django_celery_beat	0014_remove_clockedschedule_enabled	2022-04-01 19:16:25.650148+00
35	django_celery_beat	0015_alter_clockedschedule_id_alter_crontabschedule_id_and_more	2022-04-01 19:16:25.71276+00
36	sessions	0001_initial	2022-04-01 19:16:25.722042+00
37	users	0002_auto_20220401_1522	2022-04-01 19:25:37.723967+00
38	django_celery_beat	0015_edit_solarschedule_events_choices	2022-04-04 21:56:38.673964+00
39	users	0003_auto_20220407_0829	2022-04-07 12:29:58.82742+00
\.


--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.django_session (session_key, session_data, expire_date) FROM stdin;
0okwxvzdt6aq8qxroaaxawyvir99kjsm	.eJxVjEEOwiAQRe_C2hAoVGZcuu8ZCMxMpWpoUtqV8e7apAvd_vfef6mYtrXErckSJ1YX1anT75YTPaTugO-p3mZNc12XKetd0QdtephZntfD_TsoqZVvDZYtnXsMI3UAjn0ARiZ0VoKIBcM5eI_OEeaAhnnsE4L1Xhwkb0i9P9gqN5c:1ncca0:XYydQPCjlYQn7EJxrezT2YsOtbMmDdkXw4hnPRvKv5w	2022-04-22 00:34:24.972262+00
\.


--
-- Data for Name: users_cluster; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.users_cluster (org_id, creation_date, modified_date, mgr_ip_address, is_deployed, deployed_state) FROM stdin;
1692aada-8f04-4107-a6a5-ae5d46d90123	2022-04-07 12:55:48.883151+00	2022-04-07 19:30:04.711497+00	0.0.0.0	f	Cluster is not deployed
86082b90-785e-46e2-a8f6-37e82fc04d00	2022-04-07 12:57:58.331371+00	2022-04-07 19:30:09.098969+00	0.0.0.0	f	Cluster is not deployed
\.


--
-- Data for Name: users_granchoices; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.users_granchoices (granularity) FROM stdin;
HOURLY
DAILY
MONTHLY
\.


--
-- Data for Name: users_membership; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.users_membership (id, active, creation_date, modified_date, delete_requested, activation_date, org_id, user_id) FROM stdin;
b4606c13-502e-4b46-a5a1-793da54ad95f	t	2022-04-07 12:55:48.898038+00	2022-04-07 12:55:48.89805+00	f	2022-04-07 12:55:48.898058+00	1692aada-8f04-4107-a6a5-ae5d46d90123	2
e240bde5-7535-4362-95a3-cc5fdccf3cc2	t	2022-04-07 12:57:58.344786+00	2022-04-07 12:57:58.344799+00	f	2022-04-07 12:57:58.344805+00	86082b90-785e-46e2-a8f6-37e82fc04d00	3
410e8622-8084-4ab9-871d-48e51a621ef3	t	2022-04-07 12:57:58.347198+00	2022-04-07 12:57:58.347205+00	f	2022-04-07 12:57:58.34721+00	86082b90-785e-46e2-a8f6-37e82fc04d00	2
\.


--
-- Data for Name: users_orgaccount; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.users_orgaccount (id, name, point_of_contact_name, email, max_allowance, monthly_allowance, balance, creation_date, modified_date, node_mgr_fixed_cost, node_fixed_cost, init_num_nodes, cur_nodes, min_node_cap, max_node_cap, max_hrly, cur_hrly, min_hrly, min_ddt, cur_ddt, max_ddt, most_recent_charge_time, most_recent_credit_time, fc_min_hourly, fc_min_daily, fc_min_monthly, fc_cur_hourly, fc_cur_daily, fc_cur_monthly, fc_max_hourly, fc_max_daily, fc_max_monthly, owner_id) FROM stdin;
86082b90-785e-46e2-a8f6-37e82fc04d00	UofMDTest	support team	sps.sliderule@gmail.com	50.00	10.00	50.00	2022-04-07 12:57:58.32882+00	2022-04-07 19:30:09.750023+00	0.306	0.226	2	2	2	2	0.758	0.758	0.758	2022-04-10 13:27:56.186455+00	2022-04-10 13:27:56.187795+00	2022-04-10 13:27:56.189372+00	2022-04-07 12:57:58.328899+00	2022-04-07 12:57:58.328904+00	"{\\"tm\\": [\\"2022-04-07T12:00\\", \\"2022-04-07T13:00\\", \\"2022-04-07T14:00\\", \\"2022-04-07T15:00\\", \\"2022-04-07T16:00\\", \\"2022-04-07T17:00\\", \\"2022-04-07T18:00\\", \\"2022-04-07T19:00\\", \\"2022-04-07T20:00\\", \\"2022-04-07T21:00\\", \\"2022-04-07T22:00\\", \\"2022-04-07T23:00\\", \\"2022-04-08T00:00\\", \\"2022-04-08T01:00\\", \\"2022-04-08T02:00\\", \\"2022-04-08T03:00\\", \\"2022-04-08T04:00\\", \\"2022-04-08T05:00\\", \\"2022-04-08T06:00\\", \\"2022-04-08T07:00\\", \\"2022-04-08T08:00\\", \\"2022-04-08T09:00\\", \\"2022-04-08T10:00\\", \\"2022-04-08T11:00\\", \\"2022-04-08T12:00\\", \\"2022-04-08T13:00\\", \\"2022-04-08T14:00\\", \\"2022-04-08T15:00\\", \\"2022-04-08T16:00\\", \\"2022-04-08T17:00\\", \\"2022-04-08T18:00\\", \\"2022-04-08T19:00\\", \\"2022-04-08T20:00\\", \\"2022-04-08T21:00\\", \\"2022-04-08T22:00\\", \\"2022-04-08T23:00\\", \\"2022-04-09T00:00\\", \\"2022-04-09T01:00\\", \\"2022-04-09T02:00\\", \\"2022-04-09T03:00\\", \\"2022-04-09T04:00\\", \\"2022-04-09T05:00\\", \\"2022-04-09T06:00\\", \\"2022-04-09T07:00\\", \\"2022-04-09T08:00\\", \\"2022-04-09T09:00\\", \\"2022-04-09T10:00\\", \\"2022-04-09T11:00\\", \\"2022-04-09T12:00\\", \\"2022-04-09T13:00\\", \\"2022-04-09T14:00\\", \\"2022-04-09T15:00\\", \\"2022-04-09T16:00\\", \\"2022-04-09T17:00\\", \\"2022-04-09T18:00\\", \\"2022-04-09T19:00\\", \\"2022-04-09T20:00\\", \\"2022-04-09T21:00\\", \\"2022-04-09T22:00\\", \\"2022-04-09T23:00\\", \\"2022-04-10T00:00\\", \\"2022-04-10T01:00\\", \\"2022-04-10T02:00\\", \\"2022-04-10T03:00\\", \\"2022-04-10T04:00\\", \\"2022-04-10T05:00\\", \\"2022-04-10T06:00\\", \\"2022-04-10T07:00\\", \\"2022-04-10T08:00\\", \\"2022-04-10T09:00\\", \\"2022-04-10T10:00\\", \\"2022-04-10T11:00\\", \\"2022-04-10T12:00\\", \\"2022-04-10T13:00\\", \\"2022-04-10T14:00\\", \\"2022-04-10T15:00\\", \\"2022-04-10T16:00\\", \\"2022-04-10T17:00\\", \\"2022-04-10T18:00\\", \\"2022-04-10T19:00\\", \\"2022-04-10T20:00\\", \\"2022-04-10T21:00\\", \\"2022-04-10T22:00\\", \\"2022-04-10T23:00\\", \\"2022-04-11T00:00\\", \\"2022-04-11T01:00\\", \\"2022-04-11T02:00\\", \\"2022-04-11T03:00\\", \\"2022-04-11T04:00\\", \\"2022-04-11T05:00\\", \\"2022-04-11T06:00\\", \\"2022-04-11T07:00\\", \\"2022-04-11T08:00\\", \\"2022-04-11T09:00\\", \\"2022-04-11T10:00\\", \\"2022-04-11T11:00\\", \\"2022-04-11T12:00\\", \\"2022-04-11T13:00\\", \\"2022-04-11T14:00\\", \\"2022-04-11T15:00\\", \\"2022-04-11T16:00\\", \\"2022-04-11T17:00\\", \\"2022-04-11T18:00\\", \\"2022-04-11T19:00\\", \\"2022-04-11T20:00\\", \\"2022-04-11T21:00\\", \\"2022-04-11T22:00\\", \\"2022-04-11T23:00\\", \\"2022-04-12T00:00\\", \\"2022-04-12T01:00\\", \\"2022-04-12T02:00\\", \\"2022-04-12T03:00\\", \\"2022-04-12T04:00\\", \\"2022-04-12T05:00\\", \\"2022-04-12T06:00\\", \\"2022-04-12T07:00\\", \\"2022-04-12T08:00\\", \\"2022-04-12T09:00\\", \\"2022-04-12T10:00\\", \\"2022-04-12T11:00\\", \\"2022-04-12T12:00\\", \\"2022-04-12T13:00\\", \\"2022-04-12T14:00\\", \\"2022-04-12T15:00\\", \\"2022-04-12T16:00\\", \\"2022-04-12T17:00\\", \\"2022-04-12T18:00\\", \\"2022-04-12T19:00\\", \\"2022-04-12T20:00\\", \\"2022-04-12T21:00\\", \\"2022-04-12T22:00\\", \\"2022-04-12T23:00\\", \\"2022-04-13T00:00\\", \\"2022-04-13T01:00\\", \\"2022-04-13T02:00\\", \\"2022-04-13T03:00\\", \\"2022-04-13T04:00\\", \\"2022-04-13T05:00\\", \\"2022-04-13T06:00\\", \\"2022-04-13T07:00\\", \\"2022-04-13T08:00\\", \\"2022-04-13T09:00\\", \\"2022-04-13T10:00\\", \\"2022-04-13T11:00\\", \\"2022-04-13T12:00\\", \\"2022-04-13T13:00\\", \\"2022-04-13T14:00\\", \\"2022-04-13T15:00\\", \\"2022-04-13T16:00\\", \\"2022-04-13T17:00\\", \\"2022-04-13T18:00\\", \\"2022-04-13T19:00\\", \\"2022-04-13T20:00\\", \\"2022-04-13T21:00\\", \\"2022-04-13T22:00\\", \\"2022-04-13T23:00\\", \\"2022-04-14T00:00\\", \\"2022-04-14T01:00\\", \\"2022-04-14T02:00\\", \\"2022-04-14T03:00\\", \\"2022-04-14T04:00\\", \\"2022-04-14T05:00\\", \\"2022-04-14T06:00\\", \\"2022-04-14T07:00\\", \\"2022-04-14T08:00\\", \\"2022-04-14T09:00\\", \\"2022-04-14T10:00\\", \\"2022-04-14T11:00\\", \\"2022-04-14T12:00\\", \\"2022-04-14T13:00\\", \\"2022-04-14T14:00\\", \\"2022-04-14T15:00\\", \\"2022-04-14T16:00\\", \\"2022-04-14T17:00\\", \\"2022-04-14T18:00\\", \\"2022-04-14T19:00\\", \\"2022-04-14T20:00\\", \\"2022-04-14T21:00\\", \\"2022-04-14T22:00\\", \\"2022-04-14T23:00\\", \\"2022-04-15T00:00\\", \\"2022-04-15T01:00\\", \\"2022-04-15T02:00\\", \\"2022-04-15T03:00\\", \\"2022-04-15T04:00\\", \\"2022-04-15T05:00\\", \\"2022-04-15T06:00\\", \\"2022-04-15T07:00\\", \\"2022-04-15T08:00\\", \\"2022-04-15T09:00\\", \\"2022-04-15T10:00\\", \\"2022-04-15T11:00\\", \\"2022-04-15T12:00\\", \\"2022-04-15T13:00\\", \\"2022-04-15T14:00\\", \\"2022-04-15T15:00\\", \\"2022-04-15T16:00\\", \\"2022-04-15T17:00\\", \\"2022-04-15T18:00\\", \\"2022-04-15T19:00\\", \\"2022-04-15T20:00\\", \\"2022-04-15T21:00\\", \\"2022-04-15T22:00\\", \\"2022-04-15T23:00\\", \\"2022-04-16T00:00\\", \\"2022-04-16T01:00\\", \\"2022-04-16T02:00\\", \\"2022-04-16T03:00\\", \\"2022-04-16T04:00\\", \\"2022-04-16T05:00\\", \\"2022-04-16T06:00\\", \\"2022-04-16T07:00\\", \\"2022-04-16T08:00\\", \\"2022-04-16T09:00\\", \\"2022-04-16T10:00\\", \\"2022-04-16T11:00\\", \\"2022-04-16T12:00\\", \\"2022-04-16T13:00\\", \\"2022-04-16T14:00\\", \\"2022-04-16T15:00\\", \\"2022-04-16T16:00\\", \\"2022-04-16T17:00\\", \\"2022-04-16T18:00\\", \\"2022-04-16T19:00\\", \\"2022-04-16T20:00\\", \\"2022-04-16T21:00\\", \\"2022-04-16T22:00\\", \\"2022-04-16T23:00\\", \\"2022-04-17T00:00\\", \\"2022-04-17T01:00\\", \\"2022-04-17T02:00\\", \\"2022-04-17T03:00\\", \\"2022-04-17T04:00\\", \\"2022-04-17T05:00\\", \\"2022-04-17T06:00\\", \\"2022-04-17T07:00\\", \\"2022-04-17T08:00\\", \\"2022-04-17T09:00\\", \\"2022-04-17T10:00\\", \\"2022-04-17T11:00\\", \\"2022-04-17T12:00\\", \\"2022-04-17T13:00\\", \\"2022-04-17T14:00\\", \\"2022-04-17T15:00\\", \\"2022-04-17T16:00\\", \\"2022-04-17T17:00\\", \\"2022-04-17T18:00\\", \\"2022-04-17T19:00\\", \\"2022-04-17T20:00\\", \\"2022-04-17T21:00\\", \\"2022-04-17T22:00\\", \\"2022-04-17T23:00\\", \\"2022-04-18T00:00\\", \\"2022-04-18T01:00\\", \\"2022-04-18T02:00\\", \\"2022-04-18T03:00\\", \\"2022-04-18T04:00\\", \\"2022-04-18T05:00\\", \\"2022-04-18T06:00\\", \\"2022-04-18T07:00\\", \\"2022-04-18T08:00\\", \\"2022-04-18T09:00\\", \\"2022-04-18T10:00\\", \\"2022-04-18T11:00\\", \\"2022-04-18T12:00\\", \\"2022-04-18T13:00\\", \\"2022-04-18T14:00\\", \\"2022-04-18T15:00\\", \\"2022-04-18T16:00\\", \\"2022-04-18T17:00\\", \\"2022-04-18T18:00\\", \\"2022-04-18T19:00\\", \\"2022-04-18T20:00\\", \\"2022-04-18T21:00\\", \\"2022-04-18T22:00\\", \\"2022-04-18T23:00\\", \\"2022-04-19T00:00\\", \\"2022-04-19T01:00\\", \\"2022-04-19T02:00\\", \\"2022-04-19T03:00\\", \\"2022-04-19T04:00\\", \\"2022-04-19T05:00\\", \\"2022-04-19T06:00\\", \\"2022-04-19T07:00\\", \\"2022-04-19T08:00\\", \\"2022-04-19T09:00\\", \\"2022-04-19T10:00\\", \\"2022-04-19T11:00\\", \\"2022-04-19T12:00\\", \\"2022-04-19T13:00\\", \\"2022-04-19T14:00\\", \\"2022-04-19T15:00\\", \\"2022-04-19T16:00\\", \\"2022-04-19T17:00\\", \\"2022-04-19T18:00\\", \\"2022-04-19T19:00\\", \\"2022-04-19T20:00\\", \\"2022-04-19T21:00\\", \\"2022-04-19T22:00\\", \\"2022-04-19T23:00\\", \\"2022-04-20T00:00\\", \\"2022-04-20T01:00\\", \\"2022-04-20T02:00\\", \\"2022-04-20T03:00\\", \\"2022-04-20T04:00\\", \\"2022-04-20T05:00\\", \\"2022-04-20T06:00\\", \\"2022-04-20T07:00\\", \\"2022-04-20T08:00\\", \\"2022-04-20T09:00\\", \\"2022-04-20T10:00\\", \\"2022-04-20T11:00\\", \\"2022-04-20T12:00\\", \\"2022-04-20T13:00\\", \\"2022-04-20T14:00\\", \\"2022-04-20T15:00\\", \\"2022-04-20T16:00\\", \\"2022-04-20T17:00\\", \\"2022-04-20T18:00\\", \\"2022-04-20T19:00\\", \\"2022-04-20T20:00\\", \\"2022-04-20T21:00\\", \\"2022-04-20T22:00\\", \\"2022-04-20T23:00\\", \\"2022-04-21T00:00\\", \\"2022-04-21T01:00\\", \\"2022-04-21T02:00\\", \\"2022-04-21T03:00\\", \\"2022-04-21T04:00\\", \\"2022-04-21T05:00\\", \\"2022-04-21T06:00\\", \\"2022-04-21T07:00\\", \\"2022-04-21T08:00\\", \\"2022-04-21T09:00\\", \\"2022-04-21T10:00\\", \\"2022-04-21T11:00\\"], \\"bal\\": [49.242, 48.483999999999995, 47.72599999999999, 46.96799999999999, 46.20999999999999, 45.451999999999984, 44.69399999999998, 43.93599999999998, 43.177999999999976, 42.41999999999997, 41.66199999999997, 40.90399999999997, 40.145999999999965, 39.38799999999996, 38.62999999999996, 37.87199999999996, 37.113999999999955, 36.35599999999995, 35.59799999999995, 34.83999999999995, 34.081999999999944, 33.32399999999994, 32.56599999999994, 31.80799999999994, 31.04999999999994, 30.29199999999994, 29.533999999999942, 28.775999999999943, 28.017999999999944, 27.259999999999945, 26.501999999999946, 25.743999999999946, 24.985999999999947, 24.22799999999995, 23.46999999999995, 22.71199999999995, 21.95399999999995, 21.19599999999995, 20.437999999999953, 19.679999999999954, 18.921999999999954, 18.163999999999955, 17.405999999999956, 16.647999999999957, 15.889999999999958, 15.131999999999959, 14.37399999999996, 13.61599999999996, 12.857999999999961, 12.099999999999962, 11.341999999999963, 10.583999999999964, 9.825999999999965, 9.067999999999966, 8.309999999999967, 7.551999999999967, 6.793999999999967, 6.035999999999967, 5.277999999999967, 4.519999999999967, 3.7619999999999667, 3.0039999999999667, 2.2459999999999667, 1.4879999999999667, 0.7299999999999667, -0.02800000000003333, -0.7860000000000333, -1.5440000000000333, -2.3020000000000334, -3.0600000000000334, -3.8180000000000334, -4.576000000000033, -5.334000000000033, -6.092000000000033, -6.850000000000033, -7.608000000000033, -8.366000000000033, -9.124000000000034, -9.882000000000033, -10.640000000000033, -11.398000000000032, -12.15600000000003, -12.91400000000003, -13.672000000000029, -14.430000000000028, -15.188000000000027, -15.946000000000026, -16.704000000000025, -17.462000000000025, -18.220000000000024, -18.978000000000023, -19.736000000000022, -20.49400000000002, -21.25200000000002, -22.01000000000002, -22.76800000000002, -23.526000000000018, -24.284000000000017, -25.042000000000016, -25.800000000000015, -26.558000000000014, -27.316000000000013, -28.074000000000012, -28.83200000000001, -29.59000000000001, -30.34800000000001, -31.10600000000001, -31.864000000000008, -32.62200000000001, -33.38000000000001, -34.13800000000001, -34.896000000000015, -35.65400000000002, -36.41200000000002, -37.17000000000002, -37.928000000000026, -38.68600000000003, -39.44400000000003, -40.202000000000034, -40.960000000000036, -41.71800000000004, -42.47600000000004, -43.234000000000044, -43.99200000000005, -44.75000000000005, -45.50800000000005, -46.266000000000055, -47.02400000000006, -47.78200000000006, -48.54000000000006, -49.298000000000066, -50.05600000000007, -50.81400000000007, -51.572000000000074, -52.33000000000008, -53.08800000000008, -53.84600000000008, -54.604000000000084, -55.36200000000009, -56.12000000000009, -56.87800000000009, -57.636000000000095, -58.3940000000001, -59.1520000000001, -59.9100000000001, -60.668000000000106, -61.42600000000011, -62.18400000000011, -62.942000000000114, -63.70000000000012, -64.45800000000011, -65.21600000000011, -65.9740000000001, -66.7320000000001, -67.4900000000001, -68.24800000000009, -69.00600000000009, -69.76400000000008, -70.52200000000008, -71.28000000000007, -72.03800000000007, -72.79600000000006, -73.55400000000006, -74.31200000000005, -75.07000000000005, -75.82800000000005, -76.58600000000004, -77.34400000000004, -78.10200000000003, -78.86000000000003, -79.61800000000002, -80.37600000000002, -81.13400000000001, -81.89200000000001, -82.65, -83.408, -84.166, -84.92399999999999, -85.68199999999999, -86.43999999999998, -87.19799999999998, -87.95599999999997, -88.71399999999997, -89.47199999999997, -90.22999999999996, -90.98799999999996, -91.74599999999995, -92.50399999999995, -93.26199999999994, -94.01999999999994, -94.77799999999993, -95.53599999999993, -96.29399999999993, -97.05199999999992, -97.80999999999992, -98.56799999999991, -99.32599999999991, -100.0839999999999, -100.8419999999999, -101.5999999999999, -102.35799999999989, -103.11599999999989, -103.87399999999988, -104.63199999999988, -105.38999999999987, -106.14799999999987, -106.90599999999986, -107.66399999999986, -108.42199999999985, -109.17999999999985, -109.93799999999985, -110.69599999999984, -111.45399999999984, -112.21199999999983, -112.96999999999983, -113.72799999999982, -114.48599999999982, -115.24399999999982, -116.00199999999981, -116.7599999999998, -117.5179999999998, -118.2759999999998, -119.03399999999979, -119.79199999999979, -120.54999999999978, -121.30799999999978, -122.06599999999978, -122.82399999999977, -123.58199999999977, -124.33999999999976, -125.09799999999976, -125.85599999999975, -126.61399999999975, -127.37199999999974, -128.12999999999974, -128.88799999999975, -129.64599999999976, -130.40399999999977, -131.16199999999978, -131.9199999999998, -132.6779999999998, -133.4359999999998, -134.19399999999982, -134.95199999999983, -135.70999999999984, -136.46799999999985, -137.22599999999986, -137.98399999999987, -138.74199999999988, -139.4999999999999, -140.2579999999999, -141.0159999999999, -141.77399999999992, -142.53199999999993, -143.28999999999994, -144.04799999999994, -144.80599999999995, -145.56399999999996, -146.32199999999997, -147.07999999999998, -147.838, -148.596, -149.354, -150.11200000000002, -150.87000000000003, -151.62800000000004, -152.38600000000005, -153.14400000000006, -153.90200000000007, -154.66000000000008, -155.4180000000001, -156.1760000000001, -156.9340000000001, -157.69200000000012, -158.45000000000013, -159.20800000000014, -159.96600000000015, -160.72400000000016, -161.48200000000017, -162.24000000000018, -162.9980000000002, -163.7560000000002, -164.5140000000002, -165.27200000000022, -166.03000000000023, -166.78800000000024, -167.54600000000025, -168.30400000000026, -169.06200000000027, -169.82000000000028, -170.5780000000003, -171.3360000000003, -172.0940000000003, -172.85200000000032, -173.61000000000033, -174.36800000000034, -175.12600000000035, -175.88400000000036, -176.64200000000037, -177.40000000000038, -178.15800000000038, -178.9160000000004, -179.6740000000004, -180.43200000000041, -181.19000000000042, -181.94800000000043, -182.70600000000044, -183.46400000000045, -184.22200000000046, -184.98000000000047, -185.73800000000048, -186.4960000000005, -187.2540000000005, -188.0120000000005, -188.77000000000052, -189.52800000000053, -190.28600000000054, -191.04400000000055, -191.80200000000056, -192.56000000000057, -193.31800000000058, -194.0760000000006, -194.8340000000006, -195.5920000000006, -196.35000000000062, -197.10800000000063, -197.86600000000064, -198.62400000000065, -199.38200000000066, -200.14000000000067, -200.89800000000068, -201.6560000000007, -202.4140000000007, -203.1720000000007, -203.93000000000072, -204.68800000000073]}"	"{\\"tm\\": [\\"2022-04-08\\", \\"2022-04-09\\", \\"2022-04-10\\", \\"2022-04-11\\", \\"2022-04-12\\", \\"2022-04-13\\", \\"2022-04-14\\", \\"2022-04-15\\", \\"2022-04-16\\", \\"2022-04-17\\", \\"2022-04-18\\", \\"2022-04-19\\", \\"2022-04-20\\", \\"2022-04-21\\", \\"2022-04-22\\", \\"2022-04-23\\", \\"2022-04-24\\", \\"2022-04-25\\", \\"2022-04-26\\", \\"2022-04-27\\", \\"2022-04-28\\", \\"2022-04-29\\", \\"2022-04-30\\", \\"2022-05-01\\", \\"2022-05-02\\", \\"2022-05-03\\", \\"2022-05-04\\", \\"2022-05-05\\", \\"2022-05-06\\", \\"2022-05-07\\", \\"2022-05-08\\"], \\"bal\\": [23.444522777777777, 5.252522777777777, -12.939477222222223, -31.131477222222223, -49.32347722222222, -67.51547722222222, -85.70747722222222, -103.89947722222223, -122.09147722222224, -140.28347722222225, -158.47547722222225, -176.66747722222226, -194.85947722222227, -213.05147722222227, -231.24347722222228, -249.4354772222223, -267.6274772222223, -285.8194772222223, -304.0114772222223, -322.2034772222223, -340.3954772222223, -358.58747722222233, -376.77947722222234, -384.97147722222235, -403.16347722222235, -421.35547722222236, -439.54747722222237, -457.7394772222224, -475.9314772222224, -494.1234772222224, -512.3154772222224]}"	"{\\"tm\\": [\\"2022-04\\", \\"2022-04\\", \\"2022-05\\", \\"2022-06\\", \\"2022-07\\", \\"2022-08\\", \\"2022-09\\", \\"2022-10\\", \\"2022-11\\", \\"2022-12\\", \\"2023-01\\", \\"2023-02\\", \\"2023-03\\", \\"2023-04\\"], \\"bal\\": [-366.77947722222234, -930.7314772222223, -1494.6834772222223, -2058.635477222222, -2622.5874772222223, -3186.5394772222226, -3750.491477222223, -4314.443477222223, -4878.395477222223, -5442.3474772222235, -6006.299477222224, -6570.251477222224, -7134.203477222224, -7698.155477222224]}"	"{\\"tm\\": [\\"2022-04-07T12:00\\", \\"2022-04-07T13:00\\", \\"2022-04-07T14:00\\", \\"2022-04-07T15:00\\", \\"2022-04-07T16:00\\", \\"2022-04-07T17:00\\", \\"2022-04-07T18:00\\", \\"2022-04-07T19:00\\", \\"2022-04-07T20:00\\", \\"2022-04-07T21:00\\", \\"2022-04-07T22:00\\", \\"2022-04-07T23:00\\", \\"2022-04-08T00:00\\", \\"2022-04-08T01:00\\", \\"2022-04-08T02:00\\", \\"2022-04-08T03:00\\", \\"2022-04-08T04:00\\", \\"2022-04-08T05:00\\", \\"2022-04-08T06:00\\", \\"2022-04-08T07:00\\", \\"2022-04-08T08:00\\", \\"2022-04-08T09:00\\", \\"2022-04-08T10:00\\", \\"2022-04-08T11:00\\", \\"2022-04-08T12:00\\", \\"2022-04-08T13:00\\", \\"2022-04-08T14:00\\", \\"2022-04-08T15:00\\", \\"2022-04-08T16:00\\", \\"2022-04-08T17:00\\", \\"2022-04-08T18:00\\", \\"2022-04-08T19:00\\", \\"2022-04-08T20:00\\", \\"2022-04-08T21:00\\", \\"2022-04-08T22:00\\", \\"2022-04-08T23:00\\", \\"2022-04-09T00:00\\", \\"2022-04-09T01:00\\", \\"2022-04-09T02:00\\", \\"2022-04-09T03:00\\", \\"2022-04-09T04:00\\", \\"2022-04-09T05:00\\", \\"2022-04-09T06:00\\", \\"2022-04-09T07:00\\", \\"2022-04-09T08:00\\", \\"2022-04-09T09:00\\", \\"2022-04-09T10:00\\", \\"2022-04-09T11:00\\", \\"2022-04-09T12:00\\", \\"2022-04-09T13:00\\", \\"2022-04-09T14:00\\", \\"2022-04-09T15:00\\", \\"2022-04-09T16:00\\", \\"2022-04-09T17:00\\", \\"2022-04-09T18:00\\", \\"2022-04-09T19:00\\", \\"2022-04-09T20:00\\", \\"2022-04-09T21:00\\", \\"2022-04-09T22:00\\", \\"2022-04-09T23:00\\", \\"2022-04-10T00:00\\", \\"2022-04-10T01:00\\", \\"2022-04-10T02:00\\", \\"2022-04-10T03:00\\", \\"2022-04-10T04:00\\", \\"2022-04-10T05:00\\", \\"2022-04-10T06:00\\", \\"2022-04-10T07:00\\", \\"2022-04-10T08:00\\", \\"2022-04-10T09:00\\", \\"2022-04-10T10:00\\", \\"2022-04-10T11:00\\", \\"2022-04-10T12:00\\", \\"2022-04-10T13:00\\", \\"2022-04-10T14:00\\", \\"2022-04-10T15:00\\", \\"2022-04-10T16:00\\", \\"2022-04-10T17:00\\", \\"2022-04-10T18:00\\", \\"2022-04-10T19:00\\", \\"2022-04-10T20:00\\", \\"2022-04-10T21:00\\", \\"2022-04-10T22:00\\", \\"2022-04-10T23:00\\", \\"2022-04-11T00:00\\", \\"2022-04-11T01:00\\", \\"2022-04-11T02:00\\", \\"2022-04-11T03:00\\", \\"2022-04-11T04:00\\", \\"2022-04-11T05:00\\", \\"2022-04-11T06:00\\", \\"2022-04-11T07:00\\", \\"2022-04-11T08:00\\", \\"2022-04-11T09:00\\", \\"2022-04-11T10:00\\", \\"2022-04-11T11:00\\", \\"2022-04-11T12:00\\", \\"2022-04-11T13:00\\", \\"2022-04-11T14:00\\", \\"2022-04-11T15:00\\", \\"2022-04-11T16:00\\", \\"2022-04-11T17:00\\", \\"2022-04-11T18:00\\", \\"2022-04-11T19:00\\", \\"2022-04-11T20:00\\", \\"2022-04-11T21:00\\", \\"2022-04-11T22:00\\", \\"2022-04-11T23:00\\", \\"2022-04-12T00:00\\", \\"2022-04-12T01:00\\", \\"2022-04-12T02:00\\", \\"2022-04-12T03:00\\", \\"2022-04-12T04:00\\", \\"2022-04-12T05:00\\", \\"2022-04-12T06:00\\", \\"2022-04-12T07:00\\", \\"2022-04-12T08:00\\", \\"2022-04-12T09:00\\", \\"2022-04-12T10:00\\", \\"2022-04-12T11:00\\", \\"2022-04-12T12:00\\", \\"2022-04-12T13:00\\", \\"2022-04-12T14:00\\", \\"2022-04-12T15:00\\", \\"2022-04-12T16:00\\", \\"2022-04-12T17:00\\", \\"2022-04-12T18:00\\", \\"2022-04-12T19:00\\", \\"2022-04-12T20:00\\", \\"2022-04-12T21:00\\", \\"2022-04-12T22:00\\", \\"2022-04-12T23:00\\", \\"2022-04-13T00:00\\", \\"2022-04-13T01:00\\", \\"2022-04-13T02:00\\", \\"2022-04-13T03:00\\", \\"2022-04-13T04:00\\", \\"2022-04-13T05:00\\", \\"2022-04-13T06:00\\", \\"2022-04-13T07:00\\", \\"2022-04-13T08:00\\", \\"2022-04-13T09:00\\", \\"2022-04-13T10:00\\", \\"2022-04-13T11:00\\", \\"2022-04-13T12:00\\", \\"2022-04-13T13:00\\", \\"2022-04-13T14:00\\", \\"2022-04-13T15:00\\", \\"2022-04-13T16:00\\", \\"2022-04-13T17:00\\", \\"2022-04-13T18:00\\", \\"2022-04-13T19:00\\", \\"2022-04-13T20:00\\", \\"2022-04-13T21:00\\", \\"2022-04-13T22:00\\", \\"2022-04-13T23:00\\", \\"2022-04-14T00:00\\", \\"2022-04-14T01:00\\", \\"2022-04-14T02:00\\", \\"2022-04-14T03:00\\", \\"2022-04-14T04:00\\", \\"2022-04-14T05:00\\", \\"2022-04-14T06:00\\", \\"2022-04-14T07:00\\", \\"2022-04-14T08:00\\", \\"2022-04-14T09:00\\", \\"2022-04-14T10:00\\", \\"2022-04-14T11:00\\", \\"2022-04-14T12:00\\", \\"2022-04-14T13:00\\", \\"2022-04-14T14:00\\", \\"2022-04-14T15:00\\", \\"2022-04-14T16:00\\", \\"2022-04-14T17:00\\", \\"2022-04-14T18:00\\", \\"2022-04-14T19:00\\", \\"2022-04-14T20:00\\", \\"2022-04-14T21:00\\", \\"2022-04-14T22:00\\", \\"2022-04-14T23:00\\", \\"2022-04-15T00:00\\", \\"2022-04-15T01:00\\", \\"2022-04-15T02:00\\", \\"2022-04-15T03:00\\", \\"2022-04-15T04:00\\", \\"2022-04-15T05:00\\", \\"2022-04-15T06:00\\", \\"2022-04-15T07:00\\", \\"2022-04-15T08:00\\", \\"2022-04-15T09:00\\", \\"2022-04-15T10:00\\", \\"2022-04-15T11:00\\", \\"2022-04-15T12:00\\", \\"2022-04-15T13:00\\", \\"2022-04-15T14:00\\", \\"2022-04-15T15:00\\", \\"2022-04-15T16:00\\", \\"2022-04-15T17:00\\", \\"2022-04-15T18:00\\", \\"2022-04-15T19:00\\", \\"2022-04-15T20:00\\", \\"2022-04-15T21:00\\", \\"2022-04-15T22:00\\", \\"2022-04-15T23:00\\", \\"2022-04-16T00:00\\", \\"2022-04-16T01:00\\", \\"2022-04-16T02:00\\", \\"2022-04-16T03:00\\", \\"2022-04-16T04:00\\", \\"2022-04-16T05:00\\", \\"2022-04-16T06:00\\", \\"2022-04-16T07:00\\", \\"2022-04-16T08:00\\", \\"2022-04-16T09:00\\", \\"2022-04-16T10:00\\", \\"2022-04-16T11:00\\", \\"2022-04-16T12:00\\", \\"2022-04-16T13:00\\", \\"2022-04-16T14:00\\", \\"2022-04-16T15:00\\", \\"2022-04-16T16:00\\", \\"2022-04-16T17:00\\", \\"2022-04-16T18:00\\", \\"2022-04-16T19:00\\", \\"2022-04-16T20:00\\", \\"2022-04-16T21:00\\", \\"2022-04-16T22:00\\", \\"2022-04-16T23:00\\", \\"2022-04-17T00:00\\", \\"2022-04-17T01:00\\", \\"2022-04-17T02:00\\", \\"2022-04-17T03:00\\", \\"2022-04-17T04:00\\", \\"2022-04-17T05:00\\", \\"2022-04-17T06:00\\", \\"2022-04-17T07:00\\", \\"2022-04-17T08:00\\", \\"2022-04-17T09:00\\", \\"2022-04-17T10:00\\", \\"2022-04-17T11:00\\", \\"2022-04-17T12:00\\", \\"2022-04-17T13:00\\", \\"2022-04-17T14:00\\", \\"2022-04-17T15:00\\", \\"2022-04-17T16:00\\", \\"2022-04-17T17:00\\", \\"2022-04-17T18:00\\", \\"2022-04-17T19:00\\", \\"2022-04-17T20:00\\", \\"2022-04-17T21:00\\", \\"2022-04-17T22:00\\", \\"2022-04-17T23:00\\", \\"2022-04-18T00:00\\", \\"2022-04-18T01:00\\", \\"2022-04-18T02:00\\", \\"2022-04-18T03:00\\", \\"2022-04-18T04:00\\", \\"2022-04-18T05:00\\", \\"2022-04-18T06:00\\", \\"2022-04-18T07:00\\", \\"2022-04-18T08:00\\", \\"2022-04-18T09:00\\", \\"2022-04-18T10:00\\", \\"2022-04-18T11:00\\", \\"2022-04-18T12:00\\", \\"2022-04-18T13:00\\", \\"2022-04-18T14:00\\", \\"2022-04-18T15:00\\", \\"2022-04-18T16:00\\", \\"2022-04-18T17:00\\", \\"2022-04-18T18:00\\", \\"2022-04-18T19:00\\", \\"2022-04-18T20:00\\", \\"2022-04-18T21:00\\", \\"2022-04-18T22:00\\", \\"2022-04-18T23:00\\", \\"2022-04-19T00:00\\", \\"2022-04-19T01:00\\", \\"2022-04-19T02:00\\", \\"2022-04-19T03:00\\", \\"2022-04-19T04:00\\", \\"2022-04-19T05:00\\", \\"2022-04-19T06:00\\", \\"2022-04-19T07:00\\", \\"2022-04-19T08:00\\", \\"2022-04-19T09:00\\", \\"2022-04-19T10:00\\", \\"2022-04-19T11:00\\", \\"2022-04-19T12:00\\", \\"2022-04-19T13:00\\", \\"2022-04-19T14:00\\", \\"2022-04-19T15:00\\", \\"2022-04-19T16:00\\", \\"2022-04-19T17:00\\", \\"2022-04-19T18:00\\", \\"2022-04-19T19:00\\", \\"2022-04-19T20:00\\", \\"2022-04-19T21:00\\", \\"2022-04-19T22:00\\", \\"2022-04-19T23:00\\", \\"2022-04-20T00:00\\", \\"2022-04-20T01:00\\", \\"2022-04-20T02:00\\", \\"2022-04-20T03:00\\", \\"2022-04-20T04:00\\", \\"2022-04-20T05:00\\", \\"2022-04-20T06:00\\", \\"2022-04-20T07:00\\", \\"2022-04-20T08:00\\", \\"2022-04-20T09:00\\", \\"2022-04-20T10:00\\", \\"2022-04-20T11:00\\", \\"2022-04-20T12:00\\", \\"2022-04-20T13:00\\", \\"2022-04-20T14:00\\", \\"2022-04-20T15:00\\", \\"2022-04-20T16:00\\", \\"2022-04-20T17:00\\", \\"2022-04-20T18:00\\", \\"2022-04-20T19:00\\", \\"2022-04-20T20:00\\", \\"2022-04-20T21:00\\", \\"2022-04-20T22:00\\", \\"2022-04-20T23:00\\", \\"2022-04-21T00:00\\", \\"2022-04-21T01:00\\", \\"2022-04-21T02:00\\", \\"2022-04-21T03:00\\", \\"2022-04-21T04:00\\", \\"2022-04-21T05:00\\", \\"2022-04-21T06:00\\", \\"2022-04-21T07:00\\", \\"2022-04-21T08:00\\", \\"2022-04-21T09:00\\", \\"2022-04-21T10:00\\", \\"2022-04-21T11:00\\"], \\"bal\\": [49.242, 48.483999999999995, 47.72599999999999, 46.96799999999999, 46.20999999999999, 45.451999999999984, 44.69399999999998, 43.93599999999998, 43.177999999999976, 42.41999999999997, 41.66199999999997, 40.90399999999997, 40.145999999999965, 39.38799999999996, 38.62999999999996, 37.87199999999996, 37.113999999999955, 36.35599999999995, 35.59799999999995, 34.83999999999995, 34.081999999999944, 33.32399999999994, 32.56599999999994, 31.80799999999994, 31.04999999999994, 30.29199999999994, 29.533999999999942, 28.775999999999943, 28.017999999999944, 27.259999999999945, 26.501999999999946, 25.743999999999946, 24.985999999999947, 24.22799999999995, 23.46999999999995, 22.71199999999995, 21.95399999999995, 21.19599999999995, 20.437999999999953, 19.679999999999954, 18.921999999999954, 18.163999999999955, 17.405999999999956, 16.647999999999957, 15.889999999999958, 15.131999999999959, 14.37399999999996, 13.61599999999996, 12.857999999999961, 12.099999999999962, 11.341999999999963, 10.583999999999964, 9.825999999999965, 9.067999999999966, 8.309999999999967, 7.551999999999967, 6.793999999999967, 6.035999999999967, 5.277999999999967, 4.519999999999967, 3.7619999999999667, 3.0039999999999667, 2.2459999999999667, 1.4879999999999667, 0.7299999999999667, -0.02800000000003333, -0.7860000000000333, -1.5440000000000333, -2.3020000000000334, -3.0600000000000334, -3.8180000000000334, -4.576000000000033, -5.334000000000033, -6.092000000000033, -6.850000000000033, -7.608000000000033, -8.366000000000033, -9.124000000000034, -9.882000000000033, -10.640000000000033, -11.398000000000032, -12.15600000000003, -12.91400000000003, -13.672000000000029, -14.430000000000028, -15.188000000000027, -15.946000000000026, -16.704000000000025, -17.462000000000025, -18.220000000000024, -18.978000000000023, -19.736000000000022, -20.49400000000002, -21.25200000000002, -22.01000000000002, -22.76800000000002, -23.526000000000018, -24.284000000000017, -25.042000000000016, -25.800000000000015, -26.558000000000014, -27.316000000000013, -28.074000000000012, -28.83200000000001, -29.59000000000001, -30.34800000000001, -31.10600000000001, -31.864000000000008, -32.62200000000001, -33.38000000000001, -34.13800000000001, -34.896000000000015, -35.65400000000002, -36.41200000000002, -37.17000000000002, -37.928000000000026, -38.68600000000003, -39.44400000000003, -40.202000000000034, -40.960000000000036, -41.71800000000004, -42.47600000000004, -43.234000000000044, -43.99200000000005, -44.75000000000005, -45.50800000000005, -46.266000000000055, -47.02400000000006, -47.78200000000006, -48.54000000000006, -49.298000000000066, -50.05600000000007, -50.81400000000007, -51.572000000000074, -52.33000000000008, -53.08800000000008, -53.84600000000008, -54.604000000000084, -55.36200000000009, -56.12000000000009, -56.87800000000009, -57.636000000000095, -58.3940000000001, -59.1520000000001, -59.9100000000001, -60.668000000000106, -61.42600000000011, -62.18400000000011, -62.942000000000114, -63.70000000000012, -64.45800000000011, -65.21600000000011, -65.9740000000001, -66.7320000000001, -67.4900000000001, -68.24800000000009, -69.00600000000009, -69.76400000000008, -70.52200000000008, -71.28000000000007, -72.03800000000007, -72.79600000000006, -73.55400000000006, -74.31200000000005, -75.07000000000005, -75.82800000000005, -76.58600000000004, -77.34400000000004, -78.10200000000003, -78.86000000000003, -79.61800000000002, -80.37600000000002, -81.13400000000001, -81.89200000000001, -82.65, -83.408, -84.166, -84.92399999999999, -85.68199999999999, -86.43999999999998, -87.19799999999998, -87.95599999999997, -88.71399999999997, -89.47199999999997, -90.22999999999996, -90.98799999999996, -91.74599999999995, -92.50399999999995, -93.26199999999994, -94.01999999999994, -94.77799999999993, -95.53599999999993, -96.29399999999993, -97.05199999999992, -97.80999999999992, -98.56799999999991, -99.32599999999991, -100.0839999999999, -100.8419999999999, -101.5999999999999, -102.35799999999989, -103.11599999999989, -103.87399999999988, -104.63199999999988, -105.38999999999987, -106.14799999999987, -106.90599999999986, -107.66399999999986, -108.42199999999985, -109.17999999999985, -109.93799999999985, -110.69599999999984, -111.45399999999984, -112.21199999999983, -112.96999999999983, -113.72799999999982, -114.48599999999982, -115.24399999999982, -116.00199999999981, -116.7599999999998, -117.5179999999998, -118.2759999999998, -119.03399999999979, -119.79199999999979, -120.54999999999978, -121.30799999999978, -122.06599999999978, -122.82399999999977, -123.58199999999977, -124.33999999999976, -125.09799999999976, -125.85599999999975, -126.61399999999975, -127.37199999999974, -128.12999999999974, -128.88799999999975, -129.64599999999976, -130.40399999999977, -131.16199999999978, -131.9199999999998, -132.6779999999998, -133.4359999999998, -134.19399999999982, -134.95199999999983, -135.70999999999984, -136.46799999999985, -137.22599999999986, -137.98399999999987, -138.74199999999988, -139.4999999999999, -140.2579999999999, -141.0159999999999, -141.77399999999992, -142.53199999999993, -143.28999999999994, -144.04799999999994, -144.80599999999995, -145.56399999999996, -146.32199999999997, -147.07999999999998, -147.838, -148.596, -149.354, -150.11200000000002, -150.87000000000003, -151.62800000000004, -152.38600000000005, -153.14400000000006, -153.90200000000007, -154.66000000000008, -155.4180000000001, -156.1760000000001, -156.9340000000001, -157.69200000000012, -158.45000000000013, -159.20800000000014, -159.96600000000015, -160.72400000000016, -161.48200000000017, -162.24000000000018, -162.9980000000002, -163.7560000000002, -164.5140000000002, -165.27200000000022, -166.03000000000023, -166.78800000000024, -167.54600000000025, -168.30400000000026, -169.06200000000027, -169.82000000000028, -170.5780000000003, -171.3360000000003, -172.0940000000003, -172.85200000000032, -173.61000000000033, -174.36800000000034, -175.12600000000035, -175.88400000000036, -176.64200000000037, -177.40000000000038, -178.15800000000038, -178.9160000000004, -179.6740000000004, -180.43200000000041, -181.19000000000042, -181.94800000000043, -182.70600000000044, -183.46400000000045, -184.22200000000046, -184.98000000000047, -185.73800000000048, -186.4960000000005, -187.2540000000005, -188.0120000000005, -188.77000000000052, -189.52800000000053, -190.28600000000054, -191.04400000000055, -191.80200000000056, -192.56000000000057, -193.31800000000058, -194.0760000000006, -194.8340000000006, -195.5920000000006, -196.35000000000062, -197.10800000000063, -197.86600000000064, -198.62400000000065, -199.38200000000066, -200.14000000000067, -200.89800000000068, -201.6560000000007, -202.4140000000007, -203.1720000000007, -203.93000000000072, -204.68800000000073]}"	"{\\"tm\\": [\\"2022-04-08\\", \\"2022-04-09\\", \\"2022-04-10\\", \\"2022-04-11\\", \\"2022-04-12\\", \\"2022-04-13\\", \\"2022-04-14\\", \\"2022-04-15\\", \\"2022-04-16\\", \\"2022-04-17\\", \\"2022-04-18\\", \\"2022-04-19\\", \\"2022-04-20\\", \\"2022-04-21\\", \\"2022-04-22\\", \\"2022-04-23\\", \\"2022-04-24\\", \\"2022-04-25\\", \\"2022-04-26\\", \\"2022-04-27\\", \\"2022-04-28\\", \\"2022-04-29\\", \\"2022-04-30\\", \\"2022-05-01\\", \\"2022-05-02\\", \\"2022-05-03\\", \\"2022-05-04\\", \\"2022-05-05\\", \\"2022-05-06\\", \\"2022-05-07\\", \\"2022-05-08\\"], \\"bal\\": [23.444522777777777, 5.252522777777777, -12.939477222222223, -31.131477222222223, -49.32347722222222, -67.51547722222222, -85.70747722222222, -103.89947722222223, -122.09147722222224, -140.28347722222225, -158.47547722222225, -176.66747722222226, -194.85947722222227, -213.05147722222227, -231.24347722222228, -249.4354772222223, -267.6274772222223, -285.8194772222223, -304.0114772222223, -322.2034772222223, -340.3954772222223, -358.58747722222233, -376.77947722222234, -384.97147722222235, -403.16347722222235, -421.35547722222236, -439.54747722222237, -457.7394772222224, -475.9314772222224, -494.1234772222224, -512.3154772222224]}"	"{\\"tm\\": [\\"2022-04\\", \\"2022-04\\", \\"2022-05\\", \\"2022-06\\", \\"2022-07\\", \\"2022-08\\", \\"2022-09\\", \\"2022-10\\", \\"2022-11\\", \\"2022-12\\", \\"2023-01\\", \\"2023-02\\", \\"2023-03\\", \\"2023-04\\"], \\"bal\\": [-366.77947722222234, -930.7314772222223, -1494.6834772222223, -2058.635477222222, -2622.5874772222223, -3186.5394772222226, -3750.491477222223, -4314.443477222223, -4878.395477222223, -5442.3474772222235, -6006.299477222224, -6570.251477222224, -7134.203477222224, -7698.155477222224]}"	"{\\"tm\\": [\\"2022-04-07T12:00\\", \\"2022-04-07T13:00\\", \\"2022-04-07T14:00\\", \\"2022-04-07T15:00\\", \\"2022-04-07T16:00\\", \\"2022-04-07T17:00\\", \\"2022-04-07T18:00\\", \\"2022-04-07T19:00\\", \\"2022-04-07T20:00\\", \\"2022-04-07T21:00\\", \\"2022-04-07T22:00\\", \\"2022-04-07T23:00\\", \\"2022-04-08T00:00\\", \\"2022-04-08T01:00\\", \\"2022-04-08T02:00\\", \\"2022-04-08T03:00\\", \\"2022-04-08T04:00\\", \\"2022-04-08T05:00\\", \\"2022-04-08T06:00\\", \\"2022-04-08T07:00\\", \\"2022-04-08T08:00\\", \\"2022-04-08T09:00\\", \\"2022-04-08T10:00\\", \\"2022-04-08T11:00\\", \\"2022-04-08T12:00\\", \\"2022-04-08T13:00\\", \\"2022-04-08T14:00\\", \\"2022-04-08T15:00\\", \\"2022-04-08T16:00\\", \\"2022-04-08T17:00\\", \\"2022-04-08T18:00\\", \\"2022-04-08T19:00\\", \\"2022-04-08T20:00\\", \\"2022-04-08T21:00\\", \\"2022-04-08T22:00\\", \\"2022-04-08T23:00\\", \\"2022-04-09T00:00\\", \\"2022-04-09T01:00\\", \\"2022-04-09T02:00\\", \\"2022-04-09T03:00\\", \\"2022-04-09T04:00\\", \\"2022-04-09T05:00\\", \\"2022-04-09T06:00\\", \\"2022-04-09T07:00\\", \\"2022-04-09T08:00\\", \\"2022-04-09T09:00\\", \\"2022-04-09T10:00\\", \\"2022-04-09T11:00\\", \\"2022-04-09T12:00\\", \\"2022-04-09T13:00\\", \\"2022-04-09T14:00\\", \\"2022-04-09T15:00\\", \\"2022-04-09T16:00\\", \\"2022-04-09T17:00\\", \\"2022-04-09T18:00\\", \\"2022-04-09T19:00\\", \\"2022-04-09T20:00\\", \\"2022-04-09T21:00\\", \\"2022-04-09T22:00\\", \\"2022-04-09T23:00\\", \\"2022-04-10T00:00\\", \\"2022-04-10T01:00\\", \\"2022-04-10T02:00\\", \\"2022-04-10T03:00\\", \\"2022-04-10T04:00\\", \\"2022-04-10T05:00\\", \\"2022-04-10T06:00\\", \\"2022-04-10T07:00\\", \\"2022-04-10T08:00\\", \\"2022-04-10T09:00\\", \\"2022-04-10T10:00\\", \\"2022-04-10T11:00\\", \\"2022-04-10T12:00\\", \\"2022-04-10T13:00\\", \\"2022-04-10T14:00\\", \\"2022-04-10T15:00\\", \\"2022-04-10T16:00\\", \\"2022-04-10T17:00\\", \\"2022-04-10T18:00\\", \\"2022-04-10T19:00\\", \\"2022-04-10T20:00\\", \\"2022-04-10T21:00\\", \\"2022-04-10T22:00\\", \\"2022-04-10T23:00\\", \\"2022-04-11T00:00\\", \\"2022-04-11T01:00\\", \\"2022-04-11T02:00\\", \\"2022-04-11T03:00\\", \\"2022-04-11T04:00\\", \\"2022-04-11T05:00\\", \\"2022-04-11T06:00\\", \\"2022-04-11T07:00\\", \\"2022-04-11T08:00\\", \\"2022-04-11T09:00\\", \\"2022-04-11T10:00\\", \\"2022-04-11T11:00\\", \\"2022-04-11T12:00\\", \\"2022-04-11T13:00\\", \\"2022-04-11T14:00\\", \\"2022-04-11T15:00\\", \\"2022-04-11T16:00\\", \\"2022-04-11T17:00\\", \\"2022-04-11T18:00\\", \\"2022-04-11T19:00\\", \\"2022-04-11T20:00\\", \\"2022-04-11T21:00\\", \\"2022-04-11T22:00\\", \\"2022-04-11T23:00\\", \\"2022-04-12T00:00\\", \\"2022-04-12T01:00\\", \\"2022-04-12T02:00\\", \\"2022-04-12T03:00\\", \\"2022-04-12T04:00\\", \\"2022-04-12T05:00\\", \\"2022-04-12T06:00\\", \\"2022-04-12T07:00\\", \\"2022-04-12T08:00\\", \\"2022-04-12T09:00\\", \\"2022-04-12T10:00\\", \\"2022-04-12T11:00\\", \\"2022-04-12T12:00\\", \\"2022-04-12T13:00\\", \\"2022-04-12T14:00\\", \\"2022-04-12T15:00\\", \\"2022-04-12T16:00\\", \\"2022-04-12T17:00\\", \\"2022-04-12T18:00\\", \\"2022-04-12T19:00\\", \\"2022-04-12T20:00\\", \\"2022-04-12T21:00\\", \\"2022-04-12T22:00\\", \\"2022-04-12T23:00\\", \\"2022-04-13T00:00\\", \\"2022-04-13T01:00\\", \\"2022-04-13T02:00\\", \\"2022-04-13T03:00\\", \\"2022-04-13T04:00\\", \\"2022-04-13T05:00\\", \\"2022-04-13T06:00\\", \\"2022-04-13T07:00\\", \\"2022-04-13T08:00\\", \\"2022-04-13T09:00\\", \\"2022-04-13T10:00\\", \\"2022-04-13T11:00\\", \\"2022-04-13T12:00\\", \\"2022-04-13T13:00\\", \\"2022-04-13T14:00\\", \\"2022-04-13T15:00\\", \\"2022-04-13T16:00\\", \\"2022-04-13T17:00\\", \\"2022-04-13T18:00\\", \\"2022-04-13T19:00\\", \\"2022-04-13T20:00\\", \\"2022-04-13T21:00\\", \\"2022-04-13T22:00\\", \\"2022-04-13T23:00\\", \\"2022-04-14T00:00\\", \\"2022-04-14T01:00\\", \\"2022-04-14T02:00\\", \\"2022-04-14T03:00\\", \\"2022-04-14T04:00\\", \\"2022-04-14T05:00\\", \\"2022-04-14T06:00\\", \\"2022-04-14T07:00\\", \\"2022-04-14T08:00\\", \\"2022-04-14T09:00\\", \\"2022-04-14T10:00\\", \\"2022-04-14T11:00\\", \\"2022-04-14T12:00\\", \\"2022-04-14T13:00\\", \\"2022-04-14T14:00\\", \\"2022-04-14T15:00\\", \\"2022-04-14T16:00\\", \\"2022-04-14T17:00\\", \\"2022-04-14T18:00\\", \\"2022-04-14T19:00\\", \\"2022-04-14T20:00\\", \\"2022-04-14T21:00\\", \\"2022-04-14T22:00\\", \\"2022-04-14T23:00\\", \\"2022-04-15T00:00\\", \\"2022-04-15T01:00\\", \\"2022-04-15T02:00\\", \\"2022-04-15T03:00\\", \\"2022-04-15T04:00\\", \\"2022-04-15T05:00\\", \\"2022-04-15T06:00\\", \\"2022-04-15T07:00\\", \\"2022-04-15T08:00\\", \\"2022-04-15T09:00\\", \\"2022-04-15T10:00\\", \\"2022-04-15T11:00\\", \\"2022-04-15T12:00\\", \\"2022-04-15T13:00\\", \\"2022-04-15T14:00\\", \\"2022-04-15T15:00\\", \\"2022-04-15T16:00\\", \\"2022-04-15T17:00\\", \\"2022-04-15T18:00\\", \\"2022-04-15T19:00\\", \\"2022-04-15T20:00\\", \\"2022-04-15T21:00\\", \\"2022-04-15T22:00\\", \\"2022-04-15T23:00\\", \\"2022-04-16T00:00\\", \\"2022-04-16T01:00\\", \\"2022-04-16T02:00\\", \\"2022-04-16T03:00\\", \\"2022-04-16T04:00\\", \\"2022-04-16T05:00\\", \\"2022-04-16T06:00\\", \\"2022-04-16T07:00\\", \\"2022-04-16T08:00\\", \\"2022-04-16T09:00\\", \\"2022-04-16T10:00\\", \\"2022-04-16T11:00\\", \\"2022-04-16T12:00\\", \\"2022-04-16T13:00\\", \\"2022-04-16T14:00\\", \\"2022-04-16T15:00\\", \\"2022-04-16T16:00\\", \\"2022-04-16T17:00\\", \\"2022-04-16T18:00\\", \\"2022-04-16T19:00\\", \\"2022-04-16T20:00\\", \\"2022-04-16T21:00\\", \\"2022-04-16T22:00\\", \\"2022-04-16T23:00\\", \\"2022-04-17T00:00\\", \\"2022-04-17T01:00\\", \\"2022-04-17T02:00\\", \\"2022-04-17T03:00\\", \\"2022-04-17T04:00\\", \\"2022-04-17T05:00\\", \\"2022-04-17T06:00\\", \\"2022-04-17T07:00\\", \\"2022-04-17T08:00\\", \\"2022-04-17T09:00\\", \\"2022-04-17T10:00\\", \\"2022-04-17T11:00\\", \\"2022-04-17T12:00\\", \\"2022-04-17T13:00\\", \\"2022-04-17T14:00\\", \\"2022-04-17T15:00\\", \\"2022-04-17T16:00\\", \\"2022-04-17T17:00\\", \\"2022-04-17T18:00\\", \\"2022-04-17T19:00\\", \\"2022-04-17T20:00\\", \\"2022-04-17T21:00\\", \\"2022-04-17T22:00\\", \\"2022-04-17T23:00\\", \\"2022-04-18T00:00\\", \\"2022-04-18T01:00\\", \\"2022-04-18T02:00\\", \\"2022-04-18T03:00\\", \\"2022-04-18T04:00\\", \\"2022-04-18T05:00\\", \\"2022-04-18T06:00\\", \\"2022-04-18T07:00\\", \\"2022-04-18T08:00\\", \\"2022-04-18T09:00\\", \\"2022-04-18T10:00\\", \\"2022-04-18T11:00\\", \\"2022-04-18T12:00\\", \\"2022-04-18T13:00\\", \\"2022-04-18T14:00\\", \\"2022-04-18T15:00\\", \\"2022-04-18T16:00\\", \\"2022-04-18T17:00\\", \\"2022-04-18T18:00\\", \\"2022-04-18T19:00\\", \\"2022-04-18T20:00\\", \\"2022-04-18T21:00\\", \\"2022-04-18T22:00\\", \\"2022-04-18T23:00\\", \\"2022-04-19T00:00\\", \\"2022-04-19T01:00\\", \\"2022-04-19T02:00\\", \\"2022-04-19T03:00\\", \\"2022-04-19T04:00\\", \\"2022-04-19T05:00\\", \\"2022-04-19T06:00\\", \\"2022-04-19T07:00\\", \\"2022-04-19T08:00\\", \\"2022-04-19T09:00\\", \\"2022-04-19T10:00\\", \\"2022-04-19T11:00\\", \\"2022-04-19T12:00\\", \\"2022-04-19T13:00\\", \\"2022-04-19T14:00\\", \\"2022-04-19T15:00\\", \\"2022-04-19T16:00\\", \\"2022-04-19T17:00\\", \\"2022-04-19T18:00\\", \\"2022-04-19T19:00\\", \\"2022-04-19T20:00\\", \\"2022-04-19T21:00\\", \\"2022-04-19T22:00\\", \\"2022-04-19T23:00\\", \\"2022-04-20T00:00\\", \\"2022-04-20T01:00\\", \\"2022-04-20T02:00\\", \\"2022-04-20T03:00\\", \\"2022-04-20T04:00\\", \\"2022-04-20T05:00\\", \\"2022-04-20T06:00\\", \\"2022-04-20T07:00\\", \\"2022-04-20T08:00\\", \\"2022-04-20T09:00\\", \\"2022-04-20T10:00\\", \\"2022-04-20T11:00\\", \\"2022-04-20T12:00\\", \\"2022-04-20T13:00\\", \\"2022-04-20T14:00\\", \\"2022-04-20T15:00\\", \\"2022-04-20T16:00\\", \\"2022-04-20T17:00\\", \\"2022-04-20T18:00\\", \\"2022-04-20T19:00\\", \\"2022-04-20T20:00\\", \\"2022-04-20T21:00\\", \\"2022-04-20T22:00\\", \\"2022-04-20T23:00\\", \\"2022-04-21T00:00\\", \\"2022-04-21T01:00\\", \\"2022-04-21T02:00\\", \\"2022-04-21T03:00\\", \\"2022-04-21T04:00\\", \\"2022-04-21T05:00\\", \\"2022-04-21T06:00\\", \\"2022-04-21T07:00\\", \\"2022-04-21T08:00\\", \\"2022-04-21T09:00\\", \\"2022-04-21T10:00\\", \\"2022-04-21T11:00\\"], \\"bal\\": [49.242, 48.483999999999995, 47.72599999999999, 46.96799999999999, 46.20999999999999, 45.451999999999984, 44.69399999999998, 43.93599999999998, 43.177999999999976, 42.41999999999997, 41.66199999999997, 40.90399999999997, 40.145999999999965, 39.38799999999996, 38.62999999999996, 37.87199999999996, 37.113999999999955, 36.35599999999995, 35.59799999999995, 34.83999999999995, 34.081999999999944, 33.32399999999994, 32.56599999999994, 31.80799999999994, 31.04999999999994, 30.29199999999994, 29.533999999999942, 28.775999999999943, 28.017999999999944, 27.259999999999945, 26.501999999999946, 25.743999999999946, 24.985999999999947, 24.22799999999995, 23.46999999999995, 22.71199999999995, 21.95399999999995, 21.19599999999995, 20.437999999999953, 19.679999999999954, 18.921999999999954, 18.163999999999955, 17.405999999999956, 16.647999999999957, 15.889999999999958, 15.131999999999959, 14.37399999999996, 13.61599999999996, 12.857999999999961, 12.099999999999962, 11.341999999999963, 10.583999999999964, 9.825999999999965, 9.067999999999966, 8.309999999999967, 7.551999999999967, 6.793999999999967, 6.035999999999967, 5.277999999999967, 4.519999999999967, 3.7619999999999667, 3.0039999999999667, 2.2459999999999667, 1.4879999999999667, 0.7299999999999667, -0.02800000000003333, -0.7860000000000333, -1.5440000000000333, -2.3020000000000334, -3.0600000000000334, -3.8180000000000334, -4.576000000000033, -5.334000000000033, -6.092000000000033, -6.850000000000033, -7.608000000000033, -8.366000000000033, -9.124000000000034, -9.882000000000033, -10.640000000000033, -11.398000000000032, -12.15600000000003, -12.91400000000003, -13.672000000000029, -14.430000000000028, -15.188000000000027, -15.946000000000026, -16.704000000000025, -17.462000000000025, -18.220000000000024, -18.978000000000023, -19.736000000000022, -20.49400000000002, -21.25200000000002, -22.01000000000002, -22.76800000000002, -23.526000000000018, -24.284000000000017, -25.042000000000016, -25.800000000000015, -26.558000000000014, -27.316000000000013, -28.074000000000012, -28.83200000000001, -29.59000000000001, -30.34800000000001, -31.10600000000001, -31.864000000000008, -32.62200000000001, -33.38000000000001, -34.13800000000001, -34.896000000000015, -35.65400000000002, -36.41200000000002, -37.17000000000002, -37.928000000000026, -38.68600000000003, -39.44400000000003, -40.202000000000034, -40.960000000000036, -41.71800000000004, -42.47600000000004, -43.234000000000044, -43.99200000000005, -44.75000000000005, -45.50800000000005, -46.266000000000055, -47.02400000000006, -47.78200000000006, -48.54000000000006, -49.298000000000066, -50.05600000000007, -50.81400000000007, -51.572000000000074, -52.33000000000008, -53.08800000000008, -53.84600000000008, -54.604000000000084, -55.36200000000009, -56.12000000000009, -56.87800000000009, -57.636000000000095, -58.3940000000001, -59.1520000000001, -59.9100000000001, -60.668000000000106, -61.42600000000011, -62.18400000000011, -62.942000000000114, -63.70000000000012, -64.45800000000011, -65.21600000000011, -65.9740000000001, -66.7320000000001, -67.4900000000001, -68.24800000000009, -69.00600000000009, -69.76400000000008, -70.52200000000008, -71.28000000000007, -72.03800000000007, -72.79600000000006, -73.55400000000006, -74.31200000000005, -75.07000000000005, -75.82800000000005, -76.58600000000004, -77.34400000000004, -78.10200000000003, -78.86000000000003, -79.61800000000002, -80.37600000000002, -81.13400000000001, -81.89200000000001, -82.65, -83.408, -84.166, -84.92399999999999, -85.68199999999999, -86.43999999999998, -87.19799999999998, -87.95599999999997, -88.71399999999997, -89.47199999999997, -90.22999999999996, -90.98799999999996, -91.74599999999995, -92.50399999999995, -93.26199999999994, -94.01999999999994, -94.77799999999993, -95.53599999999993, -96.29399999999993, -97.05199999999992, -97.80999999999992, -98.56799999999991, -99.32599999999991, -100.0839999999999, -100.8419999999999, -101.5999999999999, -102.35799999999989, -103.11599999999989, -103.87399999999988, -104.63199999999988, -105.38999999999987, -106.14799999999987, -106.90599999999986, -107.66399999999986, -108.42199999999985, -109.17999999999985, -109.93799999999985, -110.69599999999984, -111.45399999999984, -112.21199999999983, -112.96999999999983, -113.72799999999982, -114.48599999999982, -115.24399999999982, -116.00199999999981, -116.7599999999998, -117.5179999999998, -118.2759999999998, -119.03399999999979, -119.79199999999979, -120.54999999999978, -121.30799999999978, -122.06599999999978, -122.82399999999977, -123.58199999999977, -124.33999999999976, -125.09799999999976, -125.85599999999975, -126.61399999999975, -127.37199999999974, -128.12999999999974, -128.88799999999975, -129.64599999999976, -130.40399999999977, -131.16199999999978, -131.9199999999998, -132.6779999999998, -133.4359999999998, -134.19399999999982, -134.95199999999983, -135.70999999999984, -136.46799999999985, -137.22599999999986, -137.98399999999987, -138.74199999999988, -139.4999999999999, -140.2579999999999, -141.0159999999999, -141.77399999999992, -142.53199999999993, -143.28999999999994, -144.04799999999994, -144.80599999999995, -145.56399999999996, -146.32199999999997, -147.07999999999998, -147.838, -148.596, -149.354, -150.11200000000002, -150.87000000000003, -151.62800000000004, -152.38600000000005, -153.14400000000006, -153.90200000000007, -154.66000000000008, -155.4180000000001, -156.1760000000001, -156.9340000000001, -157.69200000000012, -158.45000000000013, -159.20800000000014, -159.96600000000015, -160.72400000000016, -161.48200000000017, -162.24000000000018, -162.9980000000002, -163.7560000000002, -164.5140000000002, -165.27200000000022, -166.03000000000023, -166.78800000000024, -167.54600000000025, -168.30400000000026, -169.06200000000027, -169.82000000000028, -170.5780000000003, -171.3360000000003, -172.0940000000003, -172.85200000000032, -173.61000000000033, -174.36800000000034, -175.12600000000035, -175.88400000000036, -176.64200000000037, -177.40000000000038, -178.15800000000038, -178.9160000000004, -179.6740000000004, -180.43200000000041, -181.19000000000042, -181.94800000000043, -182.70600000000044, -183.46400000000045, -184.22200000000046, -184.98000000000047, -185.73800000000048, -186.4960000000005, -187.2540000000005, -188.0120000000005, -188.77000000000052, -189.52800000000053, -190.28600000000054, -191.04400000000055, -191.80200000000056, -192.56000000000057, -193.31800000000058, -194.0760000000006, -194.8340000000006, -195.5920000000006, -196.35000000000062, -197.10800000000063, -197.86600000000064, -198.62400000000065, -199.38200000000066, -200.14000000000067, -200.89800000000068, -201.6560000000007, -202.4140000000007, -203.1720000000007, -203.93000000000072, -204.68800000000073]}"	"{\\"tm\\": [\\"2022-04-08\\", \\"2022-04-09\\", \\"2022-04-10\\", \\"2022-04-11\\", \\"2022-04-12\\", \\"2022-04-13\\", \\"2022-04-14\\", \\"2022-04-15\\", \\"2022-04-16\\", \\"2022-04-17\\", \\"2022-04-18\\", \\"2022-04-19\\", \\"2022-04-20\\", \\"2022-04-21\\", \\"2022-04-22\\", \\"2022-04-23\\", \\"2022-04-24\\", \\"2022-04-25\\", \\"2022-04-26\\", \\"2022-04-27\\", \\"2022-04-28\\", \\"2022-04-29\\", \\"2022-04-30\\", \\"2022-05-01\\", \\"2022-05-02\\", \\"2022-05-03\\", \\"2022-05-04\\", \\"2022-05-05\\", \\"2022-05-06\\", \\"2022-05-07\\", \\"2022-05-08\\"], \\"bal\\": [23.444522777777777, 5.252522777777777, -12.939477222222223, -31.131477222222223, -49.32347722222222, -67.51547722222222, -85.70747722222222, -103.89947722222223, -122.09147722222224, -140.28347722222225, -158.47547722222225, -176.66747722222226, -194.85947722222227, -213.05147722222227, -231.24347722222228, -249.4354772222223, -267.6274772222223, -285.8194772222223, -304.0114772222223, -322.2034772222223, -340.3954772222223, -358.58747722222233, -376.77947722222234, -384.97147722222235, -403.16347722222235, -421.35547722222236, -439.54747722222237, -457.7394772222224, -475.9314772222224, -494.1234772222224, -512.3154772222224]}"	"{\\"tm\\": [\\"2022-04\\", \\"2022-04\\", \\"2022-05\\", \\"2022-06\\", \\"2022-07\\", \\"2022-08\\", \\"2022-09\\", \\"2022-10\\", \\"2022-11\\", \\"2022-12\\", \\"2023-01\\", \\"2023-02\\", \\"2023-03\\", \\"2023-04\\"], \\"bal\\": [-366.77947722222234, -930.7314772222223, -1494.6834772222223, -2058.635477222222, -2622.5874772222223, -3186.5394772222226, -3750.491477222223, -4314.443477222223, -4878.395477222223, -5442.3474772222235, -6006.299477222224, -6570.251477222224, -7134.203477222224, -7698.155477222224]}"	3
1692aada-8f04-4107-a6a5-ae5d46d90123	Developers	support team	sps.sliderule@gmail.com	500.00	100.00	500.00	2022-04-07 12:55:48.879955+00	2022-04-07 19:30:09.760752+00	0.306	0.226	2	2	2	2	0.758	0.758	0.758	2022-05-05 07:07:59.364456+00	2022-05-05 07:07:59.365584+00	2022-05-05 07:07:59.366554+00	2022-04-07 12:55:48.880021+00	2022-04-07 12:55:48.880027+00	"{\\"tm\\": [\\"2022-04-07T12:00\\", \\"2022-04-07T13:00\\", \\"2022-04-07T14:00\\", \\"2022-04-07T15:00\\", \\"2022-04-07T16:00\\", \\"2022-04-07T17:00\\", \\"2022-04-07T18:00\\", \\"2022-04-07T19:00\\", \\"2022-04-07T20:00\\", \\"2022-04-07T21:00\\", \\"2022-04-07T22:00\\", \\"2022-04-07T23:00\\", \\"2022-04-08T00:00\\", \\"2022-04-08T01:00\\", \\"2022-04-08T02:00\\", \\"2022-04-08T03:00\\", \\"2022-04-08T04:00\\", \\"2022-04-08T05:00\\", \\"2022-04-08T06:00\\", \\"2022-04-08T07:00\\", \\"2022-04-08T08:00\\", \\"2022-04-08T09:00\\", \\"2022-04-08T10:00\\", \\"2022-04-08T11:00\\", \\"2022-04-08T12:00\\", \\"2022-04-08T13:00\\", \\"2022-04-08T14:00\\", \\"2022-04-08T15:00\\", \\"2022-04-08T16:00\\", \\"2022-04-08T17:00\\", \\"2022-04-08T18:00\\", \\"2022-04-08T19:00\\", \\"2022-04-08T20:00\\", \\"2022-04-08T21:00\\", \\"2022-04-08T22:00\\", \\"2022-04-08T23:00\\", \\"2022-04-09T00:00\\", \\"2022-04-09T01:00\\", \\"2022-04-09T02:00\\", \\"2022-04-09T03:00\\", \\"2022-04-09T04:00\\", \\"2022-04-09T05:00\\", \\"2022-04-09T06:00\\", \\"2022-04-09T07:00\\", \\"2022-04-09T08:00\\", \\"2022-04-09T09:00\\", \\"2022-04-09T10:00\\", \\"2022-04-09T11:00\\", \\"2022-04-09T12:00\\", \\"2022-04-09T13:00\\", \\"2022-04-09T14:00\\", \\"2022-04-09T15:00\\", \\"2022-04-09T16:00\\", \\"2022-04-09T17:00\\", \\"2022-04-09T18:00\\", \\"2022-04-09T19:00\\", \\"2022-04-09T20:00\\", \\"2022-04-09T21:00\\", \\"2022-04-09T22:00\\", \\"2022-04-09T23:00\\", \\"2022-04-10T00:00\\", \\"2022-04-10T01:00\\", \\"2022-04-10T02:00\\", \\"2022-04-10T03:00\\", \\"2022-04-10T04:00\\", \\"2022-04-10T05:00\\", \\"2022-04-10T06:00\\", \\"2022-04-10T07:00\\", \\"2022-04-10T08:00\\", \\"2022-04-10T09:00\\", \\"2022-04-10T10:00\\", \\"2022-04-10T11:00\\", \\"2022-04-10T12:00\\", \\"2022-04-10T13:00\\", \\"2022-04-10T14:00\\", \\"2022-04-10T15:00\\", \\"2022-04-10T16:00\\", \\"2022-04-10T17:00\\", \\"2022-04-10T18:00\\", \\"2022-04-10T19:00\\", \\"2022-04-10T20:00\\", \\"2022-04-10T21:00\\", \\"2022-04-10T22:00\\", \\"2022-04-10T23:00\\", \\"2022-04-11T00:00\\", \\"2022-04-11T01:00\\", \\"2022-04-11T02:00\\", \\"2022-04-11T03:00\\", \\"2022-04-11T04:00\\", \\"2022-04-11T05:00\\", \\"2022-04-11T06:00\\", \\"2022-04-11T07:00\\", \\"2022-04-11T08:00\\", \\"2022-04-11T09:00\\", \\"2022-04-11T10:00\\", \\"2022-04-11T11:00\\", \\"2022-04-11T12:00\\", \\"2022-04-11T13:00\\", \\"2022-04-11T14:00\\", \\"2022-04-11T15:00\\", \\"2022-04-11T16:00\\", \\"2022-04-11T17:00\\", \\"2022-04-11T18:00\\", \\"2022-04-11T19:00\\", \\"2022-04-11T20:00\\", \\"2022-04-11T21:00\\", \\"2022-04-11T22:00\\", \\"2022-04-11T23:00\\", \\"2022-04-12T00:00\\", \\"2022-04-12T01:00\\", \\"2022-04-12T02:00\\", \\"2022-04-12T03:00\\", \\"2022-04-12T04:00\\", \\"2022-04-12T05:00\\", \\"2022-04-12T06:00\\", \\"2022-04-12T07:00\\", \\"2022-04-12T08:00\\", \\"2022-04-12T09:00\\", \\"2022-04-12T10:00\\", \\"2022-04-12T11:00\\", \\"2022-04-12T12:00\\", \\"2022-04-12T13:00\\", \\"2022-04-12T14:00\\", \\"2022-04-12T15:00\\", \\"2022-04-12T16:00\\", \\"2022-04-12T17:00\\", \\"2022-04-12T18:00\\", \\"2022-04-12T19:00\\", \\"2022-04-12T20:00\\", \\"2022-04-12T21:00\\", \\"2022-04-12T22:00\\", \\"2022-04-12T23:00\\", \\"2022-04-13T00:00\\", \\"2022-04-13T01:00\\", \\"2022-04-13T02:00\\", \\"2022-04-13T03:00\\", \\"2022-04-13T04:00\\", \\"2022-04-13T05:00\\", \\"2022-04-13T06:00\\", \\"2022-04-13T07:00\\", \\"2022-04-13T08:00\\", \\"2022-04-13T09:00\\", \\"2022-04-13T10:00\\", \\"2022-04-13T11:00\\", \\"2022-04-13T12:00\\", \\"2022-04-13T13:00\\", \\"2022-04-13T14:00\\", \\"2022-04-13T15:00\\", \\"2022-04-13T16:00\\", \\"2022-04-13T17:00\\", \\"2022-04-13T18:00\\", \\"2022-04-13T19:00\\", \\"2022-04-13T20:00\\", \\"2022-04-13T21:00\\", \\"2022-04-13T22:00\\", \\"2022-04-13T23:00\\", \\"2022-04-14T00:00\\", \\"2022-04-14T01:00\\", \\"2022-04-14T02:00\\", \\"2022-04-14T03:00\\", \\"2022-04-14T04:00\\", \\"2022-04-14T05:00\\", \\"2022-04-14T06:00\\", \\"2022-04-14T07:00\\", \\"2022-04-14T08:00\\", \\"2022-04-14T09:00\\", \\"2022-04-14T10:00\\", \\"2022-04-14T11:00\\", \\"2022-04-14T12:00\\", \\"2022-04-14T13:00\\", \\"2022-04-14T14:00\\", \\"2022-04-14T15:00\\", \\"2022-04-14T16:00\\", \\"2022-04-14T17:00\\", \\"2022-04-14T18:00\\", \\"2022-04-14T19:00\\", \\"2022-04-14T20:00\\", \\"2022-04-14T21:00\\", \\"2022-04-14T22:00\\", \\"2022-04-14T23:00\\", \\"2022-04-15T00:00\\", \\"2022-04-15T01:00\\", \\"2022-04-15T02:00\\", \\"2022-04-15T03:00\\", \\"2022-04-15T04:00\\", \\"2022-04-15T05:00\\", \\"2022-04-15T06:00\\", \\"2022-04-15T07:00\\", \\"2022-04-15T08:00\\", \\"2022-04-15T09:00\\", \\"2022-04-15T10:00\\", \\"2022-04-15T11:00\\", \\"2022-04-15T12:00\\", \\"2022-04-15T13:00\\", \\"2022-04-15T14:00\\", \\"2022-04-15T15:00\\", \\"2022-04-15T16:00\\", \\"2022-04-15T17:00\\", \\"2022-04-15T18:00\\", \\"2022-04-15T19:00\\", \\"2022-04-15T20:00\\", \\"2022-04-15T21:00\\", \\"2022-04-15T22:00\\", \\"2022-04-15T23:00\\", \\"2022-04-16T00:00\\", \\"2022-04-16T01:00\\", \\"2022-04-16T02:00\\", \\"2022-04-16T03:00\\", \\"2022-04-16T04:00\\", \\"2022-04-16T05:00\\", \\"2022-04-16T06:00\\", \\"2022-04-16T07:00\\", \\"2022-04-16T08:00\\", \\"2022-04-16T09:00\\", \\"2022-04-16T10:00\\", \\"2022-04-16T11:00\\", \\"2022-04-16T12:00\\", \\"2022-04-16T13:00\\", \\"2022-04-16T14:00\\", \\"2022-04-16T15:00\\", \\"2022-04-16T16:00\\", \\"2022-04-16T17:00\\", \\"2022-04-16T18:00\\", \\"2022-04-16T19:00\\", \\"2022-04-16T20:00\\", \\"2022-04-16T21:00\\", \\"2022-04-16T22:00\\", \\"2022-04-16T23:00\\", \\"2022-04-17T00:00\\", \\"2022-04-17T01:00\\", \\"2022-04-17T02:00\\", \\"2022-04-17T03:00\\", \\"2022-04-17T04:00\\", \\"2022-04-17T05:00\\", \\"2022-04-17T06:00\\", \\"2022-04-17T07:00\\", \\"2022-04-17T08:00\\", \\"2022-04-17T09:00\\", \\"2022-04-17T10:00\\", \\"2022-04-17T11:00\\", \\"2022-04-17T12:00\\", \\"2022-04-17T13:00\\", \\"2022-04-17T14:00\\", \\"2022-04-17T15:00\\", \\"2022-04-17T16:00\\", \\"2022-04-17T17:00\\", \\"2022-04-17T18:00\\", \\"2022-04-17T19:00\\", \\"2022-04-17T20:00\\", \\"2022-04-17T21:00\\", \\"2022-04-17T22:00\\", \\"2022-04-17T23:00\\", \\"2022-04-18T00:00\\", \\"2022-04-18T01:00\\", \\"2022-04-18T02:00\\", \\"2022-04-18T03:00\\", \\"2022-04-18T04:00\\", \\"2022-04-18T05:00\\", \\"2022-04-18T06:00\\", \\"2022-04-18T07:00\\", \\"2022-04-18T08:00\\", \\"2022-04-18T09:00\\", \\"2022-04-18T10:00\\", \\"2022-04-18T11:00\\", \\"2022-04-18T12:00\\", \\"2022-04-18T13:00\\", \\"2022-04-18T14:00\\", \\"2022-04-18T15:00\\", \\"2022-04-18T16:00\\", \\"2022-04-18T17:00\\", \\"2022-04-18T18:00\\", \\"2022-04-18T19:00\\", \\"2022-04-18T20:00\\", \\"2022-04-18T21:00\\", \\"2022-04-18T22:00\\", \\"2022-04-18T23:00\\", \\"2022-04-19T00:00\\", \\"2022-04-19T01:00\\", \\"2022-04-19T02:00\\", \\"2022-04-19T03:00\\", \\"2022-04-19T04:00\\", \\"2022-04-19T05:00\\", \\"2022-04-19T06:00\\", \\"2022-04-19T07:00\\", \\"2022-04-19T08:00\\", \\"2022-04-19T09:00\\", \\"2022-04-19T10:00\\", \\"2022-04-19T11:00\\", \\"2022-04-19T12:00\\", \\"2022-04-19T13:00\\", \\"2022-04-19T14:00\\", \\"2022-04-19T15:00\\", \\"2022-04-19T16:00\\", \\"2022-04-19T17:00\\", \\"2022-04-19T18:00\\", \\"2022-04-19T19:00\\", \\"2022-04-19T20:00\\", \\"2022-04-19T21:00\\", \\"2022-04-19T22:00\\", \\"2022-04-19T23:00\\", \\"2022-04-20T00:00\\", \\"2022-04-20T01:00\\", \\"2022-04-20T02:00\\", \\"2022-04-20T03:00\\", \\"2022-04-20T04:00\\", \\"2022-04-20T05:00\\", \\"2022-04-20T06:00\\", \\"2022-04-20T07:00\\", \\"2022-04-20T08:00\\", \\"2022-04-20T09:00\\", \\"2022-04-20T10:00\\", \\"2022-04-20T11:00\\", \\"2022-04-20T12:00\\", \\"2022-04-20T13:00\\", \\"2022-04-20T14:00\\", \\"2022-04-20T15:00\\", \\"2022-04-20T16:00\\", \\"2022-04-20T17:00\\", \\"2022-04-20T18:00\\", \\"2022-04-20T19:00\\", \\"2022-04-20T20:00\\", \\"2022-04-20T21:00\\", \\"2022-04-20T22:00\\", \\"2022-04-20T23:00\\", \\"2022-04-21T00:00\\", \\"2022-04-21T01:00\\", \\"2022-04-21T02:00\\", \\"2022-04-21T03:00\\", \\"2022-04-21T04:00\\", \\"2022-04-21T05:00\\", \\"2022-04-21T06:00\\", \\"2022-04-21T07:00\\", \\"2022-04-21T08:00\\", \\"2022-04-21T09:00\\", \\"2022-04-21T10:00\\", \\"2022-04-21T11:00\\"], \\"bal\\": [499.242, 498.48400000000004, 497.72600000000006, 496.9680000000001, 496.2100000000001, 495.4520000000001, 494.69400000000013, 493.93600000000015, 493.17800000000017, 492.4200000000002, 491.6620000000002, 490.9040000000002, 490.14600000000024, 489.38800000000026, 488.6300000000003, 487.8720000000003, 487.1140000000003, 486.35600000000034, 485.59800000000035, 484.8400000000004, 484.0820000000004, 483.3240000000004, 482.56600000000043, 481.80800000000045, 481.05000000000047, 480.2920000000005, 479.5340000000005, 478.7760000000005, 478.01800000000054, 477.26000000000056, 476.5020000000006, 475.7440000000006, 474.9860000000006, 474.22800000000063, 473.47000000000065, 472.71200000000067, 471.9540000000007, 471.1960000000007, 470.4380000000007, 469.68000000000075, 468.92200000000076, 468.1640000000008, 467.4060000000008, 466.6480000000008, 465.89000000000084, 465.13200000000086, 464.3740000000009, 463.6160000000009, 462.8580000000009, 462.10000000000093, 461.34200000000095, 460.58400000000097, 459.826000000001, 459.068000000001, 458.310000000001, 457.55200000000104, 456.79400000000106, 456.0360000000011, 455.2780000000011, 454.5200000000011, 453.76200000000114, 453.00400000000116, 452.2460000000012, 451.4880000000012, 450.7300000000012, 449.97200000000123, 449.21400000000125, 448.45600000000127, 447.6980000000013, 446.9400000000013, 446.1820000000013, 445.42400000000134, 444.66600000000136, 443.9080000000014, 443.1500000000014, 442.3920000000014, 441.63400000000144, 440.87600000000145, 440.1180000000015, 439.3600000000015, 438.6020000000015, 437.84400000000153, 437.08600000000155, 436.32800000000157, 435.5700000000016, 434.8120000000016, 434.0540000000016, 433.29600000000164, 432.53800000000166, 431.7800000000017, 431.0220000000017, 430.2640000000017, 429.50600000000173, 428.74800000000175, 427.99000000000177, 427.2320000000018, 426.4740000000018, 425.7160000000018, 424.95800000000185, 424.20000000000186, 423.4420000000019, 422.6840000000019, 421.9260000000019, 421.16800000000194, 420.41000000000196, 419.652000000002, 418.894000000002, 418.136000000002, 417.37800000000203, 416.62000000000205, 415.86200000000207, 415.1040000000021, 414.3460000000021, 413.5880000000021, 412.83000000000214, 412.07200000000216, 411.3140000000022, 410.5560000000022, 409.7980000000022, 409.04000000000224, 408.28200000000226, 407.5240000000023, 406.7660000000023, 406.0080000000023, 405.25000000000233, 404.49200000000235, 403.73400000000237, 402.9760000000024, 402.2180000000024, 401.4600000000024, 400.70200000000244, 399.94400000000246, 399.1860000000025, 398.4280000000025, 397.6700000000025, 396.91200000000254, 396.15400000000255, 395.3960000000026, 394.6380000000026, 393.8800000000026, 393.12200000000263, 392.36400000000265, 391.60600000000267, 390.8480000000027, 390.0900000000027, 389.3320000000027, 388.57400000000274, 387.81600000000276, 387.0580000000028, 386.3000000000028, 385.5420000000028, 384.78400000000283, 384.02600000000285, 383.26800000000287, 382.5100000000029, 381.7520000000029, 380.9940000000029, 380.23600000000295, 379.47800000000296, 378.720000000003, 377.962000000003, 377.204000000003, 376.44600000000304, 375.68800000000306, 374.9300000000031, 374.1720000000031, 373.4140000000031, 372.65600000000313, 371.89800000000315, 371.14000000000317, 370.3820000000032, 369.6240000000032, 368.8660000000032, 368.10800000000324, 367.35000000000326, 366.5920000000033, 365.8340000000033, 365.0760000000033, 364.31800000000334, 363.56000000000336, 362.8020000000034, 362.0440000000034, 361.2860000000034, 360.52800000000343, 359.77000000000345, 359.01200000000347, 358.2540000000035, 357.4960000000035, 356.7380000000035, 355.98000000000354, 355.22200000000356, 354.4640000000036, 353.7060000000036, 352.9480000000036, 352.19000000000364, 351.43200000000365, 350.6740000000037, 349.9160000000037, 349.1580000000037, 348.40000000000373, 347.64200000000375, 346.88400000000377, 346.1260000000038, 345.3680000000038, 344.6100000000038, 343.85200000000384, 343.09400000000386, 342.3360000000039, 341.5780000000039, 340.8200000000039, 340.06200000000393, 339.30400000000395, 338.54600000000397, 337.788000000004, 337.030000000004, 336.272000000004, 335.51400000000405, 334.75600000000406, 333.9980000000041, 333.2400000000041, 332.4820000000041, 331.72400000000414, 330.96600000000416, 330.2080000000042, 329.4500000000042, 328.6920000000042, 327.93400000000423, 327.17600000000425, 326.41800000000427, 325.6600000000043, 324.9020000000043, 324.1440000000043, 323.38600000000434, 322.62800000000436, 321.8700000000044, 321.1120000000044, 320.3540000000044, 319.59600000000444, 318.83800000000446, 318.0800000000045, 317.3220000000045, 316.5640000000045, 315.80600000000453, 315.04800000000455, 314.29000000000457, 313.5320000000046, 312.7740000000046, 312.0160000000046, 311.25800000000464, 310.50000000000466, 309.7420000000047, 308.9840000000047, 308.2260000000047, 307.46800000000474, 306.71000000000475, 305.9520000000048, 305.1940000000048, 304.4360000000048, 303.67800000000483, 302.92000000000485, 302.16200000000487, 301.4040000000049, 300.6460000000049, 299.8880000000049, 299.13000000000494, 298.37200000000496, 297.614000000005, 296.856000000005, 296.098000000005, 295.34000000000503, 294.58200000000505, 293.82400000000507, 293.0660000000051, 292.3080000000051, 291.5500000000051, 290.79200000000515, 290.03400000000516, 289.2760000000052, 288.5180000000052, 287.7600000000052, 287.00200000000524, 286.24400000000526, 285.4860000000053, 284.7280000000053, 283.9700000000053, 283.21200000000533, 282.45400000000535, 281.69600000000537, 280.9380000000054, 280.1800000000054, 279.4220000000054, 278.66400000000544, 277.90600000000546, 277.1480000000055, 276.3900000000055, 275.6320000000055, 274.87400000000554, 274.11600000000556, 273.3580000000056, 272.6000000000056, 271.8420000000056, 271.08400000000563, 270.32600000000565, 269.56800000000567, 268.8100000000057, 268.0520000000057, 267.2940000000057, 266.53600000000574, 265.77800000000576, 265.0200000000058, 264.2620000000058, 263.5040000000058, 262.74600000000584, 261.98800000000585, 261.2300000000059, 260.4720000000059, 259.7140000000059, 258.95600000000593, 258.19800000000595, 257.44000000000597, 256.682000000006, 255.92400000000598, 255.16600000000597, 254.40800000000596, 253.65000000000595, 252.89200000000594, 252.13400000000593, 251.37600000000592, 250.6180000000059, 249.8600000000059, 249.1020000000059, 248.34400000000588, 247.58600000000587, 246.82800000000586, 246.07000000000585, 245.31200000000584]}"	"{\\"tm\\": [\\"2022-04-08\\", \\"2022-04-09\\", \\"2022-04-10\\", \\"2022-04-11\\", \\"2022-04-12\\", \\"2022-04-13\\", \\"2022-04-14\\", \\"2022-04-15\\", \\"2022-04-16\\", \\"2022-04-17\\", \\"2022-04-18\\", \\"2022-04-19\\", \\"2022-04-20\\", \\"2022-04-21\\", \\"2022-04-22\\", \\"2022-04-23\\", \\"2022-04-24\\", \\"2022-04-25\\", \\"2022-04-26\\", \\"2022-04-27\\", \\"2022-04-28\\", \\"2022-04-29\\", \\"2022-04-30\\", \\"2022-05-01\\", \\"2022-05-02\\", \\"2022-05-03\\", \\"2022-05-04\\", \\"2022-05-05\\", \\"2022-05-06\\", \\"2022-05-07\\", \\"2022-05-08\\"], \\"bal\\": [473.41715055555557, 455.22515055555556, 437.03315055555555, 418.84115055555554, 400.64915055555554, 382.45715055555553, 364.2651505555555, 346.0731505555555, 327.8811505555555, 309.6891505555555, 291.4971505555555, 273.3051505555555, 255.11315055555548, 236.92115055555547, 218.72915055555546, 200.53715055555546, 182.34515055555545, 164.15315055555544, 145.96115055555543, 127.76915055555543, 109.57715055555542, 91.38515055555541, 73.1931505555554, 155.0011505555554, 136.8091505555554, 118.61715055555538, 100.42515055555538, 82.23315055555537, 64.04115055555536, 45.84915055555536, 27.65715055555536]}"	"{\\"tm\\": [\\"2022-04\\", \\"2022-04\\", \\"2022-05\\", \\"2022-06\\", \\"2022-07\\", \\"2022-08\\", \\"2022-09\\", \\"2022-10\\", \\"2022-11\\", \\"2022-12\\", \\"2023-01\\", \\"2023-02\\", \\"2023-03\\", \\"2023-04\\"], \\"bal\\": [173.19315055555535, -390.75884944444465, -954.7108494444446, -1518.6628494444446, -2082.6148494444446, -2646.5668494444444, -3210.5188494444446, -3774.470849444445, -4338.422849444445, -4902.374849444445, -5466.3268494444455, -6030.278849444446, -6594.230849444446, -7158.182849444446]}"	"{\\"tm\\": [\\"2022-04-07T12:00\\", \\"2022-04-07T13:00\\", \\"2022-04-07T14:00\\", \\"2022-04-07T15:00\\", \\"2022-04-07T16:00\\", \\"2022-04-07T17:00\\", \\"2022-04-07T18:00\\", \\"2022-04-07T19:00\\", \\"2022-04-07T20:00\\", \\"2022-04-07T21:00\\", \\"2022-04-07T22:00\\", \\"2022-04-07T23:00\\", \\"2022-04-08T00:00\\", \\"2022-04-08T01:00\\", \\"2022-04-08T02:00\\", \\"2022-04-08T03:00\\", \\"2022-04-08T04:00\\", \\"2022-04-08T05:00\\", \\"2022-04-08T06:00\\", \\"2022-04-08T07:00\\", \\"2022-04-08T08:00\\", \\"2022-04-08T09:00\\", \\"2022-04-08T10:00\\", \\"2022-04-08T11:00\\", \\"2022-04-08T12:00\\", \\"2022-04-08T13:00\\", \\"2022-04-08T14:00\\", \\"2022-04-08T15:00\\", \\"2022-04-08T16:00\\", \\"2022-04-08T17:00\\", \\"2022-04-08T18:00\\", \\"2022-04-08T19:00\\", \\"2022-04-08T20:00\\", \\"2022-04-08T21:00\\", \\"2022-04-08T22:00\\", \\"2022-04-08T23:00\\", \\"2022-04-09T00:00\\", \\"2022-04-09T01:00\\", \\"2022-04-09T02:00\\", \\"2022-04-09T03:00\\", \\"2022-04-09T04:00\\", \\"2022-04-09T05:00\\", \\"2022-04-09T06:00\\", \\"2022-04-09T07:00\\", \\"2022-04-09T08:00\\", \\"2022-04-09T09:00\\", \\"2022-04-09T10:00\\", \\"2022-04-09T11:00\\", \\"2022-04-09T12:00\\", \\"2022-04-09T13:00\\", \\"2022-04-09T14:00\\", \\"2022-04-09T15:00\\", \\"2022-04-09T16:00\\", \\"2022-04-09T17:00\\", \\"2022-04-09T18:00\\", \\"2022-04-09T19:00\\", \\"2022-04-09T20:00\\", \\"2022-04-09T21:00\\", \\"2022-04-09T22:00\\", \\"2022-04-09T23:00\\", \\"2022-04-10T00:00\\", \\"2022-04-10T01:00\\", \\"2022-04-10T02:00\\", \\"2022-04-10T03:00\\", \\"2022-04-10T04:00\\", \\"2022-04-10T05:00\\", \\"2022-04-10T06:00\\", \\"2022-04-10T07:00\\", \\"2022-04-10T08:00\\", \\"2022-04-10T09:00\\", \\"2022-04-10T10:00\\", \\"2022-04-10T11:00\\", \\"2022-04-10T12:00\\", \\"2022-04-10T13:00\\", \\"2022-04-10T14:00\\", \\"2022-04-10T15:00\\", \\"2022-04-10T16:00\\", \\"2022-04-10T17:00\\", \\"2022-04-10T18:00\\", \\"2022-04-10T19:00\\", \\"2022-04-10T20:00\\", \\"2022-04-10T21:00\\", \\"2022-04-10T22:00\\", \\"2022-04-10T23:00\\", \\"2022-04-11T00:00\\", \\"2022-04-11T01:00\\", \\"2022-04-11T02:00\\", \\"2022-04-11T03:00\\", \\"2022-04-11T04:00\\", \\"2022-04-11T05:00\\", \\"2022-04-11T06:00\\", \\"2022-04-11T07:00\\", \\"2022-04-11T08:00\\", \\"2022-04-11T09:00\\", \\"2022-04-11T10:00\\", \\"2022-04-11T11:00\\", \\"2022-04-11T12:00\\", \\"2022-04-11T13:00\\", \\"2022-04-11T14:00\\", \\"2022-04-11T15:00\\", \\"2022-04-11T16:00\\", \\"2022-04-11T17:00\\", \\"2022-04-11T18:00\\", \\"2022-04-11T19:00\\", \\"2022-04-11T20:00\\", \\"2022-04-11T21:00\\", \\"2022-04-11T22:00\\", \\"2022-04-11T23:00\\", \\"2022-04-12T00:00\\", \\"2022-04-12T01:00\\", \\"2022-04-12T02:00\\", \\"2022-04-12T03:00\\", \\"2022-04-12T04:00\\", \\"2022-04-12T05:00\\", \\"2022-04-12T06:00\\", \\"2022-04-12T07:00\\", \\"2022-04-12T08:00\\", \\"2022-04-12T09:00\\", \\"2022-04-12T10:00\\", \\"2022-04-12T11:00\\", \\"2022-04-12T12:00\\", \\"2022-04-12T13:00\\", \\"2022-04-12T14:00\\", \\"2022-04-12T15:00\\", \\"2022-04-12T16:00\\", \\"2022-04-12T17:00\\", \\"2022-04-12T18:00\\", \\"2022-04-12T19:00\\", \\"2022-04-12T20:00\\", \\"2022-04-12T21:00\\", \\"2022-04-12T22:00\\", \\"2022-04-12T23:00\\", \\"2022-04-13T00:00\\", \\"2022-04-13T01:00\\", \\"2022-04-13T02:00\\", \\"2022-04-13T03:00\\", \\"2022-04-13T04:00\\", \\"2022-04-13T05:00\\", \\"2022-04-13T06:00\\", \\"2022-04-13T07:00\\", \\"2022-04-13T08:00\\", \\"2022-04-13T09:00\\", \\"2022-04-13T10:00\\", \\"2022-04-13T11:00\\", \\"2022-04-13T12:00\\", \\"2022-04-13T13:00\\", \\"2022-04-13T14:00\\", \\"2022-04-13T15:00\\", \\"2022-04-13T16:00\\", \\"2022-04-13T17:00\\", \\"2022-04-13T18:00\\", \\"2022-04-13T19:00\\", \\"2022-04-13T20:00\\", \\"2022-04-13T21:00\\", \\"2022-04-13T22:00\\", \\"2022-04-13T23:00\\", \\"2022-04-14T00:00\\", \\"2022-04-14T01:00\\", \\"2022-04-14T02:00\\", \\"2022-04-14T03:00\\", \\"2022-04-14T04:00\\", \\"2022-04-14T05:00\\", \\"2022-04-14T06:00\\", \\"2022-04-14T07:00\\", \\"2022-04-14T08:00\\", \\"2022-04-14T09:00\\", \\"2022-04-14T10:00\\", \\"2022-04-14T11:00\\", \\"2022-04-14T12:00\\", \\"2022-04-14T13:00\\", \\"2022-04-14T14:00\\", \\"2022-04-14T15:00\\", \\"2022-04-14T16:00\\", \\"2022-04-14T17:00\\", \\"2022-04-14T18:00\\", \\"2022-04-14T19:00\\", \\"2022-04-14T20:00\\", \\"2022-04-14T21:00\\", \\"2022-04-14T22:00\\", \\"2022-04-14T23:00\\", \\"2022-04-15T00:00\\", \\"2022-04-15T01:00\\", \\"2022-04-15T02:00\\", \\"2022-04-15T03:00\\", \\"2022-04-15T04:00\\", \\"2022-04-15T05:00\\", \\"2022-04-15T06:00\\", \\"2022-04-15T07:00\\", \\"2022-04-15T08:00\\", \\"2022-04-15T09:00\\", \\"2022-04-15T10:00\\", \\"2022-04-15T11:00\\", \\"2022-04-15T12:00\\", \\"2022-04-15T13:00\\", \\"2022-04-15T14:00\\", \\"2022-04-15T15:00\\", \\"2022-04-15T16:00\\", \\"2022-04-15T17:00\\", \\"2022-04-15T18:00\\", \\"2022-04-15T19:00\\", \\"2022-04-15T20:00\\", \\"2022-04-15T21:00\\", \\"2022-04-15T22:00\\", \\"2022-04-15T23:00\\", \\"2022-04-16T00:00\\", \\"2022-04-16T01:00\\", \\"2022-04-16T02:00\\", \\"2022-04-16T03:00\\", \\"2022-04-16T04:00\\", \\"2022-04-16T05:00\\", \\"2022-04-16T06:00\\", \\"2022-04-16T07:00\\", \\"2022-04-16T08:00\\", \\"2022-04-16T09:00\\", \\"2022-04-16T10:00\\", \\"2022-04-16T11:00\\", \\"2022-04-16T12:00\\", \\"2022-04-16T13:00\\", \\"2022-04-16T14:00\\", \\"2022-04-16T15:00\\", \\"2022-04-16T16:00\\", \\"2022-04-16T17:00\\", \\"2022-04-16T18:00\\", \\"2022-04-16T19:00\\", \\"2022-04-16T20:00\\", \\"2022-04-16T21:00\\", \\"2022-04-16T22:00\\", \\"2022-04-16T23:00\\", \\"2022-04-17T00:00\\", \\"2022-04-17T01:00\\", \\"2022-04-17T02:00\\", \\"2022-04-17T03:00\\", \\"2022-04-17T04:00\\", \\"2022-04-17T05:00\\", \\"2022-04-17T06:00\\", \\"2022-04-17T07:00\\", \\"2022-04-17T08:00\\", \\"2022-04-17T09:00\\", \\"2022-04-17T10:00\\", \\"2022-04-17T11:00\\", \\"2022-04-17T12:00\\", \\"2022-04-17T13:00\\", \\"2022-04-17T14:00\\", \\"2022-04-17T15:00\\", \\"2022-04-17T16:00\\", \\"2022-04-17T17:00\\", \\"2022-04-17T18:00\\", \\"2022-04-17T19:00\\", \\"2022-04-17T20:00\\", \\"2022-04-17T21:00\\", \\"2022-04-17T22:00\\", \\"2022-04-17T23:00\\", \\"2022-04-18T00:00\\", \\"2022-04-18T01:00\\", \\"2022-04-18T02:00\\", \\"2022-04-18T03:00\\", \\"2022-04-18T04:00\\", \\"2022-04-18T05:00\\", \\"2022-04-18T06:00\\", \\"2022-04-18T07:00\\", \\"2022-04-18T08:00\\", \\"2022-04-18T09:00\\", \\"2022-04-18T10:00\\", \\"2022-04-18T11:00\\", \\"2022-04-18T12:00\\", \\"2022-04-18T13:00\\", \\"2022-04-18T14:00\\", \\"2022-04-18T15:00\\", \\"2022-04-18T16:00\\", \\"2022-04-18T17:00\\", \\"2022-04-18T18:00\\", \\"2022-04-18T19:00\\", \\"2022-04-18T20:00\\", \\"2022-04-18T21:00\\", \\"2022-04-18T22:00\\", \\"2022-04-18T23:00\\", \\"2022-04-19T00:00\\", \\"2022-04-19T01:00\\", \\"2022-04-19T02:00\\", \\"2022-04-19T03:00\\", \\"2022-04-19T04:00\\", \\"2022-04-19T05:00\\", \\"2022-04-19T06:00\\", \\"2022-04-19T07:00\\", \\"2022-04-19T08:00\\", \\"2022-04-19T09:00\\", \\"2022-04-19T10:00\\", \\"2022-04-19T11:00\\", \\"2022-04-19T12:00\\", \\"2022-04-19T13:00\\", \\"2022-04-19T14:00\\", \\"2022-04-19T15:00\\", \\"2022-04-19T16:00\\", \\"2022-04-19T17:00\\", \\"2022-04-19T18:00\\", \\"2022-04-19T19:00\\", \\"2022-04-19T20:00\\", \\"2022-04-19T21:00\\", \\"2022-04-19T22:00\\", \\"2022-04-19T23:00\\", \\"2022-04-20T00:00\\", \\"2022-04-20T01:00\\", \\"2022-04-20T02:00\\", \\"2022-04-20T03:00\\", \\"2022-04-20T04:00\\", \\"2022-04-20T05:00\\", \\"2022-04-20T06:00\\", \\"2022-04-20T07:00\\", \\"2022-04-20T08:00\\", \\"2022-04-20T09:00\\", \\"2022-04-20T10:00\\", \\"2022-04-20T11:00\\", \\"2022-04-20T12:00\\", \\"2022-04-20T13:00\\", \\"2022-04-20T14:00\\", \\"2022-04-20T15:00\\", \\"2022-04-20T16:00\\", \\"2022-04-20T17:00\\", \\"2022-04-20T18:00\\", \\"2022-04-20T19:00\\", \\"2022-04-20T20:00\\", \\"2022-04-20T21:00\\", \\"2022-04-20T22:00\\", \\"2022-04-20T23:00\\", \\"2022-04-21T00:00\\", \\"2022-04-21T01:00\\", \\"2022-04-21T02:00\\", \\"2022-04-21T03:00\\", \\"2022-04-21T04:00\\", \\"2022-04-21T05:00\\", \\"2022-04-21T06:00\\", \\"2022-04-21T07:00\\", \\"2022-04-21T08:00\\", \\"2022-04-21T09:00\\", \\"2022-04-21T10:00\\", \\"2022-04-21T11:00\\"], \\"bal\\": [499.242, 498.48400000000004, 497.72600000000006, 496.9680000000001, 496.2100000000001, 495.4520000000001, 494.69400000000013, 493.93600000000015, 493.17800000000017, 492.4200000000002, 491.6620000000002, 490.9040000000002, 490.14600000000024, 489.38800000000026, 488.6300000000003, 487.8720000000003, 487.1140000000003, 486.35600000000034, 485.59800000000035, 484.8400000000004, 484.0820000000004, 483.3240000000004, 482.56600000000043, 481.80800000000045, 481.05000000000047, 480.2920000000005, 479.5340000000005, 478.7760000000005, 478.01800000000054, 477.26000000000056, 476.5020000000006, 475.7440000000006, 474.9860000000006, 474.22800000000063, 473.47000000000065, 472.71200000000067, 471.9540000000007, 471.1960000000007, 470.4380000000007, 469.68000000000075, 468.92200000000076, 468.1640000000008, 467.4060000000008, 466.6480000000008, 465.89000000000084, 465.13200000000086, 464.3740000000009, 463.6160000000009, 462.8580000000009, 462.10000000000093, 461.34200000000095, 460.58400000000097, 459.826000000001, 459.068000000001, 458.310000000001, 457.55200000000104, 456.79400000000106, 456.0360000000011, 455.2780000000011, 454.5200000000011, 453.76200000000114, 453.00400000000116, 452.2460000000012, 451.4880000000012, 450.7300000000012, 449.97200000000123, 449.21400000000125, 448.45600000000127, 447.6980000000013, 446.9400000000013, 446.1820000000013, 445.42400000000134, 444.66600000000136, 443.9080000000014, 443.1500000000014, 442.3920000000014, 441.63400000000144, 440.87600000000145, 440.1180000000015, 439.3600000000015, 438.6020000000015, 437.84400000000153, 437.08600000000155, 436.32800000000157, 435.5700000000016, 434.8120000000016, 434.0540000000016, 433.29600000000164, 432.53800000000166, 431.7800000000017, 431.0220000000017, 430.2640000000017, 429.50600000000173, 428.74800000000175, 427.99000000000177, 427.2320000000018, 426.4740000000018, 425.7160000000018, 424.95800000000185, 424.20000000000186, 423.4420000000019, 422.6840000000019, 421.9260000000019, 421.16800000000194, 420.41000000000196, 419.652000000002, 418.894000000002, 418.136000000002, 417.37800000000203, 416.62000000000205, 415.86200000000207, 415.1040000000021, 414.3460000000021, 413.5880000000021, 412.83000000000214, 412.07200000000216, 411.3140000000022, 410.5560000000022, 409.7980000000022, 409.04000000000224, 408.28200000000226, 407.5240000000023, 406.7660000000023, 406.0080000000023, 405.25000000000233, 404.49200000000235, 403.73400000000237, 402.9760000000024, 402.2180000000024, 401.4600000000024, 400.70200000000244, 399.94400000000246, 399.1860000000025, 398.4280000000025, 397.6700000000025, 396.91200000000254, 396.15400000000255, 395.3960000000026, 394.6380000000026, 393.8800000000026, 393.12200000000263, 392.36400000000265, 391.60600000000267, 390.8480000000027, 390.0900000000027, 389.3320000000027, 388.57400000000274, 387.81600000000276, 387.0580000000028, 386.3000000000028, 385.5420000000028, 384.78400000000283, 384.02600000000285, 383.26800000000287, 382.5100000000029, 381.7520000000029, 380.9940000000029, 380.23600000000295, 379.47800000000296, 378.720000000003, 377.962000000003, 377.204000000003, 376.44600000000304, 375.68800000000306, 374.9300000000031, 374.1720000000031, 373.4140000000031, 372.65600000000313, 371.89800000000315, 371.14000000000317, 370.3820000000032, 369.6240000000032, 368.8660000000032, 368.10800000000324, 367.35000000000326, 366.5920000000033, 365.8340000000033, 365.0760000000033, 364.31800000000334, 363.56000000000336, 362.8020000000034, 362.0440000000034, 361.2860000000034, 360.52800000000343, 359.77000000000345, 359.01200000000347, 358.2540000000035, 357.4960000000035, 356.7380000000035, 355.98000000000354, 355.22200000000356, 354.4640000000036, 353.7060000000036, 352.9480000000036, 352.19000000000364, 351.43200000000365, 350.6740000000037, 349.9160000000037, 349.1580000000037, 348.40000000000373, 347.64200000000375, 346.88400000000377, 346.1260000000038, 345.3680000000038, 344.6100000000038, 343.85200000000384, 343.09400000000386, 342.3360000000039, 341.5780000000039, 340.8200000000039, 340.06200000000393, 339.30400000000395, 338.54600000000397, 337.788000000004, 337.030000000004, 336.272000000004, 335.51400000000405, 334.75600000000406, 333.9980000000041, 333.2400000000041, 332.4820000000041, 331.72400000000414, 330.96600000000416, 330.2080000000042, 329.4500000000042, 328.6920000000042, 327.93400000000423, 327.17600000000425, 326.41800000000427, 325.6600000000043, 324.9020000000043, 324.1440000000043, 323.38600000000434, 322.62800000000436, 321.8700000000044, 321.1120000000044, 320.3540000000044, 319.59600000000444, 318.83800000000446, 318.0800000000045, 317.3220000000045, 316.5640000000045, 315.80600000000453, 315.04800000000455, 314.29000000000457, 313.5320000000046, 312.7740000000046, 312.0160000000046, 311.25800000000464, 310.50000000000466, 309.7420000000047, 308.9840000000047, 308.2260000000047, 307.46800000000474, 306.71000000000475, 305.9520000000048, 305.1940000000048, 304.4360000000048, 303.67800000000483, 302.92000000000485, 302.16200000000487, 301.4040000000049, 300.6460000000049, 299.8880000000049, 299.13000000000494, 298.37200000000496, 297.614000000005, 296.856000000005, 296.098000000005, 295.34000000000503, 294.58200000000505, 293.82400000000507, 293.0660000000051, 292.3080000000051, 291.5500000000051, 290.79200000000515, 290.03400000000516, 289.2760000000052, 288.5180000000052, 287.7600000000052, 287.00200000000524, 286.24400000000526, 285.4860000000053, 284.7280000000053, 283.9700000000053, 283.21200000000533, 282.45400000000535, 281.69600000000537, 280.9380000000054, 280.1800000000054, 279.4220000000054, 278.66400000000544, 277.90600000000546, 277.1480000000055, 276.3900000000055, 275.6320000000055, 274.87400000000554, 274.11600000000556, 273.3580000000056, 272.6000000000056, 271.8420000000056, 271.08400000000563, 270.32600000000565, 269.56800000000567, 268.8100000000057, 268.0520000000057, 267.2940000000057, 266.53600000000574, 265.77800000000576, 265.0200000000058, 264.2620000000058, 263.5040000000058, 262.74600000000584, 261.98800000000585, 261.2300000000059, 260.4720000000059, 259.7140000000059, 258.95600000000593, 258.19800000000595, 257.44000000000597, 256.682000000006, 255.92400000000598, 255.16600000000597, 254.40800000000596, 253.65000000000595, 252.89200000000594, 252.13400000000593, 251.37600000000592, 250.6180000000059, 249.8600000000059, 249.1020000000059, 248.34400000000588, 247.58600000000587, 246.82800000000586, 246.07000000000585, 245.31200000000584]}"	"{\\"tm\\": [\\"2022-04-08\\", \\"2022-04-09\\", \\"2022-04-10\\", \\"2022-04-11\\", \\"2022-04-12\\", \\"2022-04-13\\", \\"2022-04-14\\", \\"2022-04-15\\", \\"2022-04-16\\", \\"2022-04-17\\", \\"2022-04-18\\", \\"2022-04-19\\", \\"2022-04-20\\", \\"2022-04-21\\", \\"2022-04-22\\", \\"2022-04-23\\", \\"2022-04-24\\", \\"2022-04-25\\", \\"2022-04-26\\", \\"2022-04-27\\", \\"2022-04-28\\", \\"2022-04-29\\", \\"2022-04-30\\", \\"2022-05-01\\", \\"2022-05-02\\", \\"2022-05-03\\", \\"2022-05-04\\", \\"2022-05-05\\", \\"2022-05-06\\", \\"2022-05-07\\", \\"2022-05-08\\"], \\"bal\\": [473.41715055555557, 455.22515055555556, 437.03315055555555, 418.84115055555554, 400.64915055555554, 382.45715055555553, 364.2651505555555, 346.0731505555555, 327.8811505555555, 309.6891505555555, 291.4971505555555, 273.3051505555555, 255.11315055555548, 236.92115055555547, 218.72915055555546, 200.53715055555546, 182.34515055555545, 164.15315055555544, 145.96115055555543, 127.76915055555543, 109.57715055555542, 91.38515055555541, 73.1931505555554, 155.0011505555554, 136.8091505555554, 118.61715055555538, 100.42515055555538, 82.23315055555537, 64.04115055555536, 45.84915055555536, 27.65715055555536]}"	"{\\"tm\\": [\\"2022-04\\", \\"2022-04\\", \\"2022-05\\", \\"2022-06\\", \\"2022-07\\", \\"2022-08\\", \\"2022-09\\", \\"2022-10\\", \\"2022-11\\", \\"2022-12\\", \\"2023-01\\", \\"2023-02\\", \\"2023-03\\", \\"2023-04\\"], \\"bal\\": [173.19315055555535, -390.75884944444465, -954.7108494444446, -1518.6628494444446, -2082.6148494444446, -2646.5668494444444, -3210.5188494444446, -3774.470849444445, -4338.422849444445, -4902.374849444445, -5466.3268494444455, -6030.278849444446, -6594.230849444446, -7158.182849444446]}"	"{\\"tm\\": [\\"2022-04-07T12:00\\", \\"2022-04-07T13:00\\", \\"2022-04-07T14:00\\", \\"2022-04-07T15:00\\", \\"2022-04-07T16:00\\", \\"2022-04-07T17:00\\", \\"2022-04-07T18:00\\", \\"2022-04-07T19:00\\", \\"2022-04-07T20:00\\", \\"2022-04-07T21:00\\", \\"2022-04-07T22:00\\", \\"2022-04-07T23:00\\", \\"2022-04-08T00:00\\", \\"2022-04-08T01:00\\", \\"2022-04-08T02:00\\", \\"2022-04-08T03:00\\", \\"2022-04-08T04:00\\", \\"2022-04-08T05:00\\", \\"2022-04-08T06:00\\", \\"2022-04-08T07:00\\", \\"2022-04-08T08:00\\", \\"2022-04-08T09:00\\", \\"2022-04-08T10:00\\", \\"2022-04-08T11:00\\", \\"2022-04-08T12:00\\", \\"2022-04-08T13:00\\", \\"2022-04-08T14:00\\", \\"2022-04-08T15:00\\", \\"2022-04-08T16:00\\", \\"2022-04-08T17:00\\", \\"2022-04-08T18:00\\", \\"2022-04-08T19:00\\", \\"2022-04-08T20:00\\", \\"2022-04-08T21:00\\", \\"2022-04-08T22:00\\", \\"2022-04-08T23:00\\", \\"2022-04-09T00:00\\", \\"2022-04-09T01:00\\", \\"2022-04-09T02:00\\", \\"2022-04-09T03:00\\", \\"2022-04-09T04:00\\", \\"2022-04-09T05:00\\", \\"2022-04-09T06:00\\", \\"2022-04-09T07:00\\", \\"2022-04-09T08:00\\", \\"2022-04-09T09:00\\", \\"2022-04-09T10:00\\", \\"2022-04-09T11:00\\", \\"2022-04-09T12:00\\", \\"2022-04-09T13:00\\", \\"2022-04-09T14:00\\", \\"2022-04-09T15:00\\", \\"2022-04-09T16:00\\", \\"2022-04-09T17:00\\", \\"2022-04-09T18:00\\", \\"2022-04-09T19:00\\", \\"2022-04-09T20:00\\", \\"2022-04-09T21:00\\", \\"2022-04-09T22:00\\", \\"2022-04-09T23:00\\", \\"2022-04-10T00:00\\", \\"2022-04-10T01:00\\", \\"2022-04-10T02:00\\", \\"2022-04-10T03:00\\", \\"2022-04-10T04:00\\", \\"2022-04-10T05:00\\", \\"2022-04-10T06:00\\", \\"2022-04-10T07:00\\", \\"2022-04-10T08:00\\", \\"2022-04-10T09:00\\", \\"2022-04-10T10:00\\", \\"2022-04-10T11:00\\", \\"2022-04-10T12:00\\", \\"2022-04-10T13:00\\", \\"2022-04-10T14:00\\", \\"2022-04-10T15:00\\", \\"2022-04-10T16:00\\", \\"2022-04-10T17:00\\", \\"2022-04-10T18:00\\", \\"2022-04-10T19:00\\", \\"2022-04-10T20:00\\", \\"2022-04-10T21:00\\", \\"2022-04-10T22:00\\", \\"2022-04-10T23:00\\", \\"2022-04-11T00:00\\", \\"2022-04-11T01:00\\", \\"2022-04-11T02:00\\", \\"2022-04-11T03:00\\", \\"2022-04-11T04:00\\", \\"2022-04-11T05:00\\", \\"2022-04-11T06:00\\", \\"2022-04-11T07:00\\", \\"2022-04-11T08:00\\", \\"2022-04-11T09:00\\", \\"2022-04-11T10:00\\", \\"2022-04-11T11:00\\", \\"2022-04-11T12:00\\", \\"2022-04-11T13:00\\", \\"2022-04-11T14:00\\", \\"2022-04-11T15:00\\", \\"2022-04-11T16:00\\", \\"2022-04-11T17:00\\", \\"2022-04-11T18:00\\", \\"2022-04-11T19:00\\", \\"2022-04-11T20:00\\", \\"2022-04-11T21:00\\", \\"2022-04-11T22:00\\", \\"2022-04-11T23:00\\", \\"2022-04-12T00:00\\", \\"2022-04-12T01:00\\", \\"2022-04-12T02:00\\", \\"2022-04-12T03:00\\", \\"2022-04-12T04:00\\", \\"2022-04-12T05:00\\", \\"2022-04-12T06:00\\", \\"2022-04-12T07:00\\", \\"2022-04-12T08:00\\", \\"2022-04-12T09:00\\", \\"2022-04-12T10:00\\", \\"2022-04-12T11:00\\", \\"2022-04-12T12:00\\", \\"2022-04-12T13:00\\", \\"2022-04-12T14:00\\", \\"2022-04-12T15:00\\", \\"2022-04-12T16:00\\", \\"2022-04-12T17:00\\", \\"2022-04-12T18:00\\", \\"2022-04-12T19:00\\", \\"2022-04-12T20:00\\", \\"2022-04-12T21:00\\", \\"2022-04-12T22:00\\", \\"2022-04-12T23:00\\", \\"2022-04-13T00:00\\", \\"2022-04-13T01:00\\", \\"2022-04-13T02:00\\", \\"2022-04-13T03:00\\", \\"2022-04-13T04:00\\", \\"2022-04-13T05:00\\", \\"2022-04-13T06:00\\", \\"2022-04-13T07:00\\", \\"2022-04-13T08:00\\", \\"2022-04-13T09:00\\", \\"2022-04-13T10:00\\", \\"2022-04-13T11:00\\", \\"2022-04-13T12:00\\", \\"2022-04-13T13:00\\", \\"2022-04-13T14:00\\", \\"2022-04-13T15:00\\", \\"2022-04-13T16:00\\", \\"2022-04-13T17:00\\", \\"2022-04-13T18:00\\", \\"2022-04-13T19:00\\", \\"2022-04-13T20:00\\", \\"2022-04-13T21:00\\", \\"2022-04-13T22:00\\", \\"2022-04-13T23:00\\", \\"2022-04-14T00:00\\", \\"2022-04-14T01:00\\", \\"2022-04-14T02:00\\", \\"2022-04-14T03:00\\", \\"2022-04-14T04:00\\", \\"2022-04-14T05:00\\", \\"2022-04-14T06:00\\", \\"2022-04-14T07:00\\", \\"2022-04-14T08:00\\", \\"2022-04-14T09:00\\", \\"2022-04-14T10:00\\", \\"2022-04-14T11:00\\", \\"2022-04-14T12:00\\", \\"2022-04-14T13:00\\", \\"2022-04-14T14:00\\", \\"2022-04-14T15:00\\", \\"2022-04-14T16:00\\", \\"2022-04-14T17:00\\", \\"2022-04-14T18:00\\", \\"2022-04-14T19:00\\", \\"2022-04-14T20:00\\", \\"2022-04-14T21:00\\", \\"2022-04-14T22:00\\", \\"2022-04-14T23:00\\", \\"2022-04-15T00:00\\", \\"2022-04-15T01:00\\", \\"2022-04-15T02:00\\", \\"2022-04-15T03:00\\", \\"2022-04-15T04:00\\", \\"2022-04-15T05:00\\", \\"2022-04-15T06:00\\", \\"2022-04-15T07:00\\", \\"2022-04-15T08:00\\", \\"2022-04-15T09:00\\", \\"2022-04-15T10:00\\", \\"2022-04-15T11:00\\", \\"2022-04-15T12:00\\", \\"2022-04-15T13:00\\", \\"2022-04-15T14:00\\", \\"2022-04-15T15:00\\", \\"2022-04-15T16:00\\", \\"2022-04-15T17:00\\", \\"2022-04-15T18:00\\", \\"2022-04-15T19:00\\", \\"2022-04-15T20:00\\", \\"2022-04-15T21:00\\", \\"2022-04-15T22:00\\", \\"2022-04-15T23:00\\", \\"2022-04-16T00:00\\", \\"2022-04-16T01:00\\", \\"2022-04-16T02:00\\", \\"2022-04-16T03:00\\", \\"2022-04-16T04:00\\", \\"2022-04-16T05:00\\", \\"2022-04-16T06:00\\", \\"2022-04-16T07:00\\", \\"2022-04-16T08:00\\", \\"2022-04-16T09:00\\", \\"2022-04-16T10:00\\", \\"2022-04-16T11:00\\", \\"2022-04-16T12:00\\", \\"2022-04-16T13:00\\", \\"2022-04-16T14:00\\", \\"2022-04-16T15:00\\", \\"2022-04-16T16:00\\", \\"2022-04-16T17:00\\", \\"2022-04-16T18:00\\", \\"2022-04-16T19:00\\", \\"2022-04-16T20:00\\", \\"2022-04-16T21:00\\", \\"2022-04-16T22:00\\", \\"2022-04-16T23:00\\", \\"2022-04-17T00:00\\", \\"2022-04-17T01:00\\", \\"2022-04-17T02:00\\", \\"2022-04-17T03:00\\", \\"2022-04-17T04:00\\", \\"2022-04-17T05:00\\", \\"2022-04-17T06:00\\", \\"2022-04-17T07:00\\", \\"2022-04-17T08:00\\", \\"2022-04-17T09:00\\", \\"2022-04-17T10:00\\", \\"2022-04-17T11:00\\", \\"2022-04-17T12:00\\", \\"2022-04-17T13:00\\", \\"2022-04-17T14:00\\", \\"2022-04-17T15:00\\", \\"2022-04-17T16:00\\", \\"2022-04-17T17:00\\", \\"2022-04-17T18:00\\", \\"2022-04-17T19:00\\", \\"2022-04-17T20:00\\", \\"2022-04-17T21:00\\", \\"2022-04-17T22:00\\", \\"2022-04-17T23:00\\", \\"2022-04-18T00:00\\", \\"2022-04-18T01:00\\", \\"2022-04-18T02:00\\", \\"2022-04-18T03:00\\", \\"2022-04-18T04:00\\", \\"2022-04-18T05:00\\", \\"2022-04-18T06:00\\", \\"2022-04-18T07:00\\", \\"2022-04-18T08:00\\", \\"2022-04-18T09:00\\", \\"2022-04-18T10:00\\", \\"2022-04-18T11:00\\", \\"2022-04-18T12:00\\", \\"2022-04-18T13:00\\", \\"2022-04-18T14:00\\", \\"2022-04-18T15:00\\", \\"2022-04-18T16:00\\", \\"2022-04-18T17:00\\", \\"2022-04-18T18:00\\", \\"2022-04-18T19:00\\", \\"2022-04-18T20:00\\", \\"2022-04-18T21:00\\", \\"2022-04-18T22:00\\", \\"2022-04-18T23:00\\", \\"2022-04-19T00:00\\", \\"2022-04-19T01:00\\", \\"2022-04-19T02:00\\", \\"2022-04-19T03:00\\", \\"2022-04-19T04:00\\", \\"2022-04-19T05:00\\", \\"2022-04-19T06:00\\", \\"2022-04-19T07:00\\", \\"2022-04-19T08:00\\", \\"2022-04-19T09:00\\", \\"2022-04-19T10:00\\", \\"2022-04-19T11:00\\", \\"2022-04-19T12:00\\", \\"2022-04-19T13:00\\", \\"2022-04-19T14:00\\", \\"2022-04-19T15:00\\", \\"2022-04-19T16:00\\", \\"2022-04-19T17:00\\", \\"2022-04-19T18:00\\", \\"2022-04-19T19:00\\", \\"2022-04-19T20:00\\", \\"2022-04-19T21:00\\", \\"2022-04-19T22:00\\", \\"2022-04-19T23:00\\", \\"2022-04-20T00:00\\", \\"2022-04-20T01:00\\", \\"2022-04-20T02:00\\", \\"2022-04-20T03:00\\", \\"2022-04-20T04:00\\", \\"2022-04-20T05:00\\", \\"2022-04-20T06:00\\", \\"2022-04-20T07:00\\", \\"2022-04-20T08:00\\", \\"2022-04-20T09:00\\", \\"2022-04-20T10:00\\", \\"2022-04-20T11:00\\", \\"2022-04-20T12:00\\", \\"2022-04-20T13:00\\", \\"2022-04-20T14:00\\", \\"2022-04-20T15:00\\", \\"2022-04-20T16:00\\", \\"2022-04-20T17:00\\", \\"2022-04-20T18:00\\", \\"2022-04-20T19:00\\", \\"2022-04-20T20:00\\", \\"2022-04-20T21:00\\", \\"2022-04-20T22:00\\", \\"2022-04-20T23:00\\", \\"2022-04-21T00:00\\", \\"2022-04-21T01:00\\", \\"2022-04-21T02:00\\", \\"2022-04-21T03:00\\", \\"2022-04-21T04:00\\", \\"2022-04-21T05:00\\", \\"2022-04-21T06:00\\", \\"2022-04-21T07:00\\", \\"2022-04-21T08:00\\", \\"2022-04-21T09:00\\", \\"2022-04-21T10:00\\", \\"2022-04-21T11:00\\"], \\"bal\\": [499.242, 498.48400000000004, 497.72600000000006, 496.9680000000001, 496.2100000000001, 495.4520000000001, 494.69400000000013, 493.93600000000015, 493.17800000000017, 492.4200000000002, 491.6620000000002, 490.9040000000002, 490.14600000000024, 489.38800000000026, 488.6300000000003, 487.8720000000003, 487.1140000000003, 486.35600000000034, 485.59800000000035, 484.8400000000004, 484.0820000000004, 483.3240000000004, 482.56600000000043, 481.80800000000045, 481.05000000000047, 480.2920000000005, 479.5340000000005, 478.7760000000005, 478.01800000000054, 477.26000000000056, 476.5020000000006, 475.7440000000006, 474.9860000000006, 474.22800000000063, 473.47000000000065, 472.71200000000067, 471.9540000000007, 471.1960000000007, 470.4380000000007, 469.68000000000075, 468.92200000000076, 468.1640000000008, 467.4060000000008, 466.6480000000008, 465.89000000000084, 465.13200000000086, 464.3740000000009, 463.6160000000009, 462.8580000000009, 462.10000000000093, 461.34200000000095, 460.58400000000097, 459.826000000001, 459.068000000001, 458.310000000001, 457.55200000000104, 456.79400000000106, 456.0360000000011, 455.2780000000011, 454.5200000000011, 453.76200000000114, 453.00400000000116, 452.2460000000012, 451.4880000000012, 450.7300000000012, 449.97200000000123, 449.21400000000125, 448.45600000000127, 447.6980000000013, 446.9400000000013, 446.1820000000013, 445.42400000000134, 444.66600000000136, 443.9080000000014, 443.1500000000014, 442.3920000000014, 441.63400000000144, 440.87600000000145, 440.1180000000015, 439.3600000000015, 438.6020000000015, 437.84400000000153, 437.08600000000155, 436.32800000000157, 435.5700000000016, 434.8120000000016, 434.0540000000016, 433.29600000000164, 432.53800000000166, 431.7800000000017, 431.0220000000017, 430.2640000000017, 429.50600000000173, 428.74800000000175, 427.99000000000177, 427.2320000000018, 426.4740000000018, 425.7160000000018, 424.95800000000185, 424.20000000000186, 423.4420000000019, 422.6840000000019, 421.9260000000019, 421.16800000000194, 420.41000000000196, 419.652000000002, 418.894000000002, 418.136000000002, 417.37800000000203, 416.62000000000205, 415.86200000000207, 415.1040000000021, 414.3460000000021, 413.5880000000021, 412.83000000000214, 412.07200000000216, 411.3140000000022, 410.5560000000022, 409.7980000000022, 409.04000000000224, 408.28200000000226, 407.5240000000023, 406.7660000000023, 406.0080000000023, 405.25000000000233, 404.49200000000235, 403.73400000000237, 402.9760000000024, 402.2180000000024, 401.4600000000024, 400.70200000000244, 399.94400000000246, 399.1860000000025, 398.4280000000025, 397.6700000000025, 396.91200000000254, 396.15400000000255, 395.3960000000026, 394.6380000000026, 393.8800000000026, 393.12200000000263, 392.36400000000265, 391.60600000000267, 390.8480000000027, 390.0900000000027, 389.3320000000027, 388.57400000000274, 387.81600000000276, 387.0580000000028, 386.3000000000028, 385.5420000000028, 384.78400000000283, 384.02600000000285, 383.26800000000287, 382.5100000000029, 381.7520000000029, 380.9940000000029, 380.23600000000295, 379.47800000000296, 378.720000000003, 377.962000000003, 377.204000000003, 376.44600000000304, 375.68800000000306, 374.9300000000031, 374.1720000000031, 373.4140000000031, 372.65600000000313, 371.89800000000315, 371.14000000000317, 370.3820000000032, 369.6240000000032, 368.8660000000032, 368.10800000000324, 367.35000000000326, 366.5920000000033, 365.8340000000033, 365.0760000000033, 364.31800000000334, 363.56000000000336, 362.8020000000034, 362.0440000000034, 361.2860000000034, 360.52800000000343, 359.77000000000345, 359.01200000000347, 358.2540000000035, 357.4960000000035, 356.7380000000035, 355.98000000000354, 355.22200000000356, 354.4640000000036, 353.7060000000036, 352.9480000000036, 352.19000000000364, 351.43200000000365, 350.6740000000037, 349.9160000000037, 349.1580000000037, 348.40000000000373, 347.64200000000375, 346.88400000000377, 346.1260000000038, 345.3680000000038, 344.6100000000038, 343.85200000000384, 343.09400000000386, 342.3360000000039, 341.5780000000039, 340.8200000000039, 340.06200000000393, 339.30400000000395, 338.54600000000397, 337.788000000004, 337.030000000004, 336.272000000004, 335.51400000000405, 334.75600000000406, 333.9980000000041, 333.2400000000041, 332.4820000000041, 331.72400000000414, 330.96600000000416, 330.2080000000042, 329.4500000000042, 328.6920000000042, 327.93400000000423, 327.17600000000425, 326.41800000000427, 325.6600000000043, 324.9020000000043, 324.1440000000043, 323.38600000000434, 322.62800000000436, 321.8700000000044, 321.1120000000044, 320.3540000000044, 319.59600000000444, 318.83800000000446, 318.0800000000045, 317.3220000000045, 316.5640000000045, 315.80600000000453, 315.04800000000455, 314.29000000000457, 313.5320000000046, 312.7740000000046, 312.0160000000046, 311.25800000000464, 310.50000000000466, 309.7420000000047, 308.9840000000047, 308.2260000000047, 307.46800000000474, 306.71000000000475, 305.9520000000048, 305.1940000000048, 304.4360000000048, 303.67800000000483, 302.92000000000485, 302.16200000000487, 301.4040000000049, 300.6460000000049, 299.8880000000049, 299.13000000000494, 298.37200000000496, 297.614000000005, 296.856000000005, 296.098000000005, 295.34000000000503, 294.58200000000505, 293.82400000000507, 293.0660000000051, 292.3080000000051, 291.5500000000051, 290.79200000000515, 290.03400000000516, 289.2760000000052, 288.5180000000052, 287.7600000000052, 287.00200000000524, 286.24400000000526, 285.4860000000053, 284.7280000000053, 283.9700000000053, 283.21200000000533, 282.45400000000535, 281.69600000000537, 280.9380000000054, 280.1800000000054, 279.4220000000054, 278.66400000000544, 277.90600000000546, 277.1480000000055, 276.3900000000055, 275.6320000000055, 274.87400000000554, 274.11600000000556, 273.3580000000056, 272.6000000000056, 271.8420000000056, 271.08400000000563, 270.32600000000565, 269.56800000000567, 268.8100000000057, 268.0520000000057, 267.2940000000057, 266.53600000000574, 265.77800000000576, 265.0200000000058, 264.2620000000058, 263.5040000000058, 262.74600000000584, 261.98800000000585, 261.2300000000059, 260.4720000000059, 259.7140000000059, 258.95600000000593, 258.19800000000595, 257.44000000000597, 256.682000000006, 255.92400000000598, 255.16600000000597, 254.40800000000596, 253.65000000000595, 252.89200000000594, 252.13400000000593, 251.37600000000592, 250.6180000000059, 249.8600000000059, 249.1020000000059, 248.34400000000588, 247.58600000000587, 246.82800000000586, 246.07000000000585, 245.31200000000584]}"	"{\\"tm\\": [\\"2022-04-08\\", \\"2022-04-09\\", \\"2022-04-10\\", \\"2022-04-11\\", \\"2022-04-12\\", \\"2022-04-13\\", \\"2022-04-14\\", \\"2022-04-15\\", \\"2022-04-16\\", \\"2022-04-17\\", \\"2022-04-18\\", \\"2022-04-19\\", \\"2022-04-20\\", \\"2022-04-21\\", \\"2022-04-22\\", \\"2022-04-23\\", \\"2022-04-24\\", \\"2022-04-25\\", \\"2022-04-26\\", \\"2022-04-27\\", \\"2022-04-28\\", \\"2022-04-29\\", \\"2022-04-30\\", \\"2022-05-01\\", \\"2022-05-02\\", \\"2022-05-03\\", \\"2022-05-04\\", \\"2022-05-05\\", \\"2022-05-06\\", \\"2022-05-07\\", \\"2022-05-08\\"], \\"bal\\": [473.41715055555557, 455.22515055555556, 437.03315055555555, 418.84115055555554, 400.64915055555554, 382.45715055555553, 364.2651505555555, 346.0731505555555, 327.8811505555555, 309.6891505555555, 291.4971505555555, 273.3051505555555, 255.11315055555548, 236.92115055555547, 218.72915055555546, 200.53715055555546, 182.34515055555545, 164.15315055555544, 145.96115055555543, 127.76915055555543, 109.57715055555542, 91.38515055555541, 73.1931505555554, 155.0011505555554, 136.8091505555554, 118.61715055555538, 100.42515055555538, 82.23315055555537, 64.04115055555536, 45.84915055555536, 27.65715055555536]}"	"{\\"tm\\": [\\"2022-04\\", \\"2022-04\\", \\"2022-05\\", \\"2022-06\\", \\"2022-07\\", \\"2022-08\\", \\"2022-09\\", \\"2022-10\\", \\"2022-11\\", \\"2022-12\\", \\"2023-01\\", \\"2023-02\\", \\"2023-03\\", \\"2023-04\\"], \\"bal\\": [173.19315055555535, -390.75884944444465, -954.7108494444446, -1518.6628494444446, -2082.6148494444446, -2646.5668494444444, -3210.5188494444446, -3774.470849444445, -4338.422849444445, -4902.374849444445, -5466.3268494444455, -6030.278849444446, -6594.230849444446, -7158.182849444446]}"	2
\.


--
-- Data for Name: users_orgcost; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.users_orgcost (id, creation_date, modified_date, tm, cnt, avg, min, max, std, ccr, gran_id, org_id, cost_refresh_time) FROM stdin;
4	2022-04-07 12:55:48.888256+00	2022-04-07 13:22:39.487062+00	2022-03-31 20:00:00+00	0	0.3760359338666666	0.0045948567	0.7696733723	0.3948598658456049	"{\\n  \\"orgName\\": \\"Developers\\",\\n  \\"total\\": 2.2562156032000003,\\n  \\"unit\\": \\"USD\\",\\n  \\"tm\\": [\\n    \\"2022-03-29T12:00:00Z\\",\\n    \\"2022-03-29T13:00:00Z\\",\\n    \\"2022-03-29T14:00:00Z\\",\\n    \\"2022-03-29T15:00:00Z\\",\\n    \\"2022-03-31T19:00:00Z\\",\\n    \\"2022-03-31T20:00:00Z\\"\\n  ],\\n  \\"cost\\": [\\n    0.7662984295,\\n    0.7696733723,\\n    0.0383468966,\\n    0.0045948567,\\n    0.668437847,\\n    0.0088642011\\n  ],\\n  \\"stats\\": {\\n    \\"avg\\": 0.3760359338666666,\\n    \\"min\\": 0.0045948567,\\n    \\"max\\": 0.7696733723,\\n    \\"std\\": 0.3948598658456049\\n  }\\n}"	HOURLY	1692aada-8f04-4107-a6a5-ae5d46d90123	2022-04-07 13:22:39.487071+00
5	2022-04-07 12:55:48.891672+00	2022-04-07 13:22:39.997133+00	2022-04-01 00:00:00+00	0	3.9518531948571427	0.0368270468	11.252598831	3.777232304652141	"{\\n  \\"orgName\\": \\"Developers\\",\\n  \\"granularity\\": \\"DAILY\\",\\n  \\"total\\": 55.325944728,\\n  \\"unit\\": \\"USD\\",\\n  \\"tm\\": [\\n    \\"2022-02-01\\",\\n    \\"2022-02-03\\",\\n    \\"2022-02-04\\",\\n    \\"2022-03-01\\",\\n    \\"2022-03-02\\",\\n    \\"2022-03-03\\",\\n    \\"2022-03-04\\",\\n    \\"2022-03-16\\",\\n    \\"2022-03-17\\",\\n    \\"2022-03-18\\",\\n    \\"2022-03-19\\",\\n    \\"2022-03-24\\",\\n    \\"2022-03-30\\",\\n    \\"2022-04-01\\"\\n  ],\\n  \\"cost\\": [\\n    0.0368270468,\\n    4.9711792579,\\n    1.227350342,\\n    0.7632956098,\\n    1.0949567742,\\n    5.3191604464,\\n    8.8627288522,\\n    3.7510137793,\\n    6.6595194084,\\n    11.252598831,\\n    9.0149021745,\\n    0.1161966023,\\n    1.5789135551,\\n    0.6773020481\\n  ],\\n  \\"stats\\": {\\n    \\"avg\\": 3.9518531948571427,\\n    \\"min\\": 0.0368270468,\\n    \\"max\\": 11.252598831,\\n    \\"std\\": 3.777232304652141\\n  }\\n}"	DAILY	1692aada-8f04-4107-a6a5-ae5d46d90123	2022-04-07 13:22:39.997144+00
6	2022-04-07 12:55:48.894051+00	2022-04-07 13:22:40.337604+00	2022-04-01 00:00:00+00	0	18.441981576	0.0368270468	48.3272924715	26.11202319582993	"{\\n  \\"orgName\\": \\"Developers\\",\\n  \\"granularity\\": \\"MONTHLY\\",\\n  \\"total\\": 55.325944728,\\n  \\"unit\\": \\"USD\\",\\n  \\"tm\\": [\\n    \\"2022-02-01\\",\\n    \\"2022-03-01\\",\\n    \\"2022-04-01\\"\\n  ],\\n  \\"cost\\": [\\n    0.0368270468,\\n    6.9618252097,\\n    48.3272924715\\n  ],\\n  \\"stats\\": {\\n    \\"avg\\": 18.441981576,\\n    \\"min\\": 0.0368270468,\\n    \\"max\\": 48.3272924715,\\n    \\"std\\": 26.11202319582993\\n  }\\n}"	MONTHLY	1692aada-8f04-4107-a6a5-ae5d46d90123	2022-04-07 13:22:40.337621+00
7	2022-04-07 12:57:58.335568+00	2022-04-07 13:22:40.804546+00	2022-03-31 22:00:00+00	0	0.32295898534	0.0006394723	0.7656943724	0.4048199332196135	"{\\n  \\"orgName\\": \\"UofMDTest\\",\\n  \\"total\\": 1.6147949267000001,\\n  \\"unit\\": \\"USD\\",\\n  \\"tm\\": [\\n    \\"2022-03-25T20:00:00Z\\",\\n    \\"2022-03-25T21:00:00Z\\",\\n    \\"2022-03-25T22:00:00Z\\",\\n    \\"2022-03-31T21:00:00Z\\",\\n    \\"2022-03-31T22:00:00Z\\"\\n  ],\\n  \\"cost\\": [\\n    0.7656943724,\\n    0.7644533703,\\n    0.0044315232,\\n    0.0795761885,\\n    0.0006394723\\n  ],\\n  \\"stats\\": {\\n    \\"avg\\": 0.32295898534,\\n    \\"min\\": 0.0006394723,\\n    \\"max\\": 0.7656943724,\\n    \\"std\\": 0.4048199332196135\\n  }\\n}"	HOURLY	86082b90-785e-46e2-a8f6-37e82fc04d00	2022-04-07 13:22:40.804555+00
8	2022-04-07 12:57:58.338458+00	2022-04-07 13:22:41.174895+00	2022-04-01 00:00:00+00	0	0.80739746335	0.0802156608	1.5345792659	1.028390367477124	"{\\n  \\"orgName\\": \\"UofMDTest\\",\\n  \\"granularity\\": \\"DAILY\\",\\n  \\"total\\": 1.6147949267,\\n  \\"unit\\": \\"USD\\",\\n  \\"tm\\": [\\n    \\"2022-03-26\\",\\n    \\"2022-04-01\\"\\n  ],\\n  \\"cost\\": [\\n    1.5345792659,\\n    0.0802156608\\n  ],\\n  \\"stats\\": {\\n    \\"avg\\": 0.80739746335,\\n    \\"min\\": 0.0802156608,\\n    \\"max\\": 1.5345792659,\\n    \\"std\\": 1.028390367477124\\n  }\\n}"	DAILY	86082b90-785e-46e2-a8f6-37e82fc04d00	2022-04-07 13:22:41.174908+00
9	2022-04-07 12:57:58.340821+00	2022-04-07 13:22:41.497367+00	2022-04-01 00:00:00+00	0	1.6147949267	1.6147949267	1.6147949267	0	"{\\n  \\"orgName\\": \\"UofMDTest\\",\\n  \\"granularity\\": \\"MONTHLY\\",\\n  \\"total\\": 1.6147949267,\\n  \\"unit\\": \\"USD\\",\\n  \\"tm\\": [\\n    \\"2022-04-01\\"\\n  ],\\n  \\"cost\\": [\\n    1.6147949267\\n  ],\\n  \\"stats\\": {\\n    \\"avg\\": 1.6147949267,\\n    \\"min\\": 1.6147949267,\\n    \\"max\\": 1.6147949267\\n  },\\n  \\"serverError\\": true,\\n  \\"errorMsg\\": \\" Processing for org:UofMDTest cluster caught this exception\\"\\n}"	MONTHLY	86082b90-785e-46e2-a8f6-37e82fc04d00	2022-04-07 13:22:41.497375+00
\.


--
-- Data for Name: users_user; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.users_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined, phone_number) FROM stdin;
3	pbkdf2_sha256$260000$2vThTTffBVFBjIwHdQIT2h$dc2WYaL8+3emG0bdFcTZqusmJw7DpKitsBEjDfuRnrc=	2022-04-07 12:33:53.016748+00	f	terpadmin	Terp	Admin	test.sliderule@gmail.com	f	t	2022-04-01 21:15:29.029212+00	+13015550100
1	pbkdf2_sha256$260000$m29cOogA3XdlUABB6SvHU6$mo3mOcguQoO/EN4GHutj6LF+NIm0DOl5ZHFHwltzH3k=	2022-04-07 12:52:06.166275+00	t	admin			ps.sliderule@gmail.com	t	t	2022-04-01 19:16:44.334579+00	+15555550100
2	pbkdf2_sha256$260000$95MMbqa49arLbZRNDR2zcP$F2AGVJG1EsxTZpexJB0kYMmXSYXwa20RbXpf0pgvaNU=	2022-04-08 00:34:24.965328+00	f	ceugarteblair	Carlos	Ugarte	ceugarteblair@icloud.com	t	t	2022-04-01 20:54:18+00	+13013251599
\.


--
-- Data for Name: users_user_groups; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.users_user_groups (id, user_id, group_id) FROM stdin;
1	2	1
\.


--
-- Data for Name: users_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: ps_admin
--

COPY public.users_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ps_admin
--

SELECT pg_catalog.setval('public.auth_group_id_seq', 1, true);


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ps_admin
--

SELECT pg_catalog.setval('public.auth_group_permissions_id_seq', 40, true);


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ps_admin
--

SELECT pg_catalog.setval('public.auth_permission_id_seq', 68, true);


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ps_admin
--

SELECT pg_catalog.setval('public.django_admin_log_id_seq', 11, true);


--
-- Name: django_celery_beat_clockedschedule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ps_admin
--

SELECT pg_catalog.setval('public.django_celery_beat_clockedschedule_id_seq', 1, false);


--
-- Name: django_celery_beat_crontabschedule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ps_admin
--

SELECT pg_catalog.setval('public.django_celery_beat_crontabschedule_id_seq', 2, true);


--
-- Name: django_celery_beat_intervalschedule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ps_admin
--

SELECT pg_catalog.setval('public.django_celery_beat_intervalschedule_id_seq', 1, false);


--
-- Name: django_celery_beat_periodictask_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ps_admin
--

SELECT pg_catalog.setval('public.django_celery_beat_periodictask_id_seq', 2, true);


--
-- Name: django_celery_beat_solarschedule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ps_admin
--

SELECT pg_catalog.setval('public.django_celery_beat_solarschedule_id_seq', 1, false);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ps_admin
--

SELECT pg_catalog.setval('public.django_content_type_id_seq', 17, true);


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ps_admin
--

SELECT pg_catalog.setval('public.django_migrations_id_seq', 39, true);


--
-- Name: users_orgcost_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ps_admin
--

SELECT pg_catalog.setval('public.users_orgcost_id_seq', 9, true);


--
-- Name: users_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ps_admin
--

SELECT pg_catalog.setval('public.users_user_groups_id_seq', 1, true);


--
-- Name: users_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ps_admin
--

SELECT pg_catalog.setval('public.users_user_id_seq', 3, true);


--
-- Name: users_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ps_admin
--

SELECT pg_catalog.setval('public.users_user_user_permissions_id_seq', 1, false);


--
-- Name: auth_group auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: ps_admin
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions auth_group_permissions_group_id_permission_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: ps_admin
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: ps_admin
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: ps_admin
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission auth_permission_content_type_id_codename_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: ps_admin
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- Name: auth_permission auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: ps_admin
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: django_admin_log django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: ps_admin
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_celery_beat_clockedschedule django_celery_beat_clockedschedule_pkey; Type: CONSTRAINT; Schema: public; Owner: ps_admin
--

ALTER TABLE ONLY public.django_celery_beat_clockedschedule
    ADD CONSTRAINT django_celery_beat_clockedschedule_pkey PRIMARY KEY (id);


--
-- Name: django_celery_beat_crontabschedule django_celery_beat_crontabschedule_pkey; Type: CONSTRAINT; Schema: public; Owner: ps_admin
--

ALTER TABLE ONLY public.django_celery_beat_crontabschedule
    ADD CONSTRAINT django_celery_beat_crontabschedule_pkey PRIMARY KEY (id);


--
-- Name: django_celery_beat_intervalschedule django_celery_beat_intervalschedule_pkey; Type: CONSTRAINT; Schema: public; Owner: ps_admin
--

ALTER TABLE ONLY public.django_celery_beat_intervalschedule
    ADD CONSTRAINT django_celery_beat_intervalschedule_pkey PRIMARY KEY (id);


--
-- Name: django_celery_beat_periodictask django_celery_beat_periodictask_name_key; Type: CONSTRAINT; Schema: public; Owner: ps_admin
--

ALTER TABLE ONLY public.django_celery_beat_periodictask
    ADD CONSTRAINT django_celery_beat_periodictask_name_key UNIQUE (name);


--
-- Name: django_celery_beat_periodictask django_celery_beat_periodictask_pkey; Type: CONSTRAINT; Schema: public; Owner: ps_admin
--

ALTER TABLE ONLY public.django_celery_beat_periodictask
    ADD CONSTRAINT django_celery_beat_periodictask_pkey PRIMARY KEY (id);


--
-- Name: django_celery_beat_periodictasks django_celery_beat_periodictasks_pkey; Type: CONSTRAINT; Schema: public; Owner: ps_admin
--

ALTER TABLE ONLY public.django_celery_beat_periodictasks
    ADD CONSTRAINT django_celery_beat_periodictasks_pkey PRIMARY KEY (ident);


--
-- Name: django_celery_beat_solarschedule django_celery_beat_solar_event_latitude_longitude_ba64999a_uniq; Type: CONSTRAINT; Schema: public; Owner: ps_admin
--

ALTER TABLE ONLY public.django_celery_beat_solarschedule
    ADD CONSTRAINT django_celery_beat_solar_event_latitude_longitude_ba64999a_uniq UNIQUE (event, latitude, longitude);


--
-- Name: django_celery_beat_solarschedule django_celery_beat_solarschedule_pkey; Type: CONSTRAINT; Schema: public; Owner: ps_admin
--

ALTER TABLE ONLY public.django_celery_beat_solarschedule
    ADD CONSTRAINT django_celery_beat_solarschedule_pkey PRIMARY KEY (id);


--
-- Name: django_content_type django_content_type_app_label_model_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: ps_admin
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_app_label_model_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: ps_admin
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: ps_admin
--

ALTER TABLE ONLY public.django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_session django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: ps_admin
--

ALTER TABLE ONLY public.django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: users_cluster users_cluster_pkey; Type: CONSTRAINT; Schema: public; Owner: ps_admin
--

ALTER TABLE ONLY public.users_cluster
    ADD CONSTRAINT users_cluster_pkey PRIMARY KEY (org_id);


--
-- Name: users_granchoices users_granchoices_pkey; Type: CONSTRAINT; Schema: public; Owner: ps_admin
--

ALTER TABLE ONLY public.users_granchoices
    ADD CONSTRAINT users_granchoices_pkey PRIMARY KEY (granularity);


--
-- Name: users_membership users_membership_pkey; Type: CONSTRAINT; Schema: public; Owner: ps_admin
--

ALTER TABLE ONLY public.users_membership
    ADD CONSTRAINT users_membership_pkey PRIMARY KEY (id);


--
-- Name: users_orgaccount users_orgaccount_pkey; Type: CONSTRAINT; Schema: public; Owner: ps_admin
--

ALTER TABLE ONLY public.users_orgaccount
    ADD CONSTRAINT users_orgaccount_pkey PRIMARY KEY (id);


--
-- Name: users_orgcost users_orgcost_pkey; Type: CONSTRAINT; Schema: public; Owner: ps_admin
--

ALTER TABLE ONLY public.users_orgcost
    ADD CONSTRAINT users_orgcost_pkey PRIMARY KEY (id);


--
-- Name: users_user_groups users_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: ps_admin
--

ALTER TABLE ONLY public.users_user_groups
    ADD CONSTRAINT users_user_groups_pkey PRIMARY KEY (id);


--
-- Name: users_user_groups users_user_groups_user_id_group_id_b88eab82_uniq; Type: CONSTRAINT; Schema: public; Owner: ps_admin
--

ALTER TABLE ONLY public.users_user_groups
    ADD CONSTRAINT users_user_groups_user_id_group_id_b88eab82_uniq UNIQUE (user_id, group_id);


--
-- Name: users_user users_user_pkey; Type: CONSTRAINT; Schema: public; Owner: ps_admin
--

ALTER TABLE ONLY public.users_user
    ADD CONSTRAINT users_user_pkey PRIMARY KEY (id);


--
-- Name: users_user_user_permissions users_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: ps_admin
--

ALTER TABLE ONLY public.users_user_user_permissions
    ADD CONSTRAINT users_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: users_user_user_permissions users_user_user_permissions_user_id_permission_id_43338c45_uniq; Type: CONSTRAINT; Schema: public; Owner: ps_admin
--

ALTER TABLE ONLY public.users_user_user_permissions
    ADD CONSTRAINT users_user_user_permissions_user_id_permission_id_43338c45_uniq UNIQUE (user_id, permission_id);


--
-- Name: users_user users_user_username_key; Type: CONSTRAINT; Schema: public; Owner: ps_admin
--

ALTER TABLE ONLY public.users_user
    ADD CONSTRAINT users_user_username_key UNIQUE (username);


--
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: ps_admin
--

CREATE INDEX auth_group_name_a6ea08ec_like ON public.auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_group_id_b120cbf9; Type: INDEX; Schema: public; Owner: ps_admin
--

CREATE INDEX auth_group_permissions_group_id_b120cbf9 ON public.auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_permission_id_84c5c92e; Type: INDEX; Schema: public; Owner: ps_admin
--

CREATE INDEX auth_group_permissions_permission_id_84c5c92e ON public.auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_content_type_id_2f476e4b; Type: INDEX; Schema: public; Owner: ps_admin
--

CREATE INDEX auth_permission_content_type_id_2f476e4b ON public.auth_permission USING btree (content_type_id);


--
-- Name: django_admin_log_content_type_id_c4bce8eb; Type: INDEX; Schema: public; Owner: ps_admin
--

CREATE INDEX django_admin_log_content_type_id_c4bce8eb ON public.django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_user_id_c564eba6; Type: INDEX; Schema: public; Owner: ps_admin
--

CREATE INDEX django_admin_log_user_id_c564eba6 ON public.django_admin_log USING btree (user_id);


--
-- Name: django_celery_beat_periodictask_clocked_id_47a69f82; Type: INDEX; Schema: public; Owner: ps_admin
--

CREATE INDEX django_celery_beat_periodictask_clocked_id_47a69f82 ON public.django_celery_beat_periodictask USING btree (clocked_id);


--
-- Name: django_celery_beat_periodictask_crontab_id_d3cba168; Type: INDEX; Schema: public; Owner: ps_admin
--

CREATE INDEX django_celery_beat_periodictask_crontab_id_d3cba168 ON public.django_celery_beat_periodictask USING btree (crontab_id);


--
-- Name: django_celery_beat_periodictask_interval_id_a8ca27da; Type: INDEX; Schema: public; Owner: ps_admin
--

CREATE INDEX django_celery_beat_periodictask_interval_id_a8ca27da ON public.django_celery_beat_periodictask USING btree (interval_id);


--
-- Name: django_celery_beat_periodictask_name_265a36b7_like; Type: INDEX; Schema: public; Owner: ps_admin
--

CREATE INDEX django_celery_beat_periodictask_name_265a36b7_like ON public.django_celery_beat_periodictask USING btree (name varchar_pattern_ops);


--
-- Name: django_celery_beat_periodictask_solar_id_a87ce72c; Type: INDEX; Schema: public; Owner: ps_admin
--

CREATE INDEX django_celery_beat_periodictask_solar_id_a87ce72c ON public.django_celery_beat_periodictask USING btree (solar_id);


--
-- Name: django_session_expire_date_a5c62663; Type: INDEX; Schema: public; Owner: ps_admin
--

CREATE INDEX django_session_expire_date_a5c62663 ON public.django_session USING btree (expire_date);


--
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: ps_admin
--

CREATE INDEX django_session_session_key_c0390e0f_like ON public.django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: users_granchoices_granularity_2aab50c0_like; Type: INDEX; Schema: public; Owner: ps_admin
--

CREATE INDEX users_granchoices_granularity_2aab50c0_like ON public.users_granchoices USING btree (granularity varchar_pattern_ops);


--
-- Name: users_membership_org_id_dba0dca1; Type: INDEX; Schema: public; Owner: ps_admin
--

CREATE INDEX users_membership_org_id_dba0dca1 ON public.users_membership USING btree (org_id);


--
-- Name: users_membership_user_id_4e97941d; Type: INDEX; Schema: public; Owner: ps_admin
--

CREATE INDEX users_membership_user_id_4e97941d ON public.users_membership USING btree (user_id);


--
-- Name: users_orgaccount_owner_id_61e252a1; Type: INDEX; Schema: public; Owner: ps_admin
--

CREATE INDEX users_orgaccount_owner_id_61e252a1 ON public.users_orgaccount USING btree (owner_id);


--
-- Name: users_orgcost_gran_id_29d2bb20; Type: INDEX; Schema: public; Owner: ps_admin
--

CREATE INDEX users_orgcost_gran_id_29d2bb20 ON public.users_orgcost USING btree (gran_id);


--
-- Name: users_orgcost_gran_id_29d2bb20_like; Type: INDEX; Schema: public; Owner: ps_admin
--

CREATE INDEX users_orgcost_gran_id_29d2bb20_like ON public.users_orgcost USING btree (gran_id varchar_pattern_ops);


--
-- Name: users_orgcost_org_id_a949e970; Type: INDEX; Schema: public; Owner: ps_admin
--

CREATE INDEX users_orgcost_org_id_a949e970 ON public.users_orgcost USING btree (org_id);


--
-- Name: users_user_groups_group_id_9afc8d0e; Type: INDEX; Schema: public; Owner: ps_admin
--

CREATE INDEX users_user_groups_group_id_9afc8d0e ON public.users_user_groups USING btree (group_id);


--
-- Name: users_user_groups_user_id_5f6f5a90; Type: INDEX; Schema: public; Owner: ps_admin
--

CREATE INDEX users_user_groups_user_id_5f6f5a90 ON public.users_user_groups USING btree (user_id);


--
-- Name: users_user_user_permissions_permission_id_0b93982e; Type: INDEX; Schema: public; Owner: ps_admin
--

CREATE INDEX users_user_user_permissions_permission_id_0b93982e ON public.users_user_user_permissions USING btree (permission_id);


--
-- Name: users_user_user_permissions_user_id_20aca447; Type: INDEX; Schema: public; Owner: ps_admin
--

CREATE INDEX users_user_user_permissions_user_id_20aca447 ON public.users_user_user_permissions USING btree (user_id);


--
-- Name: users_user_username_06e46fe6_like; Type: INDEX; Schema: public; Owner: ps_admin
--

CREATE INDEX users_user_username_06e46fe6_like ON public.users_user USING btree (username varchar_pattern_ops);


--
-- Name: auth_group_permissions auth_group_permissio_permission_id_84c5c92e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: ps_admin
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_permission_id_84c5c92e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: ps_admin
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permission auth_permission_content_type_id_2f476e4b_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: ps_admin
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_2f476e4b_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_content_type_id_c4bce8eb_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: ps_admin
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_content_type_id_c4bce8eb_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_user_id_c564eba6_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: ps_admin
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_c564eba6_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_celery_beat_periodictask django_celery_beat_periodictask_clocked_id_47a69f82_fk; Type: FK CONSTRAINT; Schema: public; Owner: ps_admin
--

ALTER TABLE ONLY public.django_celery_beat_periodictask
    ADD CONSTRAINT django_celery_beat_periodictask_clocked_id_47a69f82_fk FOREIGN KEY (clocked_id) REFERENCES public.django_celery_beat_clockedschedule(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_celery_beat_periodictask django_celery_beat_periodictask_crontab_id_d3cba168_fk; Type: FK CONSTRAINT; Schema: public; Owner: ps_admin
--

ALTER TABLE ONLY public.django_celery_beat_periodictask
    ADD CONSTRAINT django_celery_beat_periodictask_crontab_id_d3cba168_fk FOREIGN KEY (crontab_id) REFERENCES public.django_celery_beat_crontabschedule(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_celery_beat_periodictask django_celery_beat_periodictask_interval_id_a8ca27da_fk; Type: FK CONSTRAINT; Schema: public; Owner: ps_admin
--

ALTER TABLE ONLY public.django_celery_beat_periodictask
    ADD CONSTRAINT django_celery_beat_periodictask_interval_id_a8ca27da_fk FOREIGN KEY (interval_id) REFERENCES public.django_celery_beat_intervalschedule(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_celery_beat_periodictask django_celery_beat_periodictask_solar_id_a87ce72c_fk; Type: FK CONSTRAINT; Schema: public; Owner: ps_admin
--

ALTER TABLE ONLY public.django_celery_beat_periodictask
    ADD CONSTRAINT django_celery_beat_periodictask_solar_id_a87ce72c_fk FOREIGN KEY (solar_id) REFERENCES public.django_celery_beat_solarschedule(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_cluster users_cluster_org_id_666dcb10_fk_users_orgaccount_id; Type: FK CONSTRAINT; Schema: public; Owner: ps_admin
--

ALTER TABLE ONLY public.users_cluster
    ADD CONSTRAINT users_cluster_org_id_666dcb10_fk_users_orgaccount_id FOREIGN KEY (org_id) REFERENCES public.users_orgaccount(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_membership users_membership_org_id_dba0dca1_fk_users_orgaccount_id; Type: FK CONSTRAINT; Schema: public; Owner: ps_admin
--

ALTER TABLE ONLY public.users_membership
    ADD CONSTRAINT users_membership_org_id_dba0dca1_fk_users_orgaccount_id FOREIGN KEY (org_id) REFERENCES public.users_orgaccount(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_membership users_membership_user_id_4e97941d_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: ps_admin
--

ALTER TABLE ONLY public.users_membership
    ADD CONSTRAINT users_membership_user_id_4e97941d_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_orgaccount users_orgaccount_owner_id_61e252a1_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: ps_admin
--

ALTER TABLE ONLY public.users_orgaccount
    ADD CONSTRAINT users_orgaccount_owner_id_61e252a1_fk_users_user_id FOREIGN KEY (owner_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_orgcost users_orgcost_gran_id_29d2bb20_fk_users_granchoices_granularity; Type: FK CONSTRAINT; Schema: public; Owner: ps_admin
--

ALTER TABLE ONLY public.users_orgcost
    ADD CONSTRAINT users_orgcost_gran_id_29d2bb20_fk_users_granchoices_granularity FOREIGN KEY (gran_id) REFERENCES public.users_granchoices(granularity) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_orgcost users_orgcost_org_id_a949e970_fk_users_orgaccount_id; Type: FK CONSTRAINT; Schema: public; Owner: ps_admin
--

ALTER TABLE ONLY public.users_orgcost
    ADD CONSTRAINT users_orgcost_org_id_a949e970_fk_users_orgaccount_id FOREIGN KEY (org_id) REFERENCES public.users_orgaccount(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_user_groups users_user_groups_group_id_9afc8d0e_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: ps_admin
--

ALTER TABLE ONLY public.users_user_groups
    ADD CONSTRAINT users_user_groups_group_id_9afc8d0e_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_user_groups users_user_groups_user_id_5f6f5a90_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: ps_admin
--

ALTER TABLE ONLY public.users_user_groups
    ADD CONSTRAINT users_user_groups_user_id_5f6f5a90_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_user_user_permissions users_user_user_perm_permission_id_0b93982e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: ps_admin
--

ALTER TABLE ONLY public.users_user_user_permissions
    ADD CONSTRAINT users_user_user_perm_permission_id_0b93982e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_user_user_permissions users_user_user_permissions_user_id_20aca447_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: ps_admin
--

ALTER TABLE ONLY public.users_user_user_permissions
    ADD CONSTRAINT users_user_user_permissions_user_id_20aca447_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- PostgreSQL database dump complete
--

