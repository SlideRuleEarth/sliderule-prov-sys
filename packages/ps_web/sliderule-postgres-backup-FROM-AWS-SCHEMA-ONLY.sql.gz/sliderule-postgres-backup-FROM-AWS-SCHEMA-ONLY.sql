
The Session Manager plugin was installed successfully. Use the AWS CLI to start a session.


Starting session with SessionId: ecs-execute-command-07c9ffa47aa35284c


SessionId: ecs-execute-command-07c9ffa47aa35284c : 
----------ERROR-------
Unable to start command: Failed to start pty: fork/exec /usr/bin/pg_dump: no such file or directory



